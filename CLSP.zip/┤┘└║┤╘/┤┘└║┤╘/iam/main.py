import boto3
import json
import os
from iam_no_root_access_key import iam_no_root_access_key



iam_client = boto3.client('iam',
                aws_access_key_id="AKIAXYKJTDP3MQUIMI43",
                aws_secret_access_key="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",
                region_name='ap-northeast-2')

response = iam_client.get_user()

results = []

results.append(iam_no_root_access_key(iam_client))



with open('iam_analysis_results.json', 'w') as json_file:
    json.dump(results, json_file, indent=4)

print("Results have been saved to iam_analysis_results.json")
#Unable to locate credentials 이 에러가 나는 99프로 이유는 키가 잘못됐기 떄문이다.

#1번째 코드안에 키값을 넣지말자