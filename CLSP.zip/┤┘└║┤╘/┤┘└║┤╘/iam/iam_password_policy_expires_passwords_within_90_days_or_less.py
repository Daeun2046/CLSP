import boto3
import logging

# 로거 설정
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# boto3 IAM 클라이언트 생성
iam_client = boto3.client('iam')

# 비밀번호 정책 검사 및 수정 클래스
class IAMPasswordPolicyManager:
    def __init__(self, region_name='ap-northeast-2'):
        # 주어진 지역 이름으로 IAM 클라이언트 생성
        self.iam_client = boto3.client('iam', region_name=region_name)
        # 현재 비밀번호 정책 가져오기
        self.password_policy = self.get_password_policy()

    def get_password_policy(self):
        try:
            # 현재 계정의 비밀번호 정책 가져오기
            response = self.iam_client.get_account_password_policy()
            return response['PasswordPolicy']
        except self.iam_client.exceptions.NoSuchEntityException:
            # 비밀번호 정책이 없을 경우 로그 출력
            logger.info("No password policy found.")
            return None
        except Exception as e:
            # 다른 예외 발생 시 로그 출력
            logger.error(f"Error retrieving password policy: {e}")
            return None

    def check_password_policy(self):
        findings = []
        if self.password_policy:
            # 정책 검사 결과를 저장할 리포트 생성
            report = {
                'region': self.iam_client.meta.region_name,
                'resource_id': 'account-password-policy',
                'resource_arn': 'arn:aws:iam::aws:policy/PasswordPolicy',
            }
            # 최대 비밀번호 사용 기간 가져오기
            max_age = self.password_policy.get('MaxPasswordAge', None)
            if max_age is not None:
                if max_age <= 90:
                    # 비밀번호 사용 기간이 90일 이하일 때
                    report['status'] = "PASS"
                    report['status_extended'] = f"Password expiration is set to {max_age} days, which is within the limit."
                else:
                    # 비밀번호 사용 기간이 90일 초과일 때
                    report['status'] = "FAIL"
                    report['status_extended'] = f"Password expiration is set to {max_age} days, which is more than 90 days."
            else:
                # 비밀번호 사용 기간이 설정되지 않았을 때
                report['status'] = "FAIL"
                report['status_extended'] = "Password expiration is not set."
            findings.append(report)
        else:
            # 비밀번호 정책이 없을 때 로그 출력
            logger.info("No password policy to check.")
        return findings

    def update_password_policy(self, max_password_age=90):
        if not self.password_policy:
            # 비밀번호 정책이 없을 때 로그 출력
            logger.error("No password policy found to update.")
            return False

        try:
            # 비밀번호 정책 업데이트
            self.iam_client.update_account_password_policy(
                MinimumPasswordLength=self.password_policy.get('MinimumPasswordLength', 8),
                RequireSymbols=self.password_policy.get('RequireSymbols', True),
                RequireNumbers=self.password_policy.get('RequireNumbers', True),
                RequireUppercaseCharacters=self.password_policy.get('RequireUppercaseCharacters', True),
                RequireLowercaseCharacters=self.password_policy.get('RequireLowercaseCharacters', True),
                AllowUsersToChangePassword=self.password_policy.get('AllowUsersToChangePassword', True),
                MaxPasswordAge=max_password_age,
                PasswordReusePrevention=self.password_policy.get('PasswordReusePrevention', 24),
                HardExpiry=self.password_policy.get('HardExpiry', False),
            )
            # 성공 로그 출력
            logger.info("Password policy updated successfully.")
            return True
        except Exception as error:
            # 업데이트 실패 시 로그 출력
            logger.error(f"Failed to update password policy: {error}")
            return False
