import boto3
import logging

# 로깅 설정
logging.basicConfig(level=logging.INFO)  # 로깅 기본 설정을 INFO 레벨로 설정
logger = logging.getLogger(__name__)  # 현재 모듈 이름으로 로거 생성

# AWS 클라이언트 생성
iam_client = boto3.client('iam')  # IAM 클라이언트 생성

def check_password_policy():
    """
    IAM 비밀번호 정책을 확인하고, 최소 하나의 특수 문자를 요구하는지 검사하는 함수.
    """
    try:
        # 비밀번호 정책 가져오기
        password_policy = iam_client.get_account_password_policy()['PasswordPolicy']
        # 비밀번호 정책에서 특수 문자를 요구하는지 확인
        requires_symbols = password_policy.get('RequireSymbols', False)
        
        if requires_symbols:
            # 특수 문자를 요구하면 로그에 정보 기록 후 PASS 상태 반환
            logger.info("IAM password policy requires at least one symbol.")
            return "PASS", "IAM password policy requires at least one symbol."
        else:
            # 특수 문자를 요구하지 않으면 로그에 경고 기록 후 FAIL 상태 반환
            logger.warning("IAM password policy does not require at least one symbol.")
            return "FAIL", "IAM password policy does not require at least one symbol."
    except iam_client.exceptions.NoSuchEntityException:
        # 비밀번호 정책이 존재하지 않으면 로그에 오류 기록 후 FAIL 상태 반환
        logger.error("No password policy found.")
        return "FAIL", "No password policy found."
    except Exception as e:
        # 기타 예외 발생 시 로그에 오류 기록 후 FAIL 상태 반환
        logger.error(f"Error checking password policy: {e}")
        return "FAIL", f"Error checking password policy: {e}"

def update_password_policy(require_symbols=True):
    """
    IAM 비밀번호 정책을 수정하여 최소 하나의 특수 문자를 요구하도록 설정하는 함수.
    """
    try:
        # 비밀번호 정책 업데이트
        iam_client.update_account_password_policy(
            MinimumPasswordLength=8,  # 비밀번호 최소 길이 설정 (기본값 8)
            RequireSymbols=require_symbols,  # 특수 문자 요구 설정
            RequireNumbers=True,  # 숫자 요구 설정 (기본값 True)
            RequireUppercaseCharacters=True,  # 대문자 요구 설정 (기본값 True)
            RequireLowercaseCharacters=True,  # 소문자 요구 설정 (기본값 True)
            AllowUsersToChangePassword=True,  # 사용자 비밀번호 변경 허용 (기본값 True)
            MaxPasswordAge=90,  # 비밀번호 최대 사용 기간 설정 (기본값 90일)
            PasswordReusePrevention=5,  # 이전 비밀번호 재사용 방지 설정 (기본값 5회)
            HardExpiry=False  # 비밀번호 만료 시 강제 만료 설정 (기본값 False)
        )
        # 정책 업데이트 성공 시 로그에 정보 기록
        logger.info("IAM password policy updated to require at least one symbol.")
        return True
    except Exception as e:
        # 정책 업데이트 실패 시 로그에 오류 기록
        logger.error(f"Error updating password policy: {e}")
        return False
