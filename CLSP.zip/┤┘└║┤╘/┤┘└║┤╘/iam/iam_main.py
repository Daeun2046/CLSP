import os
import logging
import boto3
from iam_no_root_access_key import iam_no_root_access_key
from iam_password_policy_expires_passwords_within_90_days_or_less import IAMPasswordPolicyManager
from iam_password_policy_lowercase import main as lowercase_main
import iam_password_policy_minimum_length_14 as iam_policy_min_length
from iam_password_policy_number import IAMPasswordPolicyChecker
from iam_password_policy_reuse_24 import IAMClient, IAMPasswordPolicyReuse24, fixer, logger as reuse_logger
from iam_password_policy_symbol import check_password_policy as check_symbol_policy, update_password_policy as update_symbol_policy
import iam_password_policy_uppercase as uppercase_policy

# 로깅 설정
logger = logging.getLogger()
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

def get_aws_credentials():
    aws_access_key = os.getenv('AWS_ACCESS_KEY_ID')
    aws_secret_key = os.getenv('AWS_SECRET_ACCESS_KEY')

    if not aws_access_key or not aws_secret_key:
        aws_access_key = input("AWS Access Key ID를 입력하세요: ")
        aws_secret_key = input("AWS Secret Access Key를 입력하세요: ")
        os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key
        os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_key

    return aws_access_key, aws_secret_key

def check_no_root_access_key():
    findings = iam_no_root_access_key()
    for finding in findings:
        print(finding)

def manage_password_policy():
    manager = IAMPasswordPolicyManager(region_name='ap-northeast-2')
    findings = manager.check_password_policy()
    for finding in findings:
        logger.info(f"Check Result: {finding}")
    if not manager.update_password_policy(max_password_age=90):
        logger.error("Failed to update the password policy.")

def check_and_update_min_length_policy():
    check_results = iam_policy_min_length.check_password_policy_minimum_length_14()
    for result in check_results:
        print(result)
    if any(result['status'] == "FAIL" for result in check_results):
        print("Updating password policy to meet minimum length requirement...")
        if iam_policy_min_length.fixer():
            print("Password policy updated successfully.")
        else:
            print("Failed to update password policy.")

def check_and_update_number_policy():
    checker = IAMPasswordPolicyChecker()
    findings = checker.check_password_policy()
    for finding in findings:
        logger.info(f"Region: {finding['region']}, Resource ARN: {finding['resource_arn']}, "
                    f"Status: {finding['status']}, Details: {finding['status_extended']}")
        if finding['status'] == "FAIL":
            logger.info("Fixing the IAM password policy to require numbers...")
            if checker.fix_password_policy():
                logger.info("IAM password policy updated successfully.")
            else:
                logger.error("Failed to update IAM password policy.")

def check_and_update_reuse_policy():
    iam_client = IAMClient()
    checker = IAMPasswordPolicyReuse24(iam_client)
    findings = checker.execute()
    for finding in findings:
        print(f"Status: {finding.status}, Detail: {finding.status_extended}")
    if any(finding.status == "FAIL" for finding in findings):
        if fixer(iam_client, iam_client.audited_account):
            reuse_logger.info("Password policy updated successfully.")
        else:
            reuse_logger.error("Failed to update password policy.")

def check_and_update_symbol_policy():
    status, message = check_symbol_policy()
    logger.info(f"Check status: {status}, Message: {message}")
    if status == "FAIL":
        success = update_symbol_policy()
        if success:
            logger.info("Password policy successfully updated.")
        else:
            logger.error("Failed to update password policy.")

def check_and_update_uppercase_policy():
    if not uppercase_policy.check_password_policy():
        uppercase_policy.update_password_policy()

def main():
    get_aws_credentials()  # AWS 자격 증명 설정
    check_no_root_access_key()
    manage_password_policy()
    lowercase_main()
    check_and_update_min_length_policy()
    check_and_update_number_policy()
    check_and_update_reuse_policy()
    check_and_update_symbol_policy()
    check_and_update_uppercase_policy()

if __name__ == "__main__":
    main()
