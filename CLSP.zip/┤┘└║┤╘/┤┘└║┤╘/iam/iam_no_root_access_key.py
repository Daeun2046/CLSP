import boto3  # AWS SDK for Python
from botocore.exceptions import ClientError  # 예외 처리용 모듈
import time  # 시간 지연을 위해 사용
import csv  # CSV 파싱용 모듈
from io import StringIO  # 문자열을 파일처럼 다루기 위한 모듈
import json
def iam_no_root_access_key(iam_client):
    try:
        # 자격 증명 보고서 생성 요청
        generate_report_response = iam_client.generate_credential_report()
        
        # 보고서가 생성될 때까지 대기
        while generate_report_response['State'] == 'STARTED':
            time.sleep(5)  # 5초 대기 후 다시 시도
            generate_report_response = iam_client.generate_credential_report()
        
        # 자격 증명 보고서 가져오기
        response = iam_client.get_credential_report()
        report_content = response['Content'].decode('utf-8')  # 보고서 내용을 UTF-8로 디코딩
        
        # 보고서를 CSV 형식으로 파싱
        reader = csv.DictReader(StringIO(report_content))  # CSV 내용을 딕셔너리 형식으로 읽기
        findings = []  # 결과를 저장할 리스트
        
        # 현재 계정 ID 가져오기
        account_id = iam_client.get_user()
        
        for row in reader:
            if row['user'] == '<root_account>':  # 루트 계정인 경우
                report = {
                    'region': 'global',  # 루트 계정은 글로벌 리소스
                    'resource_id': row['user'],  # 리소스 ID
                    'resource_arn': f'arn:aws:iam::{account_id}:root',  # 리소스 ARN
                    'status': '',  # 상태
                    'status_extended': ''  # 확장된 상태 설명
                }
                
                # 액세스 키 상태에 따른 보고서 업데이트
                if row['access_key_1_active'] == 'false' and row['access_key_2_active'] == 'false':
                    report['status'] = 'PASS'
                    report['status_extended'] = f"User {row['user']} does not have access keys."
                elif row['access_key_1_active'] == 'true' and row['access_key_2_active'] == 'true':
                    report['status'] = 'FAIL'
                    report['status_extended'] = f"User {row['user']} has two active access keys."
                else:
                    report['status'] = 'FAIL'
                    report['status_extended'] = f"User {row['user']} has one active access key."
                
                findings.append(report)  # 결과 리스트에 추가
        
        return findings  # 결과 반환
    
    except ClientError as e:  # 예외 처리
        error_code = e.response['Error']['Code']  # 에러 코드 가져오기
        if error_code == 'ReportNotPresent':
            print("Credential report is not present. Please generate the report and try again.")
        else:
            print(f"An error occurred: {e}")
        return []  # 빈 리스트 반환


def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4)

# 결과 실행 및 출력
if __name__ == "__main__":
    iam_client = boto3.client('iam',
                    aws_access_key_id="AKIAXYKJTDP3MQUIMI43",
                    aws_secret_access_key="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",
                    region_name='ap-northeast-2')
    result = iam_no_root_access_key(iam_client)
    save_findings_to_json(result, 'iam_no_root_access_key.json')
    print(f"Results saved to 'iam_no_root_access_key.json'.")
