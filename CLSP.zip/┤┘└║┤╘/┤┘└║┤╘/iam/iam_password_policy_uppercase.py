import boto3  # boto3 라이브러리를 가져옵니다.
import logging  # logging 라이브러리를 가져옵니다.

# 로깅 설정
logging.basicConfig(level=logging.INFO)  # 로깅 기본 설정을 INFO 레벨로 합니다.
logger = logging.getLogger()  # 로거 객체를 생성합니다.

# IAM 클라이언트 생성
iam_client = boto3.client('iam')  # boto3를 사용하여 IAM 클라이언트를 생성합니다.

# 비밀번호 정책 검사 함수
def check_password_policy():
    try:
        password_policy = iam_client.get_account_password_policy()  # 현재 계정의 비밀번호 정책을 가져옵니다.
        policy = password_policy['PasswordPolicy']  # 비밀번호 정책을 변수에 저장합니다.
        if policy.get('RequireUppercaseCharacters', False):  # 대문자 문자를 요구하는지 확인합니다.
            logger.info("PASS: IAM password policy requires at least one uppercase letter.")  # 요구한다면 PASS 로그를 기록합니다.
            return True  # 함수를 True로 반환합니다.
        else:
            logger.info("FAIL: IAM password policy does not require at least one uppercase letter.")  # 요구하지 않는다면 FAIL 로그를 기록합니다.
            return False  # 함수를 False로 반환합니다.
    except iam_client.exceptions.NoSuchEntityException:  # 비밀번호 정책이 없는 경우 예외를 처리합니다.
        logger.info("FAIL: No password policy found.")  # 정책이 없음을 로그로 기록합니다.
        return False  # 함수를 False로 반환합니다.
    except Exception as e:  # 그 외의 예외를 처리합니다.
        logger.error(f"Error checking password policy: {e}")  # 에러 내용을 로그로 기록합니다.
        return False  # 함수를 False로 반환합니다.

# 비밀번호 정책 수정 함수
def update_password_policy():
    try:
        # 현재 비밀번호 정책 가져오기
        current_policy = iam_client.get_account_password_policy()['PasswordPolicy']  # 현재 비밀번호 정책을 가져옵니다.
    except iam_client.exceptions.NoSuchEntityException:  # 비밀번호 정책이 없는 경우 예외를 처리합니다.
        # 비밀번호 정책이 없는 경우 기본값으로 설정
        current_policy = {  # 기본 비밀번호 정책을 설정합니다.
            'MinimumPasswordLength': 8,
            'RequireSymbols': True,
            'RequireNumbers': True,
            'RequireLowercaseCharacters': True,
            'AllowUsersToChangePassword': True,
            'MaxPasswordAge': 90,
            'PasswordReusePrevention': 5,
            'HardExpiry': False
        }
    except Exception as e:  # 그 외의 예외를 처리합니다.
        logger.error(f"Error fetching current password policy: {e}")  # 에러 내용을 로그로 기록합니다.
        return False  # 함수를 False로 반환합니다.

    try:
        # 비밀번호 정책 업데이트
        iam_client.update_account_password_policy(
            MinimumPasswordLength=current_policy.get('MinimumPasswordLength', 8),  # 최소 비밀번호 길이를 설정합니다.
            RequireSymbols=current_policy.get('RequireSymbols', True),  # 특수문자 요구 여부를 설정합니다.
            RequireNumbers=current_policy.get('RequireNumbers', True),  # 숫자 요구 여부를 설정합니다.
            RequireUppercaseCharacters=True,  # 대문자 문자를 요구하도록 설정합니다.
            RequireLowercaseCharacters=current_policy.get('RequireLowercaseCharacters', True),  # 소문자 요구 여부를 설정합니다.
            AllowUsersToChangePassword=current_policy.get('AllowUsersToChangePassword', True),  # 사용자 비밀번호 변경 허용 여부를 설정합니다.
            MaxPasswordAge=current_policy.get('MaxPasswordAge', 90),  # 최대 비밀번호 유효 기간을 설정합니다.
            PasswordReusePrevention=current_policy.get('PasswordReusePrevention', 5),  # 비밀번호 재사용 방지 횟수를 설정합니다.
            HardExpiry=current_policy.get('HardExpiry', False)  # 비밀번호 만료 시 강제 변경 여부를 설정합니다.
        )
        logger.info("Successfully updated the IAM password policy to require uppercase characters.")  # 정책 업데이트 성공 로그를 기록합니다.
        return True  # 함수를 True로 반환합니다.
    except Exception as e:  # 예외를 처리합니다.
        logger.error(f"Error updating password policy: {e}")  # 에러 내용을 로그로 기록합니다.
        return False  # 함수를 False로 반환합니다.
