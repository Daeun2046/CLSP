import boto3
import logging

# 로깅 설정
logger = logging.getLogger()
logger.setLevel(logging.INFO)

class IAMClient:
    def __init__(self):
        # IAM 클라이언트 생성
        self.client = boto3.client('iam')
        # 현재 세션의 리전 정보 가져오기
        self.region = boto3.Session().region_name
        # 현재 호출자의 계정 ID 가져오기
        self.audited_account = boto3.client('sts').get_caller_identity()['Account']
        # 패스워드 정책 가져오기
        self.password_policy = self.get_password_policy()
    
    def get_password_policy(self):
        try:
            # IAM 계정 패스워드 정책 가져오기
            response = self.client.get_account_password_policy()
            return response['PasswordPolicy']
        except self.client.exceptions.NoSuchEntityException:
            # 패스워드 정책이 없을 경우 에러 로그 출력
            logger.error("IAM 패스워드 정책이 설정되어 있지 않습니다.")
            return None
        except Exception as e:
            # 기타 예외 발생 시 에러 로그 출력
            logger.error(f"오류 발생: {str(e)}")
            return None

class Check:
    def metadata(self):
        return {
            "name": "iam_password_policy_reuse_24",
            "description": "Check if IAM password policy reuse prevention is set to 24."
        }

class Check_Report_AWS:
    def __init__(self, metadata):
        # 메타데이터 설정
        self.metadata = metadata
        # 리전, 리소스 ARN, 리소스 ID, 상태, 확장 상태 초기화
        self.region = None
        self.resource_arn = None
        self.resource_id = None
        self.status = None
        self.status_extended = None

class IAMPasswordPolicyReuse24(Check):
    def __init__(self, iam_client):
        self.iam_client = iam_client

    def execute(self):
        findings = []
        if self.iam_client.password_policy:
            # 보고서 객체 생성 및 메타데이터 설정
            report = Check_Report_AWS(self.metadata())
            # 리전 설정
            report.region = self.iam_client.region
            # 리소스 ARN 설정
            report.resource_arn = f"arn:aws:iam::{self.iam_client.audited_account}:root"
            # 리소스 ID 설정
            report.resource_id = self.iam_client.audited_account
            
            if "PasswordReusePrevention" in self.iam_client.password_policy:
                # 패스워드 재사용 방지 설정이 24인지 확인
                if self.iam_client.password_policy["PasswordReusePrevention"] == 24:
                    report.status = "PASS"
                    report.status_extended = (
                        "IAM password policy reuse prevention is equal to 24."
                    )
                else:
                    report.status = "FAIL"
                    report.status_extended = (
                        "IAM password policy reuse prevention is not equal to 24."
                    )
            else:
                report.status = "FAIL"
                report.status_extended = (
                    "IAM password policy reuse prevention is not set."
                )
            # 결과 추가
            findings.append(report)
        return findings

def fixer(iam_client: IAMClient, resource_id: str) -> bool:
    """
    Enable IAM password policy to prevent reusing the 24 previous passwords.
    Requires the iam:UpdateAccountPasswordPolicy permission.
    Returns:
        bool: True if IAM password policy is updated, False otherwise
    """
    try:
        # IAM 패스워드 정책 업데이트
        iam_client.client.update_account_password_policy(
            MinimumPasswordLength=iam_client.password_policy.get("MinimumPasswordLength", 8),
            RequireSymbols=iam_client.password_policy.get("RequireSymbols", True),
            RequireNumbers=iam_client.password_policy.get("RequireNumbers", True),
            RequireUppercaseCharacters=iam_client.password_policy.get("RequireUppercaseCharacters", True),
            RequireLowercaseCharacters=iam_client.password_policy.get("RequireLowercaseCharacters", True),
            AllowUsersToChangePassword=iam_client.password_policy.get("AllowUsersToChangePassword", True),
            MaxPasswordAge=iam_client.password_policy.get("MaxPasswordAge", 90),
            PasswordReusePrevention=24,
            HardExpiry=iam_client.password_policy.get("HardExpiry", False),
        )
    except Exception as error:
        # 예외 발생 시 에러 로그 출력 및 False 반환
        logger.error(
            f"{error.__class__.__name__}[{error.__traceback__.tb_lineno}]: {error}"
        )
        return False
    else:
        # 성공 시 True 반환
        return True
