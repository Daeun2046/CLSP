import boto3
import logging
from botocore.exceptions import ClientError

# 로깅 설정
logger = logging.getLogger()
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

# IAM 클라이언트 생성
iam_client = boto3.client('iam')

# IAM 비밀번호 정책 검사 및 수정 클래스
class IAMPasswordPolicyChecker:
    def __init__(self):
        # 초기화 메서드: 비밀번호 정책과 계정 ID를 가져옴
        self.password_policy = self.get_password_policy()
        self.account_id = self.get_account_id()

    def get_password_policy(self):
        try:
            # 비밀번호 정책을 가져옴
            response = iam_client.get_account_password_policy()
            return response['PasswordPolicy']
        except iam_client.exceptions.NoSuchEntityException:
            # 비밀번호 정책이 없을 경우
            logger.info("IAM 패스워드 정책이 설정되어 있지 않습니다.")
            return None
        except ClientError as e:
            # 기타 클라이언트 에러 처리
            logger.error(f"ClientError: {e.response['Error']['Message']}")
            return None
        except Exception as e:
            # 일반적인 예외 처리
            logger.error(f"오류 발생: {str(e)}")
            return None

    def get_account_id(self):
        try:
            # 계정 ID를 가져옴
            response = iam_client.get_caller_identity()
            return response['Account']
        except ClientError as e:
            # 클라이언트 에러 처리
            logger.error(f"ClientError: {e.response['Error']['Message']}")
            return None
        except Exception as e:
            # 일반적인 예외 처리
            logger.error(f"오류 발생: {str(e)}")
            return None

    def check_password_policy(self):
        # 비밀번호 정책을 확인하고 결과를 반환
        findings = []
        if self.password_policy:
            report = {
                'region': iam_client.meta.region_name,
                'resource_arn': f"arn:aws:iam::{self.account_id}:root",
                'resource_id': self.account_id,
                'status': '',
                'status_extended': ''
            }
            # 숫자 요구 사항 체크
            if self.password_policy.get('RequireNumbers', False):
                report['status'] = "PASS"
                report['status_extended'] = "IAM password policy requires at least one number."
            else:
                report['status'] = "FAIL"
                report['status_extended'] = "IAM password policy does not require at least one number."
            findings.append(report)
        else:
            # 비밀번호 정책이 없을 경우
            logger.info("IAM 패스워드 정책을 확인할 수 없습니다.")
        return findings

    def fix_password_policy(self):
        # 비밀번호 정책을 수정하는 메서드
        if not self.password_policy:
            logger.info("IAM 패스워드 정책이 설정되어 있지 않아 기본 정책을 설정합니다.")
            self.password_policy = {}

        try:
            # 비밀번호 정책을 업데이트
            iam_client.update_account_password_policy(
                MinimumPasswordLength=self.password_policy.get('MinimumPasswordLength', 8),
                RequireSymbols=self.password_policy.get('RequireSymbols', False),
                RequireNumbers=True,  # 숫자 요구 사항을 True로 설정
                RequireUppercaseCharacters=self.password_policy.get('RequireUppercaseCharacters', False),
                RequireLowercaseCharacters=self.password_policy.get('RequireLowercaseCharacters', False),
                AllowUsersToChangePassword=self.password_policy.get('AllowUsersToChangePassword', True),
                MaxPasswordAge=self.password_policy.get('MaxPasswordAge', 90),
                PasswordReusePrevention=self.password_policy.get('PasswordReusePrevention', 24),
                HardExpiry=self.password_policy.get('HardExpiry', False),
            )
        except ClientError as e:
            # 클라이언트 에러 처리
            logger.error(f"ClientError: {e.response['Error']['Message']}")
            return False
        except Exception as error:
            # 일반적인 예외 처리
            logger.error(f"{error.__class__.__name__}[{error.__traceback__.tb_lineno}]: {error}")
            return False
        else:
            return True
