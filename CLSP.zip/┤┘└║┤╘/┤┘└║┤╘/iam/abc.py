import boto3
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError

def get_aws_client(service, access_key=None, secret_key=None):
    if access_key and secret_key:
        return boto3.client(service, aws_access_key_id=access_key, aws_secret_access_key=secret_key)
    else:
        try:
            client = boto3.client(service)
            # 테스트 호출로 자격 증명 확인 (STS 클라이언트 사용)
            sts_client = boto3.client('sts')
            sts_client.get_caller_identity()
            return client
        except (NoCredentialsError, PartialCredentialsError):
            return None
        except ClientError as e:
            if e.response['Error']['Code'] == 'ExpiredToken':
                print("자격 증명이 만료되었습니다.")
                return None
            else:
                raise e

def check_password_policy(iam_client):
    try:
        password_policy = iam_client.get_account_password_policy()['PasswordPolicy']
        policy_name = "PasswordPolicy"
        max_age = password_policy.get('MaxPasswordAge')
        if max_age is None:
            return policy_name, "FAIL", "Password expiration is not set."
        elif max_age <= 90:
            return policy_name, "PASS", f"Password expiration is set lower than 90 days ({max_age} days)."
        else:
            return policy_name, "FAIL", f"Password expiration is set greater than 90 days ({max_age} days)."
    except ClientError as e:
        if e.response['Error']['Code'] == 'NoSuchEntity':
            return "PasswordPolicy", "FAIL", "Password policy is not set."
        else:
            raise e

if __name__ == "__main__":
    iam_client = boto3.client('iam',
                aws_access_key_id="AKIAXYKJTDP3MQUIMI43",
                aws_secret_access_key="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",
                region_name='ap-northeast-2')
    results = check_password_policy(iam_client)
    with open('abc.json', 'w') as json_file:
        json.dump(results, json_file, indent=4)