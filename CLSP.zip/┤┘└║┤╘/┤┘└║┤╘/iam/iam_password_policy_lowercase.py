import boto3  # AWS SDK for Python (Boto3) 임포트
import logging  # 로깅 모듈 임포트

# 로거 설정
logger = logging.getLogger()  # 로거 객체 생성
logger.setLevel(logging.INFO)  # 로깅 레벨을 INFO로 설정

# AWS IAM 클라이언트 생성
iam_client = boto3.client('iam')  # IAM 클라이언트 객체 생성

def get_user_arn() -> str:
    """현재 사용자 ARN을 반환합니다."""
    try:
        user_arn = iam_client.get_user()["User"]["Arn"]  # 현재 사용자 정보에서 ARN 가져오기
        return user_arn  # ARN 반환
    except Exception as e:
        logger.error(f"사용자 ARN을 가져오는 중 오류가 발생했습니다: {e}")  # 오류 발생 시 로그 기록
        return None  # 오류 발생 시 None 반환

def check_password_policy() -> list:
    """
    IAM 비밀번호 정책에서 소문자 문자를 요구하는지 여부를 확인합니다.
    Returns:
        list: 검사 결과
    """
    findings = []  # 결과를 저장할 리스트 초기화
    try:
        # 현재 비밀번호 정책 가져오기
        response = iam_client.get_account_password_policy()  # 계정 비밀번호 정책 가져오기
        password_policy = response['PasswordPolicy']  # 비밀번호 정책 정보 추출
        
        user_arn = get_user_arn()  # 현재 사용자 ARN 가져오기
        if not user_arn:
            return findings  # 사용자 ARN을 가져오지 못한 경우, 빈 리스트 반환

        account_id = user_arn.split(":")[4]  # 사용자 ARN에서 계정 ID 추출
        finding = {
            'region': iam_client.meta.region_name,  # 클라이언트의 리전 정보
            'resource_arn': f'arn:aws:iam::{account_id}:policy/PasswordPolicy',  # 비밀번호 정책의 ARN
            'resource_id': account_id,  # 계정 ID
            'status': 'PASS' if password_policy.get('RequireLowercaseCharacters', False) else 'FAIL',  # 정책 상태
            'status_extended': 'IAM password policy requires at least one lowercase letter.' if password_policy.get('RequireLowercaseCharacters', False) else 'IAM password policy does not require at least one lowercase letter.'  # 상태 설명
        }
        findings.append(finding)  # 결과 리스트에 추가
    except iam_client.exceptions.NoSuchEntityException:
        logger.warning("No password policy found.")  # 비밀번호 정책이 없을 때 경고 로그 기록
        findings.append({
            'region': iam_client.meta.region_name,  # 클라이언트의 리전 정보
            'resource_arn': 'N/A',  # 리소스 ARN 없음
            'resource_id': 'N/A',  # 리소스 ID 없음
            'status': 'FAIL',  # 상태: 실패
            'status_extended': 'No IAM password policy found.'  # 상태 설명
        })
    except Exception as e:
        logger.error(f"Error checking password policy: {e}")  # 기타 오류 발생 시 로그 기록
    
    return findings  # 결과 반환

def update_password_policy() -> bool:
    """
    IAM 비밀번호 정책을 수정하여 소문자 문자를 요구하도록 설정합니다.
    Returns:
        bool: 정책 업데이트 성공 여부
    """
    try:
        # 현재 비밀번호 정책 가져오기
        response = iam_client.get_account_password_policy()  # 계정 비밀번호 정책 가져오기
        password_policy = response['PasswordPolicy']  # 비밀번호 정책 정보 추출
        
        # 비밀번호 정책 업데이트
        iam_client.update_account_password_policy(
            MinimumPasswordLength=password_policy.get('MinimumPasswordLength', 8),  # 최소 비밀번호 길이
            RequireSymbols=password_policy.get('RequireSymbols', False),  # 특수문자 요구 여부
            RequireNumbers=password_policy.get('RequireNumbers', False),  # 숫자 요구 여부
            RequireUppercaseCharacters=password_policy.get('RequireUppercaseCharacters', False),  # 대문자 요구 여부
            RequireLowercaseCharacters=True,  # 소문자 요구 여부 (항상 True로 설정)
            AllowUsersToChangePassword=password_policy.get('AllowUsersToChangePassword', True),  # 사용자 비밀번호 변경 허용 여부
            MaxPasswordAge=password_policy.get('MaxPasswordAge', 90),  # 비밀번호 최대 사용 기간
            PasswordReusePrevention=password_policy.get('PasswordReusePrevention', 5),  # 비밀번호 재사용 방지 횟수
            HardExpiry=password_policy.get('HardExpiry', False),  # 강제 만료 여부
        )
        logger.info("Password policy updated to require lowercase characters.")  # 업데이트 성공 로그 기록
        return True  # 성공 시 True 반환
    except iam_client.exceptions.NoSuchEntityException:
        logger.warning("No password policy found to update.")  # 비밀번호 정책이 없을 때 경고 로그 기록
        return False  # 실패 시 False 반환
    except Exception as e:
        logger.error(f"Error updating password policy: {e}")  # 기타 오류 발생 시 로그 기록
        return False  # 실패 시 False 반환

def main():
    # 비밀번호 정책 검사
    findings = check_password_policy()  # 비밀번호 정책 검사 결과 가져오기
    for finding in findings:
        logger.info(f"Finding: {finding}")  # 검사 결과 로그 기록

    # 비밀번호 정책 업데이트
    if any(finding['status'] == 'FAIL' for finding in findings):  # 검사 결과 중 실패가 있는 경우
        if update_password_policy():  # 비밀번호 정책 업데이트 시도
            logger.info("Password policy was successfully updated.")  # 업데이트 성공 로그 기록
        else:
            logger.error("Failed to update the password policy.")  # 업데이트 실패 로그 기록
