import json
import iam_no_root_access_key
import iam_password_policy_expires_passwords_within_90_days_or_less
import iam_password_policy_lowercase
import iam_password_policy_minimum_length_14
import iam_password_policy_number
import iam_password_policy_reuse_24
import iam_password_policy_symbol
import iam_password_policy_uppercase


def main():
    results = []

    # Run iam_no_root_access_key
    print("Running iam_no_root_access_key.py...")
    access_key_usage_findings = iam_no_root_access_key.iam_no_root_access_key()
    for finding in access_key_usage_findings:
        result = {
            'Object_name': finding['object_name'],
            'arn': finding['arn'],
            'region': finding['region'],
            'tag': finding['tag'],
            'policy_name': finding['policy_name'],
            'status': finding['status'],
            'status_extended': finding['status_extended']
        }
        results.append(result)
    print()

    # Run iam_password_policy_expires_passwords_within_90_days_or_less
    print("Running iam_password_policy_expires_passwords_within_90_days_or_less.py...")
    password_policy_manager = iam_password_policy_expires_passwords_within_90_days_or_less.IAMPasswordPolicyManager()
    password_policy_manager.check_password_policy()
    print()

    # Run iam_password_policy_lowercase
    print("Running iam_password_policy_lowercase.py...")
    password_policy_manager_lowercase = iam_password_policy_lowercase.IAMPasswordPolicyManager()
    password_policy_manager_lowercase.check_password_policy()
    print()

    # Run iam_password_policy_minimum_length_14
    print("Running iam_password_policy_minimum_length_14.py...")
    password_policy_manager_min_length = iam_password_policy_minimum_length_14.IAMPasswordPolicyManager()
    password_policy_manager_min_length.check_password_policy_minimum_length_14()
    print()

    # Run iam_password_policy_number
    print("Running iam_password_policy_number.py...")
    password_policy_manager_number = iam_password_policy_number.IAMPasswordPolicyManager()
    password_policy_manager_number.check_password_policy_requires_number()
    print()

    # Run iam_password_policy_reuse_24
    print("Running iam_password_policy_reuse_24.py...")
    password_policy_manager_reuse = iam_password_policy_reuse_24.IAMPasswordPolicyManager()
    password_policy_manager_reuse.check_password_policy_prevents_reuse_24_months()
    print()

    # Run iam_password_policy_symbol
    print("Running iam_password_policy_symbol.py...")
    password_policy_manager_symbol = iam_password_policy_symbol.IAMPasswordPolicyManager()
    password_policy_manager_symbol.check_password_policy_requires_symbol()
    print()

    # Run iam_password_policy_uppercase
    print("Running iam_password_policy_uppercase.py...")
    password_policy_manager_uppercase = iam_password_policy_uppercase.IAMPasswordPolicyManager()
    password_policy_manager_uppercase.check_password_policy_requires_uppercase()
    print()

    # Save results to a JSON file
    with open('results.json', 'w') as json_file:
        json.dump(results, json_file, indent=4)

if __name__ == "__main__":
    main()
