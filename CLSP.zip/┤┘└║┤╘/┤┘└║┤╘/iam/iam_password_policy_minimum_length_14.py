import boto3
from botocore.exceptions import ClientError

# AWS IAM 클라이언트 생성
iam_client = boto3.client('iam')

def check_password_policy_minimum_length_14():
    findings = []  # 결과를 저장할 리스트 초기화
    try:
        # 현재 비밀번호 정책 가져오기
        password_policy = iam_client.get_account_password_policy()['PasswordPolicy']
        
        # 체크 리포트 생성
        report = {
            "region": iam_client.meta.region_name,  # 현재 클라이언트의 리전 정보
            "resource_arn": "arn:aws:iam::{}:policy/PasswordPolicy".format(iam_client.get_caller_identity()["Account"]),  # 리소스 ARN
            "resource_id": iam_client.get_caller_identity()["Account"],  # 계정 ID
        }

        # 비밀번호 정책 길이 검사
        if password_policy.get('MinimumPasswordLength', 0) >= 14:
            report["status"] = "PASS"  # 정책이 14자 이상이면 PASS
            report["status_extended"] = "IAM password policy requires minimum length of 14 characters."
        else:
            report["status"] = "FAIL"  # 정책이 14자 미만이면 FAIL
            report["status_extended"] = "IAM password policy does not require minimum length of 14 characters."
        
        findings.append(report)  # 결과 리스트에 리포트 추가
    except ClientError as error:
        # 비밀번호 정책이 존재하지 않을 경우 예외 처리
        if error.response['Error']['Code'] == 'NoSuchEntity':
            findings.append({
                "status": "FAIL",  # 정책이 없으면 FAIL
                "status_extended": "IAM password policy does not exist.",
                "region": iam_client.meta.region_name,  # 현재 클라이언트의 리전 정보
                "resource_arn": "arn:aws:iam::{}:policy/PasswordPolicy".format(iam_client.get_caller_identity()["Account"]),  # 리소스 ARN
                "resource_id": iam_client.get_caller_identity()["Account"],  # 계정 ID
            })
        else:
            print(f"Unexpected error: {error}")  # 기타 예외 처리
    
    return findings  # 결과 반환

def fixer():
    """
    Enable IAM password policy to require a minimum password length of 14 characters.
    Requires the iam:UpdateAccountPasswordPolicy permission.
    """
    try:
        # 비밀번호 정책 업데이트
        iam_client.update_account_password_policy(
            MinimumPasswordLength=14,  # 최소 비밀번호 길이 14자
            RequireSymbols=True,  # 기호 필수
            RequireNumbers=True,  # 숫자 필수
            RequireUppercaseCharacters=True,  # 대문자 필수
            RequireLowercaseCharacters=True,  # 소문자 필수
            AllowUsersToChangePassword=True,  # 사용자가 비밀번호 변경 가능
            MaxPasswordAge=90,  # 비밀번호 최대 사용 기간 90일
            PasswordReusePrevention=24,  # 비밀번호 재사용 방지 개수 24개
            HardExpiry=False  # 비밀번호 만료 시 계정 잠금 비활성화
        )
        return True  # 업데이트 성공 시 True 반환
    except ClientError as error:
        print(f"Error updating password policy: {error}")  # 예외 발생 시 에러 메시지 출력
        return False  # 업데이트 실패 시 False 반환
