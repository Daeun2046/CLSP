import boto3
import json
from botocore.exceptions import ClientError

# Function to print items in a bordered box
def print_in_box(lines):
    max_length = max(len(f"{index + 1}. {line}") for index, line in enumerate(lines))
    print('╔' + '═' * (max_length + 2) + '╗')
    for index, line in enumerate(lines):
        print(f'║ {index + 1}. {line.ljust(max_length - len(f"{index + 1}. "))} ║')
    print('╚' + '═' * (max_length + 2) + '╝')

# Function to retrieve S3 client and selected buckets
def s3_client_info():
    s3_client = boto3.client('s3')
    response = s3_client.list_buckets()
    buckets = response['Buckets']
    bucket_names = [bucket['Name'] for bucket in buckets]
    print("Choose the buckets you want to check:\n")
    print("0. All buckets")
    print_in_box(bucket_names)
    
    while True:
        try:
            selection = int(input("Enter the bucket number (0 for all): "))
            if selection == 0:
                selected_buckets = bucket_names
                break
            elif 1 <= selection <= len(bucket_names):
                selected_buckets = [bucket_names[selection - 1]]
                break
            else:
                print("Please enter a valid number.")
        except ValueError:
            print("Please enter a number.")

    print(f"Selected buckets: {', '.join(selected_buckets)}")
    return s3_client, selected_buckets

# Function to run S3 checks
def run_s3_checks(s3_client, selected_buckets):
    results = {}

    for bucket_name in selected_buckets:
        results[bucket_name] = {}

        # Retrieve results for each check
        encryption = s3_bucket_default_encryption.s3_bucket_encryption(s3_client, [bucket_name])
        results[bucket_name]['encryption'] = encryption

        object_lock = s3_bucket_object_lock.s3_bucket_object_lock(s3_client, [bucket_name])
        results[bucket_name]['object_lock'] = object_lock

        mfa_delete = s3_bucket_no_mfa_delete.s3_bucket_no_mfa_delete(s3_client, [bucket_name])
        results[bucket_name]['mfa_delete'] = mfa_delete

        public_access = s3_bucket_public_access.s3_bucket_public_access(s3_client, [bucket_name])
        results[bucket_name]['public_access'] = public_access

        secure_transport = s3_bucket_secure_transport_policy.s3_bucket_secure_transport_policy(s3_client, [bucket_name])
        results[bucket_name]['secure_transport'] = secure_transport

        public_write_access = s3_bucket_policy_public_write_access.s3_bucket_policy_public_write_access(s3_client, [bucket_name])
        results[bucket_name]['public_write_access'] = public_write_access

    return results

# Main execution
if __name__ == "__main__":
    s3_client, selected_buckets = s3_client_info()
    results = run_s3_checks(s3_client, selected_buckets)

    # Write results to JSON file
    with open('s3_bucket_results.json', 'w') as json_file:
        json.dump(results, json_file, indent=4, ensure_ascii=False)
    
    print("Results have been saved to s3_bucket_results.json.")
