import boto3
import json
from botocore.exceptions import ClientError

class S3BucketSecureTransportCSPMCheck:
    def run(self):
        findings = []
        # Retrieve all buckets using boto3
        s3_client = boto3.client('s3')
        buckets = s3_client.list_buckets()['Buckets']
        
        for bucket in buckets:
            bucket_name = bucket['Name']
            bucket_region = s3_client.get_bucket_location(Bucket=bucket_name)['LocationConstraint']
            bucket_arn = f"arn:aws:s3:::{bucket_name}"
            bucket_tags = self._get_bucket_tags(s3_client, bucket_name)

            # Evaluate bucket policy for secure transport
            report = self._evaluate_bucket_policy(s3_client, bucket_name, bucket_region, bucket_arn, bucket_tags)
            findings.append(report)

        return findings

    def _evaluate_bucket_policy(self, s3_client, bucket_name, bucket_region, bucket_arn, bucket_tags):
        report = {
            'Region': bucket_region,
            'ResourceID': bucket_name,
            'ResourceARN': bucket_arn,
            'ResourceTags': bucket_tags,
        }

        try:
            bucket_policy = s3_client.get_bucket_policy(Bucket=bucket_name).get('Policy', None)
            if not bucket_policy:
                report['Status'] = "FAIL"
                report['StatusDetails'] = f"S3 bucket '{bucket_name}' does not have a bucket policy, thus it allows HTTP requests. It is recommended to enforce secure transport (HTTPS) in the bucket policy."
            else:
                policy = json.loads(bucket_policy)
                if self._is_policy_secure(policy):
                    report['Status'] = "PASS"
                    report['StatusDetails'] = f"S3 bucket '{bucket_name}' has a bucket policy to deny requests over insecure transport, ensuring data is transmitted securely."
                else:
                    report['Status'] = "FAIL"
                    report['StatusDetails'] = f"S3 bucket '{bucket_name}' allows requests over insecure transport in the bucket policy. It is recommended to update the policy to enforce secure transport (HTTPS)."
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchBucketPolicy':
                report['Status'] = "FAIL"
                report['StatusDetails'] = f"S3 bucket '{bucket_name}' does not have a bucket policy, thus it allows HTTP requests. It is recommended to enforce secure transport (HTTPS) in the bucket policy."
            else:
                report['Status'] = "ERROR"
                report['StatusDetails'] = f"An error occurred while checking the policy for bucket '{bucket_name}': {str(e)}"
        except Exception as e:
            report['Status'] = "ERROR"
            report['StatusDetails'] = f"An error occurred while checking the policy for bucket '{bucket_name}': {str(e)}"

        return report

    def _is_policy_secure(self, policy):
        for statement in policy.get("Statement", []):
            if statement.get("Effect") == "Deny" and "Condition" in statement:
                condition = statement["Condition"]
                if ("Bool" in condition and "aws:SecureTransport" in condition["Bool"]
                        and condition["Bool"]["aws:SecureTransport"] == "false"):
                    return True
        return False

    def _get_bucket_tags(self, s3_client, bucket_name):
        try:
            response = s3_client.get_bucket_tagging(Bucket=bucket_name)
            return response['TagSet']
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchTagSet':
                return []
            else:
                raise e
        except Exception as e:
            raise e

# Example usage:
if __name__ == "__main__":
    checker = S3BucketSecureTransportCSPMCheck()
    results = checker.run()
    for result in results:
        print(f"Status: {result['Status']}, Details: {result['StatusDetails']}, Region: {result['Region']}, ResourceID: {result['ResourceID']}, ResourceARN: {result['ResourceARN']}, ResourceTags: {result['ResourceTags']}")
