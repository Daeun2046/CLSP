import boto3
from botocore.exceptions import ClientError

class S3PublicAccessCSPMCheck:
    def run(self):
        findings = []
        
        # Check account-level S3 public access block settings
        try:
            s3control_client = boto3.client('s3control')
            account_access_block = s3control_client.get_public_access_block(AccountId='audited_account_id')
            account_access_block_config = account_access_block.get('PublicAccessBlockConfiguration', {})
            if account_access_block_config.get('IgnorePublicAcls') and account_access_block_config.get('RestrictPublicBuckets'):
                findings.append(self._create_report("PASS", "All S3 public access is blocked at account level.", 'region', 'audited_account_id', f"arn:aws:s3:::audited_account_id"))
                return findings
        except Exception as e:
            findings.append(self._create_report("ERROR", f"Error retrieving account-level public access block settings: {str(e)}", 'region', 'audited_account_id', f"arn:aws:s3:::audited_account_id"))

        # If account-level public access is not blocked, check each bucket
        for bucket_name in self._list_buckets():
            try:
                report_status, status_extended = self._check_bucket_public_access(bucket_name)
                findings.append(self._create_report(report_status, status_extended, 'region', bucket_name, f"arn:aws:s3:::{bucket_name}", self._get_bucket_tags(bucket_name)))
            except Exception as e:
                findings.append(self._create_report("ERROR", f"Error retrieving public access settings for S3 bucket {bucket_name}: {str(e)}", 'region', bucket_name, f"arn:aws:s3:::{bucket_name}"))

        return findings

    def _create_report(self, status, status_extended, region, resource_id, resource_arn, tags=None):
        report = {
            'Status': status,
            'Details': status_extended,
            'Region': region,
            'ResourceID': resource_id,
            'ResourceARN': resource_arn,
            'ResourceTags': tags or {}
        }
        return report

    def _list_buckets(self):
        s3_client = boto3.client('s3')
        response = s3_client.list_buckets()
        buckets = [bucket['Name'] for bucket in response.get('Buckets', [])]
        return buckets

    def _check_bucket_public_access(self, bucket_name):
        s3_client = boto3.client('s3')

        try:
            # Get bucket public access block configuration
            public_access_block = s3_client.get_public_access_block(Bucket=bucket_name).get('PublicAccessBlockConfiguration', {})
            bucket_acl = s3_client.get_bucket_acl(Bucket=bucket_name).get('Grants', [])
            bucket_policy = s3_client.get_bucket_policy(Bucket=bucket_name).get('Policy', {})

            is_public = False
            status_extended = f"S3 bucket {bucket_name} is not publicly accessible."

            # Check if public access block is disabled
            if not (
                public_access_block.get('IgnorePublicAcls', False)
                and public_access_block.get('RestrictPublicBuckets', False)
            ):
                # Check bucket ACL
                for grantee in bucket_acl:
                    if grantee.get('Grantee', {}).get('Type') == 'Group':
                        if grantee['Grantee'].get('URI') in ('http://acs.amazonaws.com/groups/global/AllUsers', 'http://acs.amazonaws.com/groups/global/AuthenticatedUsers'):
                            is_public = True
                            return "FAIL", f"S3 bucket {bucket_name} is publicly accessible due to bucket ACL."

                # Check bucket policy
                if not is_public:
                    statements = bucket_policy.get('Statement', [])
                    for statement in statements:
                        if (
                            statement.get('Principal') == '*'
                            and statement.get('Effect') == 'Allow'
                        ):
                            return "FAIL", f"S3 bucket {bucket_name} is publicly accessible due to bucket policy."
                        elif (
                            statement.get('Principal', {}).get('AWS') == '*'
                            and statement.get('Effect') == 'Allow'
                        ):
                            return "FAIL", f"S3 bucket {bucket_name} is publicly accessible due to bucket policy."

            return "PASS", status_extended
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchBucketPolicy':
                return "PASS", f"S3 bucket {bucket_name} does not have a bucket policy."
            else:
                return "ERROR", f"Error retrieving public access settings for S3 bucket {bucket_name}: {str(e)}"
        except Exception as e:
            return "ERROR", f"Error retrieving public access settings for S3 bucket {bucket_name}: {str(e)}"

    def _get_bucket_tags(self, bucket_name):
        s3_client = boto3.client('s3')

        try:
            bucket_tags = s3_client.get_bucket_tagging(Bucket=bucket_name).get('TagSet', [])
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchTagSet':
                bucket_tags = []
            else:
                raise e

        return bucket_tags

# Example usage:
if __name__ == "__main__":
    checker = S3PublicAccessCSPMCheck()
    results = checker.run()
    for result in results:
        print(f"Status: {result['Status']}, Details: {result['Details']}, Region: {result['Region']}, ResourceID: {result['ResourceID']}, ResourceARN: {result['ResourceARN']}, ResourceTags: {result['ResourceTags']}")
