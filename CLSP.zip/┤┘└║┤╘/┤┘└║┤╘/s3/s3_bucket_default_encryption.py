import boto3
from botocore.exceptions import ClientError

# Simplified CheckReportAWS class
class CheckReportAWS:
    def __init__(self, metadata):
        self.metadata = metadata
        self.resource_id = None
        self.resource_arn = None
        self.status = None
        self.status_extended = None

# Example S3BucketEncryptionCSPMCheck without using prowler.lib.check.models
class S3BucketEncryptionCSPMCheck:
    def __init__(self):
        pass

    def run(self):
        findings = []
        s3_client = boto3.client('s3')
        kms_client = boto3.client('kms')

        # Get list of all buckets
        response = s3_client.list_buckets()
        buckets = response['Buckets']

        for bucket in buckets:
            bucket_name = bucket['Name']
            report = CheckReportAWS(self.metadata())  # Initialize CheckReportAWS object
            report.resource_id = bucket_name
            report.resource_arn = f"arn:aws:s3:::{bucket_name}"

            try:
                # Get bucket encryption configuration
                encryption_config = s3_client.get_bucket_encryption(Bucket=bucket_name)
                rules = encryption_config.get('ServerSideEncryptionConfiguration', {}).get('Rules', [])

                if rules:
                    encryption_type = rules[0].get('ApplyServerSideEncryptionByDefault', {}).get('SSEAlgorithm', 'Unknown')
                    encryption_status = "PASS"
                    encryption_details = f"S3 Bucket {bucket_name} has Server Side Encryption with {encryption_type}."

                    # Check if encryption uses AWS KMS
                    if encryption_type == 'aws:kms':
                        kms_key_id = rules[0]['ApplyServerSideEncryptionByDefault'].get('KMSMasterKeyID')
                        kms_key_status = self.check_kms_key_status(kms_client, kms_key_id)
                        if kms_key_status != 'Enabled':
                            encryption_status = "FAIL"
                            encryption_details += f" However, the KMS key {kms_key_id} is not enabled."
                else:
                    encryption_status = "FAIL"
                    encryption_details = f"S3 Bucket {bucket_name} does not have Server Side Encryption enabled."

            except ClientError as e:
                if e.response['Error']['Code'] == 'NoSuchBucketEncryption':
                    encryption_status = "FAIL"
                    encryption_details = f"S3 Bucket {bucket_name} does not have Server Side Encryption enabled."
                else:
                    encryption_status = "ERROR"
                    encryption_details = str(e)

            except Exception as e:
                encryption_status = "ERROR"
                encryption_details = str(e)

            # Assign status and details to report object
            report.status = encryption_status
            report.status_extended = encryption_details
            findings.append(report)

        return findings

    def check_kms_key_status(self, kms_client, kms_key_id):
        try:
            kms_key = kms_client.describe_key(KeyId=kms_key_id)
            return kms_key['KeyMetadata']['KeyState']
        except ClientError as e:
            return str(e)

# Example usage:
if __name__ == "__main__":
    checker = S3BucketEncryptionCSPMCheck()
    results = checker.run()
    for result in results:
        print(f"Bucket ID: {result.resource_id}, Status: {result.status}, Details: {result.status_extended}")
