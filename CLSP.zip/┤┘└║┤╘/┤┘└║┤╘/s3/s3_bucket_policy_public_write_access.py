import boto3
from botocore.exceptions import ClientError
import json

class S3BucketPublicWriteCheck:
    def execute(self):
        findings = []
        s3_client = boto3.client('s3')
        s3control_client = boto3.client('s3control')

        # Check if account-level public bucket access restriction is enabled
        try:
            account_access_block = s3control_client.get_public_access_block(AccountId='audited_account_id')
            account_access_block_config = account_access_block.get('PublicAccessBlockConfiguration', {})
            if account_access_block_config.get('IgnorePublicAcls') and account_access_block_config.get('RestrictPublicBuckets'):
                findings.append(self._create_report("PASS", 'region', 'audited_account_id', "All S3 public access blocked at account level."))
                return findings
        except Exception as e:
            findings.append(self._create_report("ERROR", 'region', 'audited_account_id', f"Error retrieving account-level public access block: {str(e)}"))

        # If account-level public access is not blocked, check each bucket
        try:
            buckets = s3_client.list_buckets()['Buckets']
            for bucket in buckets:
                try:
                    bucket_name = bucket['Name']
                    bucket_policy_findings = self._check_bucket_policy(s3_client, bucket_name)
                    findings.extend(bucket_policy_findings)
                except Exception as e:
                    findings.append(self._create_report("ERROR", bucket['Region'], bucket_name, f"Error checking bucket {bucket_name}: {str(e)}"))
        except Exception as e:
            findings.append(self._create_report("ERROR", 'region', 'audited_account_id', f"Error listing S3 buckets: {str(e)}"))

        return findings

    def _check_bucket_policy(self, s3_client, bucket_name):
        findings = []

        try:
            bucket_policy = s3_client.get_bucket_policy(Bucket=bucket_name)
            policy = json.loads(bucket_policy['Policy'])
            policy_statements = policy['Statement']

            for statement in policy_statements:
                if (
                    statement["Effect"] == "Allow"
                    and "Condition" not in statement
                    and (
                        "Principal" in statement
                        and "*" in str(statement["Principal"])
                    )
                    and (
                        (
                            isinstance(statement["Action"], list)
                            and (
                                "s3:PutObject" in statement["Action"]
                                or "*" in statement["Action"]
                                or "s3:*" in statement["Action"]
                                or "s3:Put*" in statement["Action"]
                            )
                        )
                        or (
                            isinstance(statement["Action"], str)
                            and (
                                "s3:PutObject" == statement["Action"]
                                or "*" == statement["Action"]
                                or "s3:*" == statement["Action"]
                                or "s3:Put*" == statement["Action"]
                            )
                        )
                    )
                ):
                    status = "FAIL"
                    status_extended = f"S3 Bucket {bucket_name} allows public write access in the bucket policy."
                    findings.append(self._create_report(status, 'region', bucket_name, status_extended))
                    break
            else:
                status = "PASS"
                status_extended = f"S3 Bucket {bucket_name} does not allow public write access in the bucket policy."
                findings.append(self._create_report(status, 'region', bucket_name, status_extended))

        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchBucketPolicy':
                status = "PASS"
                status_extended = f"S3 Bucket {bucket_name} does not have a bucket policy."
                findings.append(self._create_report(status, 'region', bucket_name, status_extended))
            else:
                status = "ERROR"
                status_extended = f"Error retrieving policy for bucket {bucket_name}: {str(e)}"
                findings.append(self._create_report(status, 'region', bucket_name, status_extended))

        except Exception as e:
            status = "ERROR"
            status_extended = f"Error checking bucket policy for {bucket_name}: {str(e)}"
            findings.append(self._create_report(status, 'region', bucket_name, status_extended))

        return findings

    def _create_report(self, status, region, resource_id, status_extended):
        report = {
            'Bucket': resource_id,
            'Status': status,
            'Details': status_extended,
            'ARN': f"arn:aws:s3:::{resource_id}",
            'Region': region,
            'Tags': []  # Placeholder for tags retrieval
        }
        return report

# Example usage:
if __name__ == "__main__":
    checker = S3BucketPublicWriteCheck()
    results = checker.execute()
    for result in results:
        print(f"Bucket ID: {result['Bucket']}, Status: {result['Status']}, Details: {result['Details']}, ARN: {result['ARN']}, Region: {result['Region']}, Tags: {result['Tags']}")
