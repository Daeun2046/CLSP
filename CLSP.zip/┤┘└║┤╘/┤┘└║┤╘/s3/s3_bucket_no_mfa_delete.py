import boto3
from botocore.exceptions import ClientError


def s3_bucket_no_mfa_delete(s3_client):
    findings = []

    # Get list of all buckets
    response = s3_client.list_buckets()
    buckets = response['Buckets']

    for bucket in buckets:
        bucket_name = bucket['Name']
        try:
            # Get bucket versioning configuration
            versioning_config = s3_client.get_bucket_versioning(Bucket=bucket_name)
            mfa_delete_enabled = versioning_config.get('MFADelete', 'Disabled')

            if mfa_delete_enabled == 'Enabled':
                status = 'PASS'
                status_extended = f"S3 Bucket {bucket_name} has MFA Delete enabled."
            else:
                status = 'FAIL'
                status_extended = f"S3 Bucket {bucket_name} has MFA Delete disabled."

            # Get bucket ARN and region
            bucket_region = s3_client.get_bucket_location(Bucket=bucket_name)['LocationConstraint']
            bucket_arn = f"arn:aws:s3:::{bucket_name}" if bucket_region is None else f"arn:aws:s3::{bucket_region}:{bucket_name}"

            # Get bucket tags
            try:
                bucket_tags = s3_client.get_bucket_tagging(Bucket=bucket_name)['TagSet']
            except ClientError as e:
                if e.response['Error']['Code'] == 'NoSuchTagSet':
                    bucket_tags = []
                else:
                    raise

            findings.append({
                'Bucket': bucket_name,
                'Status': status,
                'Details': status_extended,
                'ARN': bucket_arn,
                'Region': bucket_region,
                'Tags': bucket_tags
            })

        except ClientError as e:
            status = 'ERROR'
            status_extended = f"Error retrieving versioning status for bucket {bucket_name}: {str(e)}"
            findings.append({
                'Bucket': bucket_name,
                'Status': status,
                'Details': status_extended,
                'ARN': None,
                'Region': None,
                'Tags': []
            })

    return findings


# Example usage:
if __name__ == "__main__":
    s3_client = boto3.client('s3')
    results = s3_bucket_no_mfa_delete(s3_client)
    for result in results:
        print(f"Bucket ID: {result['Bucket']}, Status: {result['Status']}, Details: {result['Details']}, ARN: {result['ARN']}, Region: {result['Region']}, Tags: {result['Tags']}")
