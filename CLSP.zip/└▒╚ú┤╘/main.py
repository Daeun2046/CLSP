# main.py
import json
import boto3
from s3_bucket_default_encryption.s3_bucket_default_encryption import s3_bucket_default_encryption
from s3_bucket_public_access.s3_bucket_public_access import s3_bucket_public_access
from s3_bucket_object_lock.s3_bucket_object_lock import s3_bucket_object_lock
from s3_bucket_secure_transport_policy.s3_bucket_secure_transport_policy import s3_bucket_secure_transport_policy
from s3_bucket_policy_public_write_access.s3_bucket_policy_public_write_access import s3_bucket_policy_public_write_access
from s3_bucket_no_mfa_delete.s3_bucket_no_mfa_delete import s3_bucket_no_mfa_delete

# Prompt for AWS credentials
ACCESS_KEY = input("Enter your AWS Access Key ID: ")
SECRET_KEY = input("Enter your AWS Secret Access Key: ")

# Configure boto3 with provided credentials
session = boto3.Session(aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)

# Run the checks
encryption_findings = s3_bucket_default_encryption()
public_access_findings = s3_bucket_public_access(session)
object_lock_findings = s3_bucket_object_lock()
secure_transport_findings = s3_bucket_secure_transport_policy()
public_write_access_findings = s3_bucket_policy_public_write_access(session)
mfa_delete_findings = s3_bucket_no_mfa_delete()

# Combine all findings
all_findings = [
    {"CheckName": "S3 Bucket Encryption", "Findings": encryption_findings},
    {"CheckName": "S3 Bucket Public Access", "Findings": public_access_findings},
    {"CheckName": "S3 Bucket Object Lock", "Findings": object_lock_findings},
    {"CheckName": "S3 Bucket Secure Transport Policy", "Findings": secure_transport_findings},
    {"CheckName": "S3 Bucket Public Write Access", "Findings": public_write_access_findings},
    {"CheckName": "S3 Bucket MFA Delete", "Findings": mfa_delete_findings},
]

# Write findings to result.json
with open('result.json', 'w') as f:
    json.dump(all_findings, f, indent=2)