# s3_bucket_public_access.py
import boto3


def s3_bucket_public_access(session):
    """
    Ensure there are no S3 buckets open to Everyone or Any AWS user.
    """
    s3 = session.client('s3')
    findings = []

    # Get list of all buckets
    buckets = s3.list_buckets().get('Buckets', [])

    for bucket in buckets:
        bucket_name = bucket['Name']
        try:
            # Get bucket public access block configuration
            public_access_block = s3.get_public_access_block(Bucket=bucket_name).get('PublicAccessBlockConfiguration', {})
            bucket_acl = s3.get_bucket_acl(Bucket=bucket_name).get('Grants', [])
            bucket_policy = s3.get_bucket_policy(Bucket=bucket_name).get('Policy', {})

            is_public = False
            status_extended = f"S3 Bucket {bucket_name} is not public."

            # Check if public access block is enabled
            if not (
                public_access_block.get('IgnorePublicAcls', False)
                and public_access_block.get('RestrictPublicBuckets', False)
            ):
                # Check bucket ACL
                for grantee in bucket_acl:
                    if grantee.get('Grantee', {}).get('Type') == 'Group':
                        if grantee['Grantee'].get('URI') in ('http://acs.amazonaws.com/groups/global/AllUsers', 'http://acs.amazonaws.com/groups/global/AuthenticatedUsers'):
                            is_public = True
                            status_extended = f"S3 Bucket {bucket_name} has public access due to bucket ACL."
                            break

                # Check bucket policy
                if not is_public:
                    statements = bucket_policy.get('Statement', [])
                    for statement in statements:
                        if (
                            statement.get('Principal') == '*'
                            and statement.get('Effect') == 'Allow'
                        ):
                            is_public = True
                            status_extended = f"S3 Bucket {bucket_name} has public access due to bucket policy."
                            break
                        elif (
                            statement.get('Principal', {}).get('AWS') == '*'
                            and statement.get('Effect') == 'Allow'
                        ):
                            is_public = True
                            status_extended = f"S3 Bucket {bucket_name} has public access due to bucket policy."
                            break

            if is_public:
                status = 'FAIL'
            else:
                status = 'PASS'

            findings.append({
                'resource_id': bucket_name,
                'resource_arn': f"arn:aws:s3:::{bucket_name}",
                'status': status,
                'status_extended': status_extended,
            })
        except Exception as e:
            findings.append({
                'resource_id': bucket_name,
                'resource_arn': f"arn:aws:s3:::{bucket_name}",
                'status': 'ERROR',
                'status_extended': str(e),
            })

    return findings