# s3_bucket_secure_transport_policy.py
import boto3


def s3_bucket_secure_transport_policy():
    """
    Check if S3 buckets have secure transport policy.
    """
    s3 = boto3.client('s3')
    findings = []

    # Get list of all buckets
    buckets = s3.list_buckets().get('Buckets')

    for bucket in buckets:
        bucket_name = bucket['Name']
        try:
            # Get bucket policy
            bucket_policy = s3.get_bucket_policy(Bucket=bucket_name).get('Policy', {})

            if not bucket_policy:
                status = 'FAIL'
                status_extended = f"S3 Bucket {bucket_name} does not have a bucket policy, thus it allows HTTP requests."
            else:
                status = 'FAIL'
                status_extended = f"S3 Bucket {bucket_name} allows requests over insecure transport in the bucket policy."
                statements = bucket_policy.get('Statement', [])
                for statement in statements:
                    if (
                        statement.get('Effect') == 'Deny'
                        and 'Condition' in statement
                        and (
                            's3:PutObject' in statement.get('Action', [])
                            or '*' in statement.get('Action', [])
                            or 's3:*' in statement.get('Action', [])
                        )
                    ):
                        if 'Bool' in statement['Condition']:
                            if 'aws:SecureTransport' in statement['Condition']['Bool']:
                                if statement['Condition']['Bool']['aws:SecureTransport'] == 'false':
                                    status = 'PASS'
                                    status_extended = f"S3 Bucket {bucket_name} has a bucket policy to deny requests over insecure transport."

            findings.append({
                'resource_id': bucket_name,
                'resource_arn': f"arn:aws:s3:::{bucket_name}",
                'status': status,
                'status_extended': status_extended,
            })
        except Exception as e:
            findings.append({
                'resource_id': bucket_name,
                'resource_arn': f"arn:aws:s3:::{bucket_name}",
                'status': 'ERROR',
                'status_extended': str(e),
            })

    return findings