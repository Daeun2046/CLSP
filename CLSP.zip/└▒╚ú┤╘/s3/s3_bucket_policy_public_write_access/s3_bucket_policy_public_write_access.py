import boto3

def s3_bucket_policy_public_write_access(session):
    """
    Check if S3 buckets have policies which allow public write access.
    """
    s3 = session.client('s3')
    findings = []

    # Get list of all buckets
    buckets = s3.list_buckets().get('Buckets', [])

    for bucket in buckets:
        bucket_name = bucket['Name']
        try:
            bucket_policy = s3.get_bucket_policy(Bucket=bucket_name)['Policy']
            statements = bucket_policy.get('Statement', [])
            for statement in statements:
                if (
                    statement.get('Effect') == 'Allow'
                    and 'Principal' in statement
                    and '*' in statement['Principal']
                    and 'Action' in statement
                    and (
                        'PutObject' in statement['Action']
                        or 'Put*' in statement['Action']
                    )
                ):
                    finding = {
                        'resource_id': bucket_name,
                        'resource_arn': f"arn:aws:s3:::{bucket_name}",
                        'status': 'FAIL',
                        'status_extended': f"S3 Bucket {bucket_name} allows public write access in the bucket policy.",
                    }
                    findings.append(finding)
                    break
        except Exception as e:
            finding = {
                'resource_id': bucket_name,
                'resource_arn': f"arn:aws:s3:::{bucket_name}",
                'status': 'ERROR',
                'status_extended': str(e),
            }
            findings.append(finding)

    return findings