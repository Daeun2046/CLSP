# s3_bucket_default_encryption.py
import boto3


def s3_bucket_default_encryption():
    """
    Check if S3 buckets have default encryption (SSE) enabled or use a bucket policy to enforce it.
    """
    s3 = boto3.client('s3')
    findings = []

    # Get list of all buckets
    buckets = s3.list_buckets().get('Buckets')

    for bucket in buckets:
        bucket_name = bucket['Name']
        try:
            # Get bucket encryption configuration
            encryption_config = s3.get_bucket_encryption(Bucket=bucket_name)
            rules = encryption_config.get('ServerSideEncryptionConfiguration', {}).get('Rules', [])

            if rules:
                encryption_enabled = True
                encryption_type = rules[0].get('ApplyServerSideEncryptionByDefault', {}).get('SSEAlgorithm', 'Unknown')
            else:
                encryption_enabled = False
                encryption_type = 'None'

            if encryption_enabled:
                status = 'PASS'
                status_extended = f"S3 Bucket {bucket_name} has Server Side Encryption with {encryption_type}."
            else:
                status = 'FAIL'
                status_extended = f"S3 Bucket {bucket_name} does not have Server Side Encryption enabled."

            findings.append({
                'resource_id': bucket_name,
                'resource_arn': f"arn:aws:s3:::{bucket_name}",
                'status': status,
                'status_extended': status_extended,
            })
        except Exception as e:
            findings.append({
                'resource_id': bucket_name,
                'resource_arn': f"arn:aws:s3:::{bucket_name}",
                'status': 'ERROR',
                'status_extended': str(e),
            })

    return findings