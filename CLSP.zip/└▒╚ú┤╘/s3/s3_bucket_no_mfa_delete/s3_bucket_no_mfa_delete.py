# s3_bucket_no_mfa_delete.py
import boto3


def s3_bucket_no_mfa_delete():
    """
    Check if S3 bucket MFA Delete is not enabled.
    """
    s3 = boto3.client('s3')
    findings = []

    # Get list of all buckets
    buckets = s3.list_buckets().get('Buckets')

    for bucket in buckets:
        bucket_name = bucket['Name']
        try:
            # Get bucket versioning configuration
            versioning_config = s3.get_bucket_versioning(Bucket=bucket_name)
            mfa_delete_enabled = versioning_config.get('MFADelete', 'Disabled')

            if mfa_delete_enabled == 'Enabled':
                status = 'PASS'
                status_extended = f"S3 Bucket {bucket_name} has MFA Delete enabled."
            else:
                status = 'FAIL'
                status_extended = f"S3 Bucket {bucket_name} has MFA Delete disabled."

            findings.append({
                'resource_id': bucket_name,
                'resource_arn': f"arn:aws:s3:::{bucket_name}",
                'status': status,
                'status_extended': status_extended,
            })
        except Exception as e:
            findings.append({
                'resource_id': bucket_name,
                'resource_arn': f"arn:aws:s3:::{bucket_name}",
                'status': 'ERROR',
                'status_extended': str(e),
            })

    return findings