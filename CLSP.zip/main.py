import json
import os
import subprocess


#import boto3
#from dotenv import load_dotenv

def key_pair():
    env_path = os.path.join(os.path.dirname(__file__), '.env')

    if os.path.exists(env_path):
        load_dotenv(env_path)
    else:
        open(env_path, 'a').close()  # 빈 .env 파일 생성

    try:
        aws_access_key_id = os.getenv('AWS_ACCESS_KEY_ID')
        aws_secret_access_key = os.getenv('AWS_SECRET_ACCESS_KEY')
        aws_default_region = os.getenv('AWS_DEFAULT_REGION', "ap-northeast-2")

        os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key_id
        os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_access_key
        os.environ['AWS_DEFAULT_REGION'] = aws_default_region

    except Exception as e:
        print("키값이 올바르지 않습니다.")
        aws_access_key_id = input("AWS_ACCESS_KEY_ID: ")

        aws_secret_access_key = input("AWS_SECRET_ACCESS_KEY: ")

        aws_default_region = input("AWS_DEFAULT_REGION (기본값: ap-northeast-2[서울]): ") or "ap-northeast-2"

        os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key_id
        os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_access_key
        os.environ['AWS_DEFAULT_REGION'] = aws_default_region


    with open(env_path, 'w') as f:
        f.write(f"AWS_ACCESS_KEY_ID={aws_access_key_id}\n")
        f.write(f"AWS_SECRET_ACCESS_KEY={aws_secret_access_key}\n")
        f.write(f"AWS_DEFAULT_REGION={aws_default_region}\n")
    
    if not os.environ['AWS_DEFAULT_REGION']:
        os.environ['AWS_DEFAULT_REGION'] = "ap-northeast-2"


def read_json_file(filename):
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"Error: {filename} not found.")
        return None
    
def print_in_box(lines):
    max_length = max(len(f"{index + 1}. {line}") for index, line in enumerate(lines))
    print('╔' + '═' * (max_length + 2) + '╗')
    for index, line in enumerate(lines):
        print(f'║ {index + 1}. {str(lines[index])} ║')
    print('╚' + '═' * (max_length + 2) + '╝')

def service_client_info():
    services = {
        "ec2": ec2,
        "iam": iam,
        "s3 ": s3
    }
    service_names = list(services.keys())

    print("분석할 서비스를 선택하세요:\n")
    print("0. 모든 서비스:\n")
    print_in_box(service_names)
    while True:
        try:
            selection = int(input("번호를 입력하세요: "))
            if selection == 0:
                selected_services = service_names
                break
            elif 1 <= selection <= len(service_names):
                selected_services = [service_names[selection - 1]]
                break
            else:
                print("유효한 번호를 입력하세요.")
        except ValueError:
            print("숫자를 입력하세요.")

    print(f"선택된 서비스: {', '.join(selected_services)}")
    return selection


# 쉘 명령어를 실행하는 함수
def run_command(command):
    result = subprocess.run(command, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    print(result.stdout)
    if result.stderr:
        print(result.stderr)

# 1단계: 필요한 라이브러리 설치
def install_libraries(libraries):
    print("필요한 라이브러리 설치 중...")
    for library in libraries:
        run_command(f"pip install {library}")


# 프로젝트 설정을 위한 메인 함수
def setup_project():
    libraries = [
        "boto3",
        "python-dotenv",
        "colorama"
    ]
    
    install_libraries(libraries)
    print("프로젝트 설정이 완료되었습니다!")


def main():
    print("OK")
    select = service_client_info()
    base_dir = os.path.join('results', 'checks')
    
    if select == 0 :
        s3.s3__main__.main()

        s3_results_path = os.path.join(base_dir, "s3_checks.json")
        s3_data = read_json_file(s3_results_path)
        s3_print_pretty_report(s3_data)

        ec2.ec2__main__.main()
        
        ec2_results_path = os.path.join(base_dir, "ec2_checks.json")
        ec2_data = read_json_file(ec2_results_path)
        ec2_print_pretty_report(ec2_data)

        iam.iam__main__.main()

        iam_results_path = os.path.join(base_dir, "iam_checks.json")
        iam_data = read_json_file(iam_results_path)
        iam_print_pretty_report(iam_data)

    elif select == 1:
        ec2.ec2__main__.main()

        ec2_results_path = os.path.join(base_dir, "ec2_checks.json")
        ec2_data = read_json_file(ec2_results_path)
        ec2_print_pretty_report(ec2_data)

    elif select == 2:
        iam.iam__main__.main()

        iam_results_path = os.path.join(base_dir, "iam_checks.json")
        iam_data = read_json_file(iam_results_path)
        iam_print_pretty_report(iam_data)


    elif select == 3: 
        s3.s3__main__.main()

        s3_results_path = os.path.join(base_dir, "s3_checks.json")
        s3_data = read_json_file(s3_results_path)
        s3_print_pretty_report(s3_data)
    

if __name__ == "__main__":
    try:
        import boto3
        from dotenv import load_dotenv
        import colorama
        key_pair()
        from s3.s3__main__ import s3_print_pretty_report
        from ec2.ec2__main__ import ec2_print_pretty_report
        import s3.s3__main__
        import ec2.ec2__main__
        import iam.iam__main__
        from iam.iam__main__ import iam_print_pretty_report
        print("코드를 실행합니다.")
        main()
    except ImportError:
        print("라이브러리가 설치되어 있지 않습니다. 설치를 시작합니다...")
        print("ok")
        setup_project() 
    
