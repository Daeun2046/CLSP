import json
import boto3
import os
from iam_administrator_access_with_mfa import iam_administrator_access_with_mfa2
from iam_avoid_root_usage import iam_avoid_root_usage2
from iam_aws_attached_policy_no_administrative_privileges import iam_aws_attached_policy_no_administrative_privileges2
from iam_check_saml_providers_sts import iam_check_saml_providers_sts2
from iam_customer_attached_policy_no_administrative_privileges import iam_customer_attached_policy_no_administrative_privileges2
from iam_customer_unattached_policy_no_administrative_privileges import iam_customer_unattached_policy_no_administrative_privileges2
from iam_inline_policy_no_administrative_privileges import iam_inline_policy_no_administrative_privileges2
from iam_no_custom_policy_permissive_role_assumption import iam_no_custom_policy_permissive_role_assumption2
from iam_no_expired_server_certificates_stored import iam_no_expired_server_certificates_stored2


# IAM 클라이언트 생성
os.environ['AWS_ACCESS_KEY_ID'] = 'AKIAXYKJTDP3MQUIMI43'
os.environ['AWS_SECRET_ACCESS_KEY'] = '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'
os.environ['AWS_DEFAULT_REGION'] = 'ap-northeast-2'
iam_client = boto3.client('iam')

# 정사각형 테두리 생성 함수
def print_in_box(lines):
    max_length = max(len(f"{index + 1}. {line}") for index, line in enumerate(lines))
    print('╔' + '═' * (max_length + 2) + '╗')
    for index, line in enumerate(lines):
        print(f'║ {index + 1}. {line.ljust(max_length - len(f"{index + 1}. "))} ║')
    print('╚' + '═' * (max_length + 2) + '╝')

# IAM 사용자 목록 가져오기 함수
def list_iam_users():
    response = iam_client.list_users()
    users = response['Users']
    user_names = [user['UserName'] for user in users]
    return user_names

# IAM 사용자의 정책 목록 가져오기 함수
def list_user_policies(user_name):
    response = iam_client.list_attached_user_policies(UserName=user_name)
    policies = response['AttachedPolicies']
    policy_names = [policy['PolicyName'] for policy in policies]
    return policy_names

def iam_client_info():
    user_names = list_iam_users()
    print("Select the IAM users you want to analyze:\n")
    print("0. All users")
    print_in_box(user_names)
    while True:
        try:
            selection = int(input("Enter the number: "))
            if selection == 0:
                selected_users = user_names
                break
            elif 1 <= selection <= len(user_names):
                selected_users = [user_names[selection - 1]]
                break
            else:
                print("Please enter a valid number.")
        except ValueError:
            print("Please enter a number.")

    print(f"Selected IAM users: {', '.join(selected_users)}")
    return selected_users

if __name__ == "__main__":
    selected_users = iam_client_info()
    results = {}

    for user_name in selected_users:
        user_policies = list_user_policies(user_name)
        results[user_name] = {}

        for policy_name in user_policies:
            print(f"{policy_name}!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            results[user_name][policy_name] = {}

            # 각 함수 호출에서 정책 이름 목록을 전달
            admin_access = iam_administrator_access_with_mfa2(iam_client)
            avoid_root = iam_avoid_root_usage2(iam_client)
            aws_attached = iam_aws_attached_policy_no_administrative_privileges2(iam_client)
            check_saml = iam_check_saml_providers_sts2(iam_client)
            customer_attached = iam_customer_attached_policy_no_administrative_privileges2(iam_client)
            customer_unattached = iam_customer_unattached_policy_no_administrative_privileges2(iam_client)
            inline_policy = iam_inline_policy_no_administrative_privileges2(iam_client)
            no_custom_policy = iam_no_custom_policy_permissive_role_assumption2(iam_client)
            no_expired_server = iam_no_expired_server_certificates_stored2(iam_client)

            # 결과 저장
            results[user_name][policy_name] = {
                'admin_access': admin_access,
                'avoid_root': avoid_root,
                'aws_attached': aws_attached,
                'check_saml': check_saml,
                'customer_attached': customer_attached,
                'customer_unattached': customer_unattached,
                'inline_policy': inline_policy,
                'no_custom_policy': no_custom_policy,
                'no_expired_server': no_expired_server
            }

    with open('iam_analysis_results.json', 'w') as json_file:
        json.dump(results, json_file, indent=4)

    print("Results have been saved to iam_analysis_results.json")
