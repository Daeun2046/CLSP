from botocore.exceptions import ClientError

def iam_aws_attached_policy_no_administrative_privileges2(iam_client):
    findings = []  # 결과를 저장할 리스트 초기화

    try:
        # 모든 정책을 가져오기 위해 페이지 처리 설정
        paginator = iam_client.get_paginator('list_policies')
        # 페이지 처리된 정책 리스트를 순회
        for response in paginator.paginate(Scope='Local'):
            for policy in response['Policies']:
                policy_name = policy['PolicyName']  # 정책 이름 가져오기
                policy_arn = policy['Arn']  # 정책 ARN 가져오기

                # 정책이 연결된 엔터티를 확인
                attached_entities = iam_client.list_entities_for_policy(PolicyArn=policy_arn)
                # 정책이 어떤 엔터티에도 연결되지 않았으면 다음으로 넘어감
                if not attached_entities['PolicyGroups'] and not attached_entities['PolicyUsers'] and not attached_entities['PolicyRoles']:
                    continue

                # 기본 상태 및 상태 확장 메시지 설정
                status = "PASS"
                status_extended = f"AWS policy {policy_name} does not allow '*:*' administrative privileges."

                # 정책의 기본 버전을 가져오기
                policy_version = iam_client.get_policy_version(
                    PolicyArn=policy_arn, 
                    VersionId=policy['DefaultVersionId']
                )['PolicyVersion']['Document']

                # 정책 문서에 'Statement'가 있는지 확인
                if 'Statement' in policy_version:
                    # 'Statement'가 리스트가 아니면 리스트로 변환
                    if not isinstance(policy_version['Statement'], list):
                        policy_statements = [policy_version['Statement']]
                    else:
                        policy_statements = policy_version['Statement']

                    # 각 'Statement'를 순회하며 조건 확인
                    for statement in policy_statements:
                        # "Effect": "Allow"와 "Action": "*" 그리고 "Resource": "*"인 경우 확인
                        if (
                            statement.get('Effect') == 'Allow'
                            and 'Action' in statement
                            and (
                                statement['Action'] == '*' or isinstance(statement['Action'], list) and '*' in statement['Action']
                            )
                            and (
                                statement['Resource'] == '*' or isinstance(statement['Resource'], list) and '*' in statement['Resource']
                            )
                        ):
                            # 조건에 맞으면 상태를 "FAIL"로 변경하고 확장 메시지 수정
                            status = "FAIL"
                            status_extended = f"AWS policy {policy_name} allows '*:*' administrative privileges."
                            break

                # 결과 리스트에 현재 정책의 상태 추가
                findings.append({
                    "Object_name": policy_name,
                    "arn": f"{policy_arn}",
                    "tag": "N/A",  # IAM 정책에는 태그가 적용되지 않음
                    "region": iam_client.meta.region_name,
                    "policy_name": policy_name,
                    "status": status,
                    "status_extended": status_extended
                })

    except ClientError as e:
        # 예외 발생 시 에러 메시지와 함께 결과 리스트에 추가
        findings.append({
            "Object_name": "N/A",
            "arn": "N/A",
            "tag": "N/A",
            "region": "N/A",
            "policy_name": "N/A",
            "status": "ERROR",
            "status_extended": f"Error retrieving IAM policies: {str(e)}"
        })

    return findings  # 결과 리스트 반환

