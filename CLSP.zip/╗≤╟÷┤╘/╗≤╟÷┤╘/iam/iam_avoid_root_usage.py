import datetime  # 날짜와 시간 관련 기능을 사용하기 위해 datetime 모듈을 가져옴
from botocore.exceptions import ClientError  # Boto3 클라이언트 에러를 처리하기 위해 예외를 가져옴
import boto3
maximum_access_days = 1  # 최대 허용 액세스 일 수 설정

def iam_avoid_root_usage2(iam_client):
    findings = []  # 결과를 저장할 리스트 초기화

    try:
        response = iam_client.get_credential_report()  # IAM 자격 증명 보고서를 가져옴
        report_lines = response['Content'].decode('utf-8').split('\n')  # 보고서 내용을 UTF-8로 디코딩하고 줄 단위로 분리
        headers = report_lines[0].split(',')  # 첫 번째 줄은 헤더로 분리

        for line in report_lines[1:]:  # 헤더 이후의 각 줄에 대해 반복
            user = dict(zip(headers, line.split(',')))  # 각 줄의 데이터를 헤더와 매핑하여 딕셔너리로 변환
            if user["user"] == "<root_account>":  # 루트 계정인지 확인
                # 기본값 설정
                status = "PASS"  # 초기 상태는 "PASS"로 설정
                status_extended = f"Root user in the account wasn't accessed in the last {maximum_access_days} days."  # 기본 설명 설정

                if (
                    user["password_last_used"] != "no_information"  # 비밀번호가 마지막으로 사용된 경우
                    or user["access_key_1_last_used_date"] != "N/A"  # 첫 번째 액세스 키가 마지막으로 사용된 경우
                    or user["access_key_2_last_used_date"] != "N/A"  # 두 번째 액세스 키가 마지막으로 사용된 경우
                ):
                    if user["password_last_used"] != "no_information":  # 비밀번호가 마지막으로 사용된 경우
                        days_since_accessed = (
                            datetime.datetime.now()  # 현재 시간과
                            - datetime.datetime.strptime(
                                user["password_last_used"],  # 비밀번호 마지막 사용 시간을 비교하여
                                "%Y-%m-%dT%H:%M:%S+00:00",  # 시간 형식을 지정하고
                            )
                        ).days  # 일 수로 변환
                    elif user["access_key_1_last_used_date"] != "N/A":  # 첫 번째 액세스 키가 마지막으로 사용된 경우
                        days_since_accessed = (
                            datetime.datetime.now()  # 현재 시간과
                            - datetime.datetime.strptime(
                                user["access_key_1_last_used_date"],  # 첫 번째 액세스 키 마지막 사용 시간을 비교하여
                                "%Y-%m-%dT%H:%M:%S+00:00",  # 시간 형식을 지정하고
                            )
                        ).days  # 일 수로 변환
                    elif user["access_key_2_last_used_date"] != "N/A":  # 두 번째 액세스 키가 마지막으로 사용된 경우
                        days_since_accessed = (
                            datetime.datetime.now()  # 현재 시간과
                            - datetime.datetime.strptime(
                                user["access_key_2_last_used_date"],  # 두 번째 액세스 키 마지막 사용 시간을 비교하여
                                "%Y-%m-%dT%H:%M:%S+00:00",  # 시간 형식을 지정하고
                            )
                        ).days  # 일 수로 변환
                    if maximum_access_days >= days_since_accessed:  # 마지막 사용일이 최대 허용 일 수 이내인지 확인
                        status = "FAIL"  # 상태를 "FAIL"로 설정
                        status_extended = f"Root user in the account was last accessed {days_since_accessed} days ago."  # 설명 업데이트

                findings.append({  # 결과를 findings 리스트에 추가
                    "Object_name": user["user"],  # 사용자 이름
                    "arn": f"{user['arn']}",  # 사용자 ARN
                    "tag": "N/A",  # IAM 사용자에는 태그가 적용되지 않음
                    "region": iam_client.meta.region_name,  # IAM 클라이언트의 지역
                    "policy_name": "N/A",  # 정책 이름은 해당되지 않음
                    "status": status,  # 사용자의 상태
                    "status_extended": status_extended  # 상태에 대한 설명
                })

    except ClientError as e:  # ClientError 발생 시 처리
        findings.append({  # 에러 내용을 findings 리스트에 추가
            "Object_name": "N/A",  # N/A로 설정
            "arn": "N/A",  # N/A로 설정
            "tag": "N/A",  # N/A로 설정
            "region": "N/A",  # N/A로 설정
            "policy_name": "N/A",  # N/A로 설정
            "status": "ERROR",  # 상태를 "ERROR"로 설정
            "status_extended": f"Error retrieving IAM credential report: {str(e)}"  # 에러 메시지 추가
        })

    return findings  # 결과 반환


if __name__ == "__main__":
    iam_client = boto3.client('iam',
                aws_access_key_id="AKIAXYKJTDP3MQUIMI43",
                aws_secret_access_key="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",
                region_name='ap-northeast-2')
    print(iam_avoid_root_usage2(iam_client))