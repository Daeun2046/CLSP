from botocore.exceptions import ClientError

def iam_customer_attached_policy_no_administrative_privileges2(iam_client):
    findings = []  # 결과를 저장할 리스트 초기화

    try:
        # 사용자 지정 정책 중 연결된 것들만 가져옴
        response = iam_client.list_policies(Scope='Local', OnlyAttached=True, PolicyUsageFilter='PermissionsPolicy')
        # 각 정책을 순회
        for policy in response['Policies']:
            # INLINE 정책은 건너뜀
            if policy['PolicyType'] == 'INLINE':
                continue
            
            policy_name = policy['PolicyName']  # 정책 이름 가져오기
            policy_arn = policy['Arn']  # 정책 ARN 가져오기

            # 기본 상태 및 상태 확장 메시지 설정
            status = "PASS"
            status_extended = f"Custom policy {policy_name} is attached but does not allow '*:*' administrative privileges."

            # 정책의 기본 버전 문서 가져오기
            policy_document = iam_client.get_policy_version(PolicyArn=policy_arn, VersionId=policy['DefaultVersionId'])['PolicyVersion']['Document']
            if policy_document:
                # 'Statement'가 리스트가 아니면 리스트로 변환
                if not isinstance(policy_document['Statement'], list):
                    policy_statements = [policy_document['Statement']]
                else:
                    policy_statements = policy_document['Statement']
                
                # 각 'Statement'를 순회하며 조건 확인
                for statement in policy_statements:
                    # "Effect": "Allow"와 "Action": "*" 그리고 "Resource": "*"인 경우 확인
                    if (
                        statement['Effect'] == 'Allow'
                        and 'Action' in statement
                        and (
                            statement['Action'] == '*'
                            or statement['Action'] == ['*']
                        )
                        and (
                            statement['Resource'] == '*'
                            or statement['Resource'] == ['*']
                        )
                    ):
                        # 조건에 맞으면 상태를 "FAIL"로 변경하고 확장 메시지 수정
                        status = "FAIL"
                        status_extended = f"Custom policy {policy_name} is attached and allows '*:*' administrative privileges."
                        break

            # 결과 리스트에 현재 정책의 상태 추가
            findings.append({
                "Object_name": policy_name,
                "arn": f"{policy_arn}",
                "tag": "N/A",  # IAM 사용자 지정 정책에는 태그가 적용되지 않음
                "region": iam_client.meta.region_name,
                "policy_name": "N/A",  # 정책 이름을 가져오는 부분이 없어서 기본값으로 N/A 설정
                "status": status,
                "status_extended": status_extended
            })

    except ClientError as e:
        # 예외 발생 시 에러 메시지와 함께 결과 리스트에 추가
        findings.append({
            "Object_name": "N/A",
            "arn": "N/A",
            "tag": "N/A",
            "region": "N/A",
            "policy_name": "N/A",
            "status": "ERROR",
            "status_extended": f"Error retrieving IAM custom attached policies: {str(e)}"
        })

    return findings  # 결과 리스트 반환

# 예시 사용
# iam_client = boto3.client('iam')
# findings = iam_customer_attached_policy_no_administrative_privileges2(iam_client)
# print(findings)
