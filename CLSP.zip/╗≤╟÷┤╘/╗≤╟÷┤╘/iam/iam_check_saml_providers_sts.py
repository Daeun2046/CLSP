from botocore.exceptions import ClientError

def iam_check_saml_providers_sts2(iam_client):
    findings = []  # 결과를 저장할 리스트 초기화

    try:
        # SAML 공급자 리스트를 가져옴
        response = iam_client.list_saml_providers()
        # SAML 공급자가 있는지 확인
        if 'SAMLProviderList' in response and response['SAMLProviderList']:
            # 각 SAML 공급자를 순회
            for provider in response['SAMLProviderList']:
                provider_arn = provider['Arn']  # 공급자의 ARN을 가져옴
                provider_name = provider_arn.split('/')[-1]  # ARN에서 공급자 이름을 추출

                # 기본 상태 및 상태 확장 메시지 설정
                status = "PASS"
                status_extended = f"SAML Provider {provider_name} has been found."

                # 결과 리스트에 현재 공급자의 상태 추가
                findings.append({
                    "Object_name": provider_name,
                    "arn": f"{provider_arn}",
                    "tag": "N/A",  # IAM SAML 공급자에는 태그가 적용되지 않음
                    "region": iam_client.meta.region_name,
                    "policy_name": "N/A",  # 정책 이름을 가져오는 부분이 없어서 기본값으로 N/A 설정
                    "status": status,
                    "status_extended": status_extended
                })

    except ClientError as e:
        # 예외 발생 시 에러 메시지와 함께 결과 리스트에 추가
        findings.append({
            "Object_name": "N/A",
            "arn": "N/A",
            "tag": "N/A",
            "region": "N/A",
            "policy_name": "N/A",
            "status": "ERROR",
            "status_extended": f"Error retrieving IAM SAML providers: {str(e)}"
        })

    return findings  # 결과 리스트 반환

# 예시 사용
# iam_client = boto3.client('iam')
# findings = iam_check_saml_providers_sts2(iam_client)
# print(findings)
