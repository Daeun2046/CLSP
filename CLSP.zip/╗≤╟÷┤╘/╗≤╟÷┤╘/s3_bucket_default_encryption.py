# import s3__main__
from botocore.exceptions import ClientError

# S3 버킷의 기본 암호화 설정을 확인하는 함수
def s3_bucket_encryption(s3_client, selected_buckets):
    findings = []

    for bucket_name in selected_buckets:
        try:
            # S3 버킷의 암호화 상태를 가져오기
            encryption = s3_client.get_bucket_encryption(Bucket=bucket_name)
            rules = encryption['ServerSideEncryptionConfiguration']['Rules']
            encryption_status = ", ".join(rule['ApplyServerSideEncryptionByDefault']['SSEAlgorithm'] for rule in rules)
            status = "PASS"
            status_extended = f"S3 Bucket {bucket_name} has Server Side Encryption with {encryption_status}."
        except s3_client.exceptions.ClientError as e:
            if e.response['Error']['Code'] == 'ServerSideEncryptionConfigurationNotFoundError':
                status = "FAIL"
                status_extended = f"S3 Bucket {bucket_name} does not have Server Side Encryption enabled."
            else:
                status = "ERROR"
                status_extended = f"Error retrieving encryption status for bucket {bucket_name}: {str(e)}"

        # Bucket ARN 가져오기
        bucket_region = s3_client.get_bucket_location(Bucket=bucket_name)['LocationConstraint']
        bucket_arn = f"arn:aws:s3:::{bucket_name}" if bucket_region is None else f"arn:aws:s3::{bucket_region}:{bucket_name}"

        # Bucket Tags 가져오기
        try:
            bucket_tags = s3_client.get_bucket_tagging(Bucket=bucket_name)['TagSet']
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchTagSet':
                bucket_tags = []
            else:
                raise

        findings.append({
            'Bucket': bucket_name,
            'Status': status,
            'Details': status_extended,
            'ARN': bucket_arn,
            'Region': bucket_region,
            'Tags': bucket_tags
        })

    return findings

# if __name__ == "__main__":
#     s3_client, selected_buckets = s3__main__.s3_client_info()
#     report = []
#     encryption_findings = s3_bucket_encryption(s3_client, selected_buckets)
    
#     print(encryption_findings)