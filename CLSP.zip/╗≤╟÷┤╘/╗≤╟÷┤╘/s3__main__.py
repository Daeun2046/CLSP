import json
import boto3
import s3_bucket_default_encryption
import s3_bucket_object_lock
import s3_bucket_no_mfa_delete
import s3_bucket_public_access
import s3_bucket_secure_transport_policy
import s3_bucket_policy_public_write_access

# main함수를 실행하기 전 자격증명을 가져와야 한다.
# 터미널에 아래 명령어를 친다.
# export AWS_ACCESS_KEY_ID=YOUR_NEW_ACCESS_KEY_ID
# export AWS_SECRET_ACCESS_KEY=YOUR_NEW_SECRET_ACCESS_KEY
# 정사각형 테두리 생성 함수
def print_in_box(lines):
    # 가장 긴 문자열의 길이 계산 (숫자와 공백 포함)
    max_length = max(len(f"{index + 1}. {line}") for index, line in enumerate(lines))
    # 상단 테두리 출력
    print('╔' + '═' * (max_length + 2) + '╗')
    # 각 줄을 번호와 함께 테두리 안에 출력
    for index, line in enumerate(lines):
        print(f'║ {index + 1}. {line.ljust(max_length - len(f"{index + 1}. "))} ║')
    # 하단 테두리 출력
    print('╚' + '═' * (max_length + 2) + '╝')

def s3_client_info():
    s3_client = boto3.client('s3')
    response = s3_client.list_buckets()
    buckets = response['Buckets']
    bucket_names = [bucket['Name'] for bucket in buckets]
    print("원하시는 버킷을 선택해주세요\n")
    print("0. 모든 버킷 선택")
    print_in_box(bucket_names)
    while True:
        try:
            selection = int(input("번호를 입력하세요: "))
            if selection == 0:
                selected_buckets = bucket_names
                break
            elif 1 <= selection <= len(bucket_names):
                selected_buckets = [bucket_names[selection - 1]]
                break
            else:
                print("유효한 번호를 입력하세요.")
        except ValueError:
            print("숫자를 입력하세요.")

    print(f"선택한 버킷: {', '.join(selected_buckets)}")
    return s3_client, selected_buckets

if __name__ == "__main__":
    s3_client, selected_buckets = s3_client_info()
    results = {}

    for bucket_name in selected_buckets:
        results[bucket_name] = {}

        encryption = s3_bucket_default_encryption.s3_bucket_encryption(s3_client, [bucket_name])
        results[bucket_name]['encryption'] = encryption

        object_lock = s3_bucket_object_lock.s3_bucket_object_lock(s3_client, [bucket_name])
        results[bucket_name]['object_lock'] = object_lock

        mfa_delete = s3_bucket_no_mfa_delete.s3_bucket_no_mfa_delete(s3_client, [bucket_name])
        results[bucket_name]['mfa_delete'] = mfa_delete

        public_access = s3_bucket_public_access.s3_bucket_public_access(s3_client, [bucket_name])
        results[bucket_name]['public_access'] = public_access

        secure_transport = s3_bucket_secure_transport_policy.s3_bucket_secure_transport_policy(s3_client, [bucket_name])
        results[bucket_name]['secure_transport'] = secure_transport

        public_write_access = s3_bucket_policy_public_write_access.s3_bucket_policy_public_write_access(s3_client, [bucket_name])
        results[bucket_name]['public_write_access'] = public_write_access

    with open('s3_bucket_results.json', 'w') as json_file:
        json.dump(results, json_file, indent=4, ensure_ascii=False)
    
    print("결과가 s3_bucket_results.json 파일에 저장되었습니다.")
