from botocore.exceptions import ClientError
import json

def s3_bucket_secure_transport_policy(s3_client, selected_buckets):
    findings = []

    for bucket_name in selected_buckets:
        status = "FAIL"
        status_extended = f"S3 Bucket {bucket_name} allows requests over insecure transport in the bucket policy."

        try:
            # Bucket Policy 확인
            bucket_policy = s3_client.get_bucket_policy(Bucket=bucket_name)
            policy = json.loads(bucket_policy['Policy'])
            policy_statements = policy['Statement']
            
            for statement in policy_statements:
                if (
                    statement["Effect"] == "Deny"
                    and "Condition" in statement
                    and (
                        "s3:PutObject" in statement["Action"]
                        or "*" in statement["Action"]
                        or "s3:*" in statement["Action"]
                    )
                ):
                    if "Bool" in statement["Condition"]:
                        if "aws:SecureTransport" in statement["Condition"]["Bool"]:
                            if statement["Condition"]["Bool"]["aws:SecureTransport"] == "false":
                                status = "PASS"
                                status_extended = f"S3 Bucket {bucket_name} has a bucket policy to deny requests over insecure transport."
                                break
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchBucketPolicy':
                status = "FAIL"
                status_extended = f"S3 Bucket {bucket_name} does not have a bucket policy, thus it allows HTTP requests."
            else:
                status = "ERROR"
                status_extended = f"Error retrieving policy for bucket {bucket_name}: {str(e)}"

        # Bucket ARN 가져오기
        bucket_location = s3_client.get_bucket_location(Bucket=bucket_name)
        bucket_region = bucket_location['LocationConstraint'] or 'us-east-1'
        bucket_arn = f"arn:aws:s3:::{bucket_name}"

        # Bucket Tags 가져오기
        try:
            bucket_tags = s3_client.get_bucket_tagging(Bucket=bucket_name)['TagSet']
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchTagSet':
                bucket_tags = []
            else:
                status = "ERROR"
                status_extended = f"Error retrieving tags for bucket {bucket_name}: {str(e)}"
                bucket_tags = []

        findings.append({
            'Bucket': bucket_name,
            'Status': status,
            'Details': status_extended,
            'ARN': bucket_arn,
            'Region': bucket_region,
            'Tags': bucket_tags
        })

    return findings
