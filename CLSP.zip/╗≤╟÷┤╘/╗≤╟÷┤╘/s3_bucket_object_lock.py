from botocore.exceptions import ClientError

def s3_bucket_object_lock(s3_client, selected_buckets):
    findings = []

    for bucket_name in selected_buckets:
        try:
            # S3 버킷의 Object Lock 상태를 가져오기
            object_lock = s3_client.get_object_lock_configuration(Bucket=bucket_name)
            if 'ObjectLockConfiguration' in object_lock and 'ObjectLockEnabled' in object_lock['ObjectLockConfiguration']:
                lock_status = object_lock['ObjectLockConfiguration']['ObjectLockEnabled']
                status = "PASS"
                status_extended = f"S3 Bucket {bucket_name} has Object Lock enabled: {lock_status}."
            else:
                status = "FAIL"
                status_extended = f"S3 Bucket {bucket_name} does not have Object Lock enabled."
        except ClientError as e:
            if e.response['Error']['Code'] == 'ObjectLockConfigurationNotFoundError':
                status = "FAIL"
                status_extended = f"S3 Bucket {bucket_name} does not have Object Lock enabled."
            else:
                status = "ERROR"
                status_extended = f"Error retrieving object lock status for bucket {bucket_name}: {str(e)}"

        # Bucket ARN 가져오기
        bucket_region = s3_client.get_bucket_location(Bucket=bucket_name)['LocationConstraint']
        bucket_arn = f"arn:aws:s3:::{bucket_name}" if bucket_region is None else f"arn:aws:s3::{bucket_region}:{bucket_name}"

        # Bucket Tags 가져오기
        try:
            bucket_tags = s3_client.get_bucket_tagging(Bucket=bucket_name)['TagSet']
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchTagSet':
                bucket_tags = []
            else:
                raise

        findings.append({
            'Bucket': bucket_name,
            'Status': status,
            'Details': status_extended,
            'ARN': bucket_arn,
            'Region': bucket_region,
            'Tags': bucket_tags
        })

    return findings
