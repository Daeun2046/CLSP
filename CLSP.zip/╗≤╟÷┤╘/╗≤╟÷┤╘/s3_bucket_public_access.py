from botocore.exceptions import ClientError

def s3_bucket_public_access(s3_client, selected_buckets):
    findings = []

    for bucket_name in selected_buckets:
        try:
            # 퍼블릭 액세스 블록 설정 가져오기
            public_access_block = s3_client.get_public_access_block(Bucket=bucket_name)
            config = public_access_block['PublicAccessBlockConfiguration']
            if config['IgnorePublicAcls'] and config['RestrictPublicBuckets']:
                status = "PASS"
                status_extended = f"S3 Bucket {bucket_name} is not public."
            else:
                status = "FAIL"
                status_extended = f"S3 Bucket {bucket_name} has public access."
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchPublicAccessBlockConfiguration':
                status = "FAIL"
                status_extended = f"S3 Bucket {bucket_name} does not have a public access block configuration."
            else:
                status = "ERROR"
                status_extended = f"Error retrieving public access block configuration for bucket {bucket_name}: {str(e)}"

        # Bucket ARN 가져오기
        bucket_location = s3_client.get_bucket_location(Bucket=bucket_name)
        bucket_region = bucket_location['LocationConstraint'] or 'us-east-1'
        bucket_arn = f"arn:aws:s3:::{bucket_name}"

        # Bucket Tags 가져오기
        try:
            bucket_tags = s3_client.get_bucket_tagging(Bucket=bucket_name)['TagSet']
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchTagSet':
                bucket_tags = []
            else:
                status = "ERROR"
                status_extended = f"Error retrieving tags for bucket {bucket_name}: {str(e)}"
                bucket_tags = []

        # Bucket ACL 확인
        try:
            bucket_acl = s3_client.get_bucket_acl(Bucket=bucket_name)
            for grant in bucket_acl['Grants']:
                grantee = grant['Grantee']
                if grantee.get('Type') == 'Group' and grantee.get('URI') in ['http://acs.amazonaws.com/groups/global/AllUsers', 'http://acs.amazonaws.com/groups/global/AuthenticatedUsers']:
                    status = "FAIL"
                    status_extended = f"S3 Bucket {bucket_name} has public access due to bucket ACL."
        except ClientError as e:
            status = "ERROR"
            status_extended = f"Error retrieving ACL for bucket {bucket_name}: {str(e)}"

        # Bucket Policy 확인
        try:
            bucket_policy = s3_client.get_bucket_policy(Bucket=bucket_name)
            policy = bucket_policy['Policy']
            if '*' in policy:
                status = "FAIL"
                status_extended = f"S3 Bucket {bucket_name} has public access due to bucket policy."
        except ClientError as e:
            if e.response['Error']['Code'] != 'NoSuchBucketPolicy':
                status = "ERROR"
                status_extended = f"Error retrieving policy for bucket {bucket_name}: {str(e)}"

        findings.append({
            'Bucket': bucket_name,
            'Status': status,
            'Details': status_extended,
            'ARN': bucket_arn,
            'Region': bucket_region,
            'Tags': bucket_tags
        })

    return findings