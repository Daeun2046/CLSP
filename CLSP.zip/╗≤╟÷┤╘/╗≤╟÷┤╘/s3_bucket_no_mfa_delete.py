from botocore.exceptions import ClientError

def s3_bucket_no_mfa_delete(s3_client, selected_buckets):
    findings = []

    for bucket_name in selected_buckets:
        try:
            # S3 버킷의 버전 설정 가져오기
            versioning = s3_client.get_bucket_versioning(Bucket=bucket_name)
            if 'Status' in versioning and versioning['Status'] == 'Enabled':
                if 'MFADelete' in versioning and versioning['MFADelete'] == 'Enabled':
                    status = "PASS"
                    status_extended = f"S3 Bucket {bucket_name} has MFA Delete enabled."
                else:
                    status = "FAIL"
                    status_extended = f"S3 Bucket {bucket_name} has MFA Delete disabled."
            else:
                status = "FAIL"
                status_extended = f"S3 Bucket {bucket_name} does not have versioning enabled, thus MFA Delete is not applicable."
        except ClientError as e:
            status = "ERROR"
            status_extended = f"Error retrieving versioning status for bucket {bucket_name}: {str(e)}"

        # Bucket ARN 가져오기
        bucket_region = s3_client.get_bucket_location(Bucket=bucket_name)['LocationConstraint']
        bucket_arn = f"arn:aws:s3:::{bucket_name}" if bucket_region is None else f"arn:aws:s3::{bucket_region}:{bucket_name}"

        # Bucket Tags 가져오기
        try:
            bucket_tags = s3_client.get_bucket_tagging(Bucket=bucket_name)['TagSet']
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchTagSet':
                bucket_tags = []
            else:
                raise

        findings.append({
            'Bucket': bucket_name,
            'Status': status,
            'Details': status_extended,
            'ARN': bucket_arn,
            'Region': bucket_region,
            'Tags': bucket_tags
        })

    return findings