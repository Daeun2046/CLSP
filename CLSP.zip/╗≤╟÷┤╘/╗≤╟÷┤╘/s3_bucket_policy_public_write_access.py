from botocore.exceptions import ClientError
import json

def s3_bucket_policy_public_write_access(s3_client, selected_buckets):
    findings = []

    for bucket_name in selected_buckets:
        status = "PASS"
        status_extended = f"S3 Bucket {bucket_name} does not allow public write access in the bucket policy."

        try:
            # Bucket Policy 확인
            bucket_policy = s3_client.get_bucket_policy(Bucket=bucket_name)
            policy = json.loads(bucket_policy['Policy'])
            policy_statements = policy['Statement']

            for statement in policy_statements:
                if (
                    statement["Effect"] == "Allow"
                    and "Condition" not in statement
                    and (
                        "Principal" in statement
                        and "*" in str(statement["Principal"])
                    )
                    and (
                        (
                            isinstance(statement["Action"], list)
                            and (
                                "s3:PutObject" in statement["Action"]
                                or "*" in statement["Action"]
                                or "s3:*" in statement["Action"]
                                or "s3:Put*" in statement["Action"]
                            )
                        )
                        or (
                            isinstance(statement["Action"], str)
                            and (
                                "s3:PutObject" == statement["Action"]
                                or "*" == statement["Action"]
                                or "s3:*" == statement["Action"]
                                or "s3:Put*" == statement["Action"]
                            )
                        )
                    )
                ):
                    status = "FAIL"
                    status_extended = f"S3 Bucket {bucket_name} allows public write access in the bucket policy."
                    break
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchBucketPolicy':
                status = "PASS"
                status_extended = f"S3 Bucket {bucket_name} does not have a bucket policy."
            else:
                status = "ERROR"
                status_extended = f"Error retrieving policy for bucket {bucket_name}: {str(e)}"

        # Bucket ARN 가져오기
        bucket_location = s3_client.get_bucket_location(Bucket=bucket_name)
        bucket_region = bucket_location['LocationConstraint'] or 'us-east-1'
        bucket_arn = f"arn:aws:s3:::{bucket_name}"

        # Bucket Tags 가져오기
        try:
            bucket_tags = s3_client.get_bucket_tagging(Bucket=bucket_name)['TagSet']
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchTagSet':
                bucket_tags = []
            else:
                status = "ERROR"
                status_extended = f"Error retrieving tags for bucket {bucket_name}: {str(e)}"
                bucket_tags = []

        findings.append({
            'Bucket': bucket_name,
            'Status': status,
            'Details': status_extended,
            'ARN': bucket_arn,
            'Region': bucket_region,
            'Tags': bucket_tags
        })

    return findings
