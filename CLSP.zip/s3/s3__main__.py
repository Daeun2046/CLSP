import boto3
import os
import json
from colorama import Fore, Style, init
import datetime
from dotenv import load_dotenv

from s3.s3_bucket_default_encryption import check_s3_bucket_default_encryption
from s3.s3_bucket_no_mfa_delete import check_s3_bucket_no_mfa_delete
from s3.s3_bucket_object_lock import check_s3_bucket_object_lock
from s3.s3_bucket_policy_public_write_access import check_s3_bucket_policy_public_write_access
from s3.s3_bucket_public_access import check_s3_bucket_public_access
from s3.s3_bucket_secure_transport_policy import check_s3_bucket_secure_transport_policy


def key_pair():
    env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env')

    if os.path.exists(env_path):
        load_dotenv(env_path)
    else:
        open(env_path, 'a').close()

    try:
        

        aws_access_key_id = os.getenv('AWS_ACCESS_KEY_ID')
        aws_secret_access_key = os.getenv('AWS_SECRET_ACCESS_KEY')
        aws_default_region = os.getenv('AWS_DEFAULT_REGION', "ap-northeast-2")

        os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key_id
        os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_access_key
        os.environ['AWS_DEFAULT_REGION'] = aws_default_region

        s3_client = boto3.client('s3')
        response = s3_client.list_buckets()


    except Exception as e:
        aws_access_key_id = input("AWS_ACCESS_KEY_ID: ")

        aws_secret_access_key = input("AWS_SECRET_ACCESS_KEY: ")

        aws_default_region = input("AWS_DEFAULT_REGION (기본값: ap-northeast-2[서울]): ") or "ap-northeast-2"

        os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key_id
        os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_access_key
        os.environ['AWS_DEFAULT_REGION'] = aws_default_region


        with open(env_path, 'w') as f:
            f.write(f"AWS_ACCESS_KEY_ID={aws_access_key_id}\n")
            f.write(f"AWS_SECRET_ACCESS_KEY={aws_secret_access_key}\n")
            f.write(f"AWS_DEFAULT_REGION={aws_default_region}\n")
        
        if not os.environ['AWS_DEFAULT_REGION']:
            os.environ['AWS_DEFAULT_REGION'] = "ap-northeast-2"

        s3_client = boto3.client('s3')
        response = s3_client.list_buckets()


def parse_data(data):
    results = []
    for bucket_name, checks in data.items():
        for check_name, check_results in checks.items():
            for result in check_results:
                results.append({
                    'bucket_name': bucket_name,
                    'check_name': check_name,
                    'arn': result['arn'],
                    'status': result['status']
                })
    return results
def s3_print_pretty_report(data):
    init(autoreset=True)  # 자동으로 색상을 리셋
    if not data:
        print("No data available.")
        return

    instance_id = data[0].get('bucket_name', 'N/A')
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    pass_count = sum(1 for check in data if check['status'] == 'PASS')
    fail_count = sum(1 for check in data if check['status'] == 'FAIL')
    error_count = sum(1 for check in data if check['status'] == 'ERROR')

    print("="*50)
    print(f"{Fore.BLUE}bucket name: {Fore.WHITE}{instance_id}")
    print(f"{Fore.CYAN}Current Time: {Fore.WHITE}{current_time}")
    print(f"{Fore.GREEN}PASS: {pass_count}{Style.RESET_ALL}, {Fore.RED}FAIL: {fail_count}{Style.RESET_ALL}, {Fore.YELLOW}ERROR: {error_count}{Style.RESET_ALL}")
    print("="*50)

    for check in data:
        status_color = Fore.GREEN if check['status'] == 'PASS' else Fore.RED if check['status'] == 'FAIL' else Fore.YELLOW
        print(f"{Fore.MAGENTA}Check Name: {Fore.WHITE}{check['check_name']}")
        print(f"{Fore.MAGENTA}ARN: {Fore.WHITE}{check.get('arn', 'N/A')}")
        print(f"{Fore.MAGENTA}Status: {status_color}{check['status']}{Style.RESET_ALL}")
        print("-"*50)

def read_json_file(filename):
    with open(filename, 'r', encoding='utf-8') as file:
        return json.load(file)

def print_in_box(lines):
    max_length = max(len(f"{index + 1}. {line}") for index, line in enumerate(lines))
    print('╔' + '═' * (max_length + 2) + '╗')
    for index, line in enumerate(lines):
        print(f'║ {index + 1}. {line.ljust(max_length - len(f"{index + 1}. "))} ║')
    print('╚' + '═' * (max_length + 2) + '╝')

def list_s3_buckets():
    response = s3_client.list_buckets()
    buckets = [bucket['Name'] for bucket in response['Buckets']]
    return buckets

def s3_client_info():
    bucket_names = list_s3_buckets()
    print("분석할 S3 버킷을 선택하세요:\n")
    print("0. 모든 버킷")
    print_in_box(bucket_names)
    while True:
        try:
            selection = int(input("번호를 입력하세요: "))
            if selection == 0:
                selected_buckets = bucket_names
                break
            elif 1 <= selection <= len(bucket_names):
                selected_buckets = [bucket_names[selection - 1]]
                break
            else:
                print("유효한 번호를 입력하세요.")
        except ValueError:
            print("숫자를 입력하세요.")

    print(f"선택된 S3 버킷: {', '.join(selected_buckets)}")
    return selected_buckets

# S3 분석 메인 함수
def main():

    key_pair()
    selected_buckets = s3_client_info()
    results = {}
    checklist = [
        (check_s3_bucket_default_encryption, "check_s3_bucket_default_encryption"),
        (check_s3_bucket_no_mfa_delete, "check_s3_bucket_no_mfa_delete"),
        (check_s3_bucket_object_lock, "check_s3_bucket_object_lock"),
        (check_s3_bucket_policy_public_write_access, "check_s3_bucket_policy_public_write_access"),
        (check_s3_bucket_public_access, "check_s3_bucket_public_access"),
        (check_s3_bucket_secure_transport_policy, "check_s3_bucket_secure_transport_policy")
    ]

    for bucket_name in selected_buckets:
        results[bucket_name] = {}
        for checkthis, name in checklist:
            results[bucket_name][name] = checkthis(s3_client)

    script_dir = os.path.dirname(__file__)
    
    base_dir = os.path.join(os.path.abspath(os.path.join(script_dir, '..')), 'results')
    results_dir = os.path.join(base_dir, 'detail_results')

    if not os.path.exists(results_dir):
        os.makedirs(results_dir)
    
    s3_results_path = os.path.join(results_dir, 's3_analysis_results.json')

    with open(s3_results_path, 'w') as json_file:
        json.dump(results, json_file, indent=4, ensure_ascii=False)


    transformed_results = parse_data(results)

    results_dir = os.path.join(base_dir, 'checks')

    if not os.path.exists(results_dir):
        os.makedirs(results_dir)

    s3_checks_path = os.path.join(results_dir, 's3_checks.json')

    with open(s3_checks_path, 'w') as json_file:
        json.dump(transformed_results, json_file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    main()
