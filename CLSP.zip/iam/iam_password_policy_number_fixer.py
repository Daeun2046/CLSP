import boto3
import json

def get_user_name(iam_client):
    """
    제공된 AWS 자격 증명과 연결된 IAM 사용자 이름을 가져옵니다.
    """
    try:
        # IAM 사용자 정보 가져오기
        user_info = iam_client.get_user()
        user_name = user_info['User']['UserName']
        return user_name
    except Exception as error:
        print(f"IAM 사용자 이름을 가져오는 중 오류 발생: {error}")
        return None

def get_account_id():
    """
    STS 클라이언트를 사용하여 계정 ID를 가져옵니다.
    """
    try:
        sts_client = boto3.client('sts')
        identity_info = sts_client.get_caller_identity()
        account_id = identity_info['Account']
        return account_id
    except Exception as error:
        print(f"계정 ID를 가져오는 중 오류 발생: {error}")
        return None

def fixer(iam_client):
    """
    숫자 또는 구성 가능한 값을 요구하도록 IAM 비밀번호 정책을 활성화합니다.
    iam:UpdateAccountPasswordPolicy 권한이 필요합니다.
    """
    findings = []
    try:
        # 사용자 이름을 내부에서 가져오기
        user_name = get_user_name(iam_client)
        if not user_name:
            raise Exception("사용자 이름을 가져오지 못했습니다.")

        # 계정 ID를 가져오기
        account_id = get_account_id()
        if not account_id:
            raise Exception("계정 ID를 가져오지 못했습니다.")

        # IAM 비밀번호 정책 업데이트
        iam_client.update_account_password_policy(
            MinimumPasswordLength=8,
            RequireSymbols=True,
            RequireNumbers=True,
            RequireUppercaseCharacters=True,
            RequireLowercaseCharacters=True,
            AllowUsersToChangePassword=True,
            MaxPasswordAge=90,
            PasswordReusePrevention=24,
            HardExpiry=False
        )
        status_extended = "비밀번호 정책이 성공적으로 업데이트되었습니다."
        status = "PASS"
    except Exception as error:
        status_extended = f"IAM 비밀번호 정책을 업데이트하는 중 오류 발생: {error}"
        status = "FAIL"
        print(status_extended)

    # 결과를 JSON 형식으로 출력
    findings.append(
        {
            "arn": f"arn:aws:iam::{account_id}:user/{user_name}",
            "tag": "",
            "region": "ap-northeast-2",
            "status": status,
            "status_extended": status_extended
        }
    )

    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4, ensure_ascii=False)  # ensure_ascii=False로 한글이 깨지지 않게 설정

if __name__ == "__main__":
    # 사용자 입력으로부터 자격 증명 정보를 받아옴
    aws_access_key_id = input("AWS 액세스 키 ID를 입력하세요: ")
    aws_secret_access_key = input("AWS 시크릿 액세스 키를 입력하세요: ")

    # AWS IAM 클라이언트 생성
    iam_client = boto3.client(
        'iam',
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        region_name='ap-northeast-2'
    )

    # 함수 호출 및 결과 저장
    result = fixer(iam_client)
    if result:
        save_findings_to_json(result, 'iam_password_policy_number_fixer.json')
        print(f"결과가 'iam_password_policy_number_fixer.json' 파일에 저장되었습니다.")
    else:
        print("IAM 비밀번호 정책 업데이트에 실패했습니다.")
