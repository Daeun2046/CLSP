import boto3
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError

def get_aws_client(service, access_key=None, secret_key=None):
    try:
        if access_key and secret_key:
            client = boto3.client(
                service,
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key
            )
        else:
            client = boto3.client(service)
        
        # 테스트 호출로 자격 증명 확인 (STS 클라이언트 사용)
        sts_client = boto3.client(
            'sts',
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key
        ) if access_key and secret_key else boto3.client('sts')
        
        sts_client.get_caller_identity()
        return client
    except (NoCredentialsError, PartialCredentialsError):
        return None
    except ClientError as e:
        if e.response['Error']['Code'] == 'ExpiredToken':
            print("자격 증명이 만료되었습니다.")
            return None
        else:
            raise e

def get_iam_username(access_key=None, secret_key=None):
    try:
        sts_client = boto3.client(
            'sts',
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key
        ) if access_key and secret_key else boto3.client('sts')
        
        identity = sts_client.get_caller_identity()
        arn = identity['Arn']
        username = arn.split('/')[-1]
        return username
    except ClientError as e:
        print(f"Error getting IAM username: {e}")
        return None

def check_password_policy(iam_client):
    findings = []
    try:
        password_policy = iam_client.get_account_password_policy()['PasswordPolicy']
        max_age = password_policy.get('MaxPasswordAge')
        if max_age is None:
            findings.append({
                "arn": "N/A",
                "tag": "N/A",
                "region": "aws-global",
                "status": "FAIL",
                "status_extended": "비밀번호 만료가 설정되지 않았습니다."
            })
        elif max_age <= 90:
            findings.append({
                "arn": "N/A",
                "tag": "N/A",
                "region": "aws-global",
                "status": "PASS",
                "status_extended": f"비밀번호 만료가 90일 이하로 설정되었습니다 ({max_age}일)."
            })
        else:
            findings.append({
                "arn": "N/A",
                "tag": "N/A",
                "region": "aws-global",
                "status": "FAIL",
                "status_extended": f"비밀번호 만료가 90일 이상으로 설정되었습니다 ({max_age}일)."
            })
    except ClientError as e:
        if e.response['Error']['Code'] == 'NoSuchEntity':
            findings.append({
                "arn": "N/A",
                "tag": "N/A",
                "region": "aws-global",
                "status": "ERROR",
                "status_extended": "비밀번호 정책이 설정되지 않았습니다."
            })
        else:
            raise e

    return findings  # 결과 반환

def save_findings_to_json(findings, filename):
    with open(filename, 'w', encoding='UTF-8-sig') as file:
        json.dump(findings, file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    # AWS 자격 증명 입력
    access_key = input("액세스 키: ")
    secret_key = input("비밀 키: ")

    # AWS IAM 클라이언트 생성
    iam_client = get_aws_client('iam', access_key, secret_key)

    if iam_client:
        # IAM 사용자 이름 가져오기
        iam_username = get_iam_username(access_key, secret_key)
        
        if iam_username:
            # 함수 호출 및 결과 저장
            results = check_password_policy(iam_client)
            
            save_findings_to_json(results, 'iam_password_policy_expires_passwords_within_90_days_or_less.json')
            # 결과를 JSON 형식으로 출력
            print(f"Results saved to 'iam_password_policy_expires_passwords_within_90_days_or_less.json'.")
        else:
            print("IAM 사용자 이름을 가져오는 데 실패했습니다.")
    else:
        print("AWS 자격 증명을 확인하세요.")
