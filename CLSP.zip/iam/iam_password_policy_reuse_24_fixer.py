import boto3
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

def initialize_iam_client():
    try:
        iam_client = boto3.client('iam')
    except (NoCredentialsError, PartialCredentialsError):
        print("AWS 자격 증명이 설정되지 않았습니다.")
        access_key = input("AWS Access Key를 입력하세요: ")
        secret_key = input("AWS Secret Key를 입력하세요: ")
        
        # 환경 변수에 저장
        os.environ['AWS_ACCESS_KEY_ID'] = access_key
        os.environ['AWS_SECRET_ACCESS_KEY'] = secret_key
        
        iam_client = boto3.client('iam')
    return iam_client

def get_user_name(iam_client):
    """
    Get the IAM user name associated with the provided AWS credentials.
    """
    try:
        # IAM 사용자 정보 가져오기
        user_info = iam_client.get_user()
        user_name = user_info['User']['UserName']
        return user_name
    except Exception as error:
        print(f"IAM 사용자 이름을 가져오는 중 오류 발생: {error}")
        return None

def fixer(iam_client):
    """
    Enable IAM password policy to prevent reusing the 24 previous passwords.
    Requires the iam:UpdateAccountPasswordPolicy permission.
    """
    user_name = None
    status = "FAIL"
    status_extended = "Unknown error"
    try:
        # 사용자 이름을 내부에서 가져오기
        user_name = get_user_name(iam_client)
        if not user_name:
            raise Exception("사용자 이름을 가져오지 못했습니다.")

        # 기존 비밀번호 정책을 가져오기
        current_policy = iam_client.get_account_password_policy()['PasswordPolicy']

        # 비밀번호 재사용 방지 설정 업데이트
        updated_policy = {
            'MinimumPasswordLength': current_policy.get('MinimumPasswordLength', 8),
            'RequireSymbols': current_policy.get('RequireSymbols', True),
            'RequireNumbers': current_policy.get('RequireNumbers', True),
            'RequireUppercaseCharacters': current_policy.get('RequireUppercaseCharacters', True),
            'RequireLowercaseCharacters': current_policy.get('RequireLowercaseCharacters', True),
            'AllowUsersToChangePassword': current_policy.get('AllowUsersToChangePassword', True),
            'MaxPasswordAge': current_policy.get('MaxPasswordAge', 90),
            'PasswordReusePrevention': 24,  # 비밀번호 재사용 방지 설정
            'HardExpiry': current_policy.get('HardExpiry', False)
        }

        iam_client.update_account_password_policy(**updated_policy)
        status = "PASS"
        status_extended = "비밀번호 정책이 성공적으로 업데이트되었습니다."
    except iam_client.exceptions.NoSuchEntityException:
        print("비밀번호 정책이 설정되어 있지 않습니다.")
        status_extended = "비밀번호 정책이 설정되어 있지 않습니다."
    except Exception as error:
        print(f"오류: {error}")
        status_extended = f"비밀번호 정책 업데이트 중 오류 발생: {error}"
    
    result = [{
        "arn": f"arn:aws:iam::{user_name}" if user_name else "arn:aws:iam::test",
        "tag": "",
        "region": "aws-global",
        "status": status,
        "status_extended": status_extended
    }]
    
    return result

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    # AWS IAM 클라이언트 생성
    iam_client = boto3.client('iam')
    
    # 자격 증명 확인 및 초기화
    iam_client = initialize_iam_client()

    # 함수 호출 및 결과 저장
    findings = fixer(iam_client)
    if findings:
        # 결과를 JSON 형식으로 저장
        save_findings_to_json(findings, 'iam_password_policy_reuse_24_fixer.json')
        
        # 결과를 JSON 형식으로 출력
        print(f"결과가 'iam_password_policy_reuse_24_fixer.json' 파일에 저장되었습니다.")
    else:
        print("IAM 비밀번호 정책 업데이트에 실패했습니다.")
