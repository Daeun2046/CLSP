import boto3
import json

# IAM 클라이언트 생성

def get_users_with_policies(iam_client):
    findings = []

    # 모든 사용자 가져오기
    paginator = iam_client.get_paginator('list_users')
    for page in paginator.paginate():
        for user in page['Users']:
            username = user['UserName']
            user_arn = user['Arn']
            region = 'ap-northeast-2'

            try:
                # 사용자 태그 가져오기
                tags = iam_client.list_user_tags(UserName=username)['Tags']

                # 부착된 정책 가져오기
                attached_policies = iam_client.list_attached_user_policies(UserName=username)['AttachedPolicies']

                # 인라인 정책 가져오기
                inline_policies = iam_client.list_user_policies(UserName=username)['PolicyNames']

                if attached_policies or inline_policies:
                    # 부착된 정책에 대한 리포트 생성
                    for policy in attached_policies:
                        findings.append({
                            'arn': user_arn,
                            'tag': tags,
                            'region': region,
                            'status': 'FAIL',
                            'status_extended': f"사용자 {username}에게 {policy['PolicyName']} 정책이 부착되어 있습니다."
                        })

                    # 인라인 정책에 대한 리포트 생성
                    for policy in inline_policies:
                        findings.append({
                            'arn': user_arn,
                            'tag': tags,
                            'region': region,
                            'status': 'FAIL',
                            'status_extended': f"사용자 {username}에게 {policy} 인라인 정책이 부착되어 있습니다."
                        })
                else:
                    # 정책이 없는 사용자에 대한 리포트 생성
                    findings.append({
                        'arn': user_arn,
                        'tag': tags,
                        'region': region,
                        'status': 'PASS',
                        'status_extended': f"사용자 {username}에게 부착된 인라인 또는 정책이 없습니다."
                    })
            except Exception as e:
                findings.append({
                    'arn': user_arn,
                    'tag': tags,
                    'region': region,
                    'status': 'ERROR',
                    'status_extended': str(e)
                })

    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4)

if __name__ == "__main__":
    iam_client = boto3.client('iam',
                      aws_access_key_id="AKIAXYKJTDP3MQUIMI43",
                      aws_secret_access_key="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",
                      region_name='ap-northeast-2')
    results = get_users_with_policies(iam_client)
    save_findings_to_json(results, 'iam_users_with_policies_findings.json')
    print(f"Results saved to 'iam_users_with_policies_findings.json'.")
