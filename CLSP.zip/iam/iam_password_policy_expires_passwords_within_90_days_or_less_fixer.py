import boto3
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError

def get_aws_client(service, access_key=None, secret_key=None):
    if access_key and secret_key:
        return boto3.client(service, aws_access_key_id=access_key, aws_secret_access_key=secret_key)
    else:
        try:
            client = boto3.client(service)
            # 테스트 호출로 자격 증명 확인 (STS 클라이언트 사용)
            sts_client = boto3.client('sts')
            sts_client.get_caller_identity()
            return client
        except (NoCredentialsError, PartialCredentialsError):
            return None
        except ClientError as e:
            if e.response['Error']['Code'] == 'ExpiredToken':
                print("자격 증명이 만료되었습니다.")
                return None
            else:
                raise e

def check_password_policy(iam_client):
    try:
        password_policy = iam_client.get_account_password_policy()['PasswordPolicy']
        max_age = password_policy.get('MaxPasswordAge')
        if max_age is None:
            return "FAIL", "비밀번호 만료가 설정되지 않았습니다."
        elif max_age <= 90:
            return "PASS", f"비밀번호 만료가 90일 이하로 설정되어 있습니다 ({max_age}일)."
        else:
            return "FAIL", f"비밀번호 만료가 90일 이상으로 설정되어 있습니다 ({max_age}일)."
    except ClientError as e:
        if e.response['Error']['Code'] == 'NoSuchEntity':
            return "FAIL", "비밀번호 정책이 설정되지 않았습니다."
        else:
            raise e

def update_password_policy(iam_client):
    try:
        iam_client.update_account_password_policy(
            MinimumPasswordLength=8,
            RequireSymbols=True,
            RequireNumbers=True,
            RequireUppercaseCharacters=True,
            RequireLowercaseCharacters=True,
            AllowUsersToChangePassword=True,
            MaxPasswordAge=90,
            PasswordReusePrevention=5,
            HardExpiry=False,
        )
        return True
    except ClientError as error:
        print(f"ClientError: {error}")
        return False

def check_password_policy_expires_passwords_within_90_days_or_less_fixer(iam_client):
    findings = []
    try:
        users = iam_client.list_users()['Users']
        for user in users:
            user_name = user['UserName']
            arn = user['Arn']
            region = 'ap-northeast-2'

            status, status_extended = check_password_policy(iam_client)
            findings.append({
                "arn": arn,
                "tag": "",
                "region": region,
                "status": status,
                "status_extended": status_extended
            })

            if status == "FAIL":
                if update_password_policy(iam_client):
                    findings.append({
                        "arn": arn,
                        "tag": "",
                        "region": region,
                        "status": "UPDATED",
                        "status_extended": "비밀번호 정책이 90일 이하로 만료되도록 업데이트되었습니다."
                    })
                else:
                    findings.append({
                        "arn": arn,
                        "tag": "",
                        "region": region,
                        "status": "ERROR",
                        "status_extended": "비밀번호 정책 업데이트에 실패했습니다."
                    })
    except Exception as e:
        findings.append({
            "arn": "unknown",
            "tag": "",
            "region": 'ap-northeast-2',
            "status": 'ERROR',
            "status_extended": str(e)
        })
    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4)

if __name__ == "__main__":
    iam_client = get_aws_client('iam', access_key=os.getenv("AWS_ACCESS_KEY_ID"), secret_key=os.getenv("AWS_SECRET_ACCESS_KEY"))

    if iam_client is None:
        access_key = input("AWS Access Key ID: ")
        secret_key = input("AWS Secret Access Key: ")
        iam_client = get_aws_client('iam', access_key, secret_key)
    
    if iam_client:
        result = check_password_policy_expires_passwords_within_90_days_or_less_fixer(iam_client)
        save_findings_to_json(result, 'iam_password_policy_expires_passwords_within_90_days_or_less_fixer.json')
        print(f"결과가 'iam_password_policy_expires_passwords_within_90_days_or_less_fixer.json' 파일에 저장되었습니다.")
    else:
        print("AWS 클라이언트를 생성할 수 없습니다. 자격 증명을 확인하세요.")

    print(result)
