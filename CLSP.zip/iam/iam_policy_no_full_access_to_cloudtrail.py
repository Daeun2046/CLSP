import boto3
import json

critical_service = "cloudtrail"


def check_policy_no_full_access_to_cloudtrail(iam_client):
    findings = []
    try:
        paginator = iam_client.get_paginator('list_policies')
        for response in paginator.paginate(Scope='Local'):
            for policy in response.get('Policies', []):
                try:
                    # 정책 상세 정보 가져오기
                    policy_response = iam_client.get_policy(PolicyArn=policy['Arn'])
                    policy_version_response = iam_client.get_policy_version(
                        PolicyArn=policy['Arn'], 
                        VersionId=policy_response['Policy']['DefaultVersionId']
                    )
                    policy_document = policy_version_response['PolicyVersion']['Document']

                    # 사용자 정의 정책만 확인
                    if policy_document.get('Statement'):
                        for statement in policy_document['Statement']:
                            if (statement.get('Effect') == 'Allow' and 
                                'Action' in statement and 
                                critical_service + ":*" in statement['Action'] and 
                                (statement.get('Resource') == '*' or statement.get('Resource') == ['*'])):
                                # cloudtrail:* 액션을 허용하는 정책 발견
                                report = {
                                    "arn": policy['Arn'],
                                    "tag": [],  # IAM 정책에는 태그가 없습니다
                                    "region": iam_client.meta.region_name,
                                    "status": "FAIL",
                                    "status_extended": f"사용자 정의 정책 {policy['PolicyName']}이(가) '{critical_service}:*' 권한을 허용합니다."
                                }
                                findings.append(report)
                                break  # 이 정책의 다른 문장을 확인할 필요가 없습니다
                    else:
                        # 문장이 전혀 없는 정책을 처리합니다 (비록 이 경우는 발생하지 않아야 합니다)
                        pass

                except iam_client.exceptions.NoSuchEntityException:
                    # 정책이 존재하지 않거나 삭제된 경우 처리
                    print(f"IAM 정책 {policy['Arn']}이(가) 존재하지 않거나 삭제되었습니다.")
                    continue

                except Exception as e:
                    # 다른 예외 상황 처리
                    print(f"IAM 정책 {policy['Arn']} 처리 중 오류 발생: {str(e)}")
                    continue

    except Exception as e:
        # 페이지네이션이나 IAM 클라이언트 작업 중 발생한 넓은 범위의 예외 처리
        print(f"IAM 작업 중 오류 발생: {str(e)}")
        return {"error": str(e)}
    
    # 발견된 결과가 없으면 PASS 리포트 반환
    if not findings:
        report = {
            "arn": None,
            "tag": [],
            "region": iam_client.meta.region_name,
            "status": "PASS",
            "status_extended": f"'{critical_service}:*' 권한을 허용하는 사용자 정의 정책이 발견되지 않았습니다."
        }
        findings.append(report)
    
    return findings

def main():
    try:
        iam_client = boto3.client('iam',
                      aws_access_key_id="AKIAXYKJTDP3MQUIMI43",
                      aws_secret_access_key="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",
                      region_name='ap-northeast-2')
        findings = check_policy_no_full_access_to_cloudtrail(iam_client)
        
        # JSON 파일로 저장
        with open('check_policy_no_full_access_to_cloudtrail.json', 'w') as json_file:
            json.dump(findings, json_file, indent=4)

        # 결과를 콘솔에 출력
        print(json.dumps(findings, indent=2))

    except Exception as e:
        # 예상치 못한 예외 상황 처리
        print(f"예상치 못한 오류 발생: {str(e)}")

if __name__ == "__main__":
    main()
