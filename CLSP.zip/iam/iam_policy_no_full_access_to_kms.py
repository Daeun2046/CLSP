import boto3
import json

# 검사할 중요 서비스 정의
critical_service = "kms"

def check_policy_no_full_access_to_kms(iam_client):
    findings = []
    specific_policy_arn = "arn:aws:iam::aws:policy/AWSKeyManagementServicePowerUser"
    
    try:
        report = {
            "arn": specific_policy_arn,
            "tag": [],
            "region": iam_client.meta.region_name,
            "status": "PASS",
            "status_extended": f"사용자 정의 정책은 '{critical_service}:*' 권한을 허용하지 않습니다."
        }

        try:
            policy_version_response = iam_client.get_policy_version(
                PolicyArn=specific_policy_arn,
                VersionId=iam_client.get_policy(PolicyArn=specific_policy_arn)['Policy']['DefaultVersionId']
            )
            policy_document = policy_version_response['PolicyVersion']['Document']

            if not isinstance(policy_document["Statement"], list):
                policy_statements = [policy_document["Statement"]]
            else:
                policy_statements = policy_document["Statement"]

            for statement in policy_statements:
                if statement["Effect"] == "Allow" and "Action" in statement:
                    actions = statement["Action"]
                    if not isinstance(actions, list):
                        actions = [actions]

                    if any(action.startswith(critical_service + ":") for action in actions):
                        resources = statement["Resource"]
                        if not isinstance(resources, list):
                            resources = [resources]

                        if "*" in resources:
                            report["status"] = "FAIL"
                            report["status_extended"] = f"사용자 정의 정책은 '{critical_service}:*' 권한을 허용합니다."
                            break

        except iam_client.exceptions.NoSuchEntityException:
            print(f"IAM 정책 {specific_policy_arn}이(가) 존재하지 않거나 삭제되었습니다.")
            return {"error": f"IAM 정책 {specific_policy_arn}이(가) 존재하지 않거나 삭제되었습니다."}
        except Exception as e:
            print(f"IAM 정책 {specific_policy_arn} 처리 중 오류 발생: {str(e)}")
            return {"error": f"IAM 정책 {specific_policy_arn} 처리 중 오류 발생: {str(e)}"}

        findings.append(report)

    except Exception as e:
        print(f"IAM 작업 중 오류 발생: {str(e)}")
        return {"error": str(e)}

    return findings

def main():
    iam_client = boto3.client('iam', region_name='ap-northeast-2')

    results = check_policy_no_full_access_to_kms(iam_client)

    print(json.dumps(results, indent=2, ensure_ascii=False))

    with open('check_policy_no_full_access_to_kms.json', 'w', encoding='UTF-8-sig') as json_file:
        json.dump(results, json_file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    main()
