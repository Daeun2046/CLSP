import json
import boto3

def check_iam_user_two_active_access_keys(iam_client):
    # 이 함수는 IAM 사용자가 두 개의 활성화된 액세스 키를 가지고 있는지 점검하는 코드입니다.
    findings = []

    # IAM 클라이언트 생성
    # iam_client = boto3.client('iam', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key)

    # 자격 증명 보고서 가져오기
    response = iam_client.get_credential_report()
    credential_report = response['Content'].decode('utf-8').split('\n')

    # 자격 증명 보고서 파싱
    for user in credential_report[1:-1]:  # 첫 번째 행(헤더)와 마지막 빈 행을 제외
        user_details = user.split(',')
        user_name = user_details[0]  # 사용자 이름
        user_arn = user_details[1]  # 사용자 ARN
        access_key_1_active = user_details[8] == 'true'  # 액세스 키 1 활성화 여부
        access_key_2_active = user_details[14] == 'true'  # 액세스 키 2 활성화 여부

        # 두 개의 활성화된 액세스 키를 가지고 있는 경우
        if access_key_1_active and access_key_2_active:
            finding = {
                'resource_id': user_name,
                'resource_arn': user_arn,
                'status': 'FAIL',
                'status_extended': f'User {user_name} has 2 active access keys.'
            }
        else:
            # 두 개의 활성화된 액세스 키를 가지고 있지 않은 경우
            finding = {
                'resource_id': user_name,
                'resource_arn': user_arn,
                'status': 'PASS',
                'status_extended': f'User {user_name} does not have 2 active access keys.'
            }
        findings.append(finding)

    return findings  # 결과 반환

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4)

# 결과 실행 및 출력
if __name__ == '_main_':
    iam_client = boto3.client('iam', 
                             aws_access_key_id="AKIAXYKTJDP3MQUMI43", 
                             aws_secret_access_key="TXGCZQ1xBwFZQrWxLbImXHhHu4NYstYuAFU79PNh",
                             region_name="ap-northeast-2")
    result = check_iam_user_two_active_access_keys(iam_client)
    save_findings_to_json(result, "iam_user_mfa_enabled_console_access.json")
    print("Results saved to 'iam_user_mfa_enabled_console_access.json'")