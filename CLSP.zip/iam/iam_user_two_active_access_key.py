import json
import boto3

def check_iam_user_two_active_access_keys(iam_client):
    # 이 함수는 IAM 사용자가 두 개의 활성화된 액세스 키를 가지고 있는지 점검하는 코드입니다.
    findings = []

    # IAM 클라이언트 생성
    # iam_client = boto3.client('iam', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key)

    # 자격 증명 보고서 가져오기
    response = iam_client.get_credential_report()
    credential_report = response['Content'].decode('utf-8').split('\n')

    # 자격 증명 보고서 파싱
    for user in credential_report[1:-1]:  # 첫 번째 행(헤더)와 마지막 빈 행을 제외
        user_details = user.split(',')
        user_name = user_details[0]  # 사용자 이름
        user_arn = user_details[1]  # 사용자 ARN
        access_key_1_active = user_details[8] == 'true'  # 액세스 키 1 활성화 여부
        access_key_2_active = user_details[14] == 'true'  # 액세스 키 2 활성화 여부

        # 두 개의 활성화된 액세스 키를 가지고 있는 경우
        if access_key_1_active and access_key_2_active:
            finding = {
                'resource_id': user_name,
                'resource_arn': user_arn,
                'status': 'FAIL',
                'status_extended': f'{user_name} 사용자에게 2개의 활성 액세스 키가 있습니다.'
            }
        else:
            # 두 개의 활성화된 액세스 키를 가지고 있지 않은 경우
            finding = {
                'resource_id': user_name,
                'resource_arn': user_arn,
                'status': 'PASS',
                'status_extended': f'{user_name} 사용자에게 2개의 활성 액세스 키가 없습니다.'
            }
        findings.append(finding)

    results = []

    for finding in findings:
        result = {
            'arn': finding['resource_arn'],
            'tag': '',  # Tag information is not available
            'region': '',  # Region information is not available
            'status': finding['status'],
            'status_extended': finding['status_extended']
        }
        results.append(result)

    return results  # 결과 반환

def save_findings_to_json(findings, filename):
    # 결과를 JSON 파일로 저장
    with open(filename, 'w',encoding='UTF-8-sig') as file:
        json.dump(findings, file, indent=4, ensure_ascii=False)

# 결과 실행 및 출력
if __name__ == '__main__':
    iam_client = boto3.client('iam')
    result = check_iam_user_two_active_access_keys(iam_client)
    save_findings_to_json(result, "iam_user_mfa_enabled_console_access.json")
    print("Results saved to 'iam_user_mfa_enabled_console_access.json'")
