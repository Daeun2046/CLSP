import boto3
import json
from botocore.exceptions import ClientError

def iam_check_saml_providers_sts(iam_client):
    findings = []  # 결과를 저장할 리스트 초기화

    try:
        # SAML 공급자 리스트를 가져옴
        response = iam_client.list_saml_providers()
        # SAML 공급자가 있는지 확인
        if 'SAMLProviderList' in response and response['SAMLProviderList']:
            # 각 SAML 공급자를 순회
            for provider in response['SAMLProviderList']:
                provider_arn = provider['Arn']  # 공급자의 ARN을 가져옴
                provider_name = provider_arn.split('/')[-1]  # ARN에서 공급자 이름을 추출

                # 기본 상태 및 상태 확장 메시지 설정
                status = "PASS"
                status_extended = f"SAML 공급자 {provider_name}이(가) 발견되었습니다."

                # 결과 리스트에 현재 공급자의 상태 추가
                findings.append({
                    "arn": f"{provider_arn}",
                    "tag": "N/A",  # IAM SAML 공급자에는 태그가 적용되지 않음
                    "region": iam_client.meta.region_name,
                    "status": status,
                    "status_extended": status_extended
                })
        else:
            # SAML 공급자가 없는 경우
            findings.append({
                "arn": "N/A",
                "tag": "N/A",
                "region": iam_client.meta.region_name,
                "status": "INFO",
                "status_extended": "계정에 SAML 공급자가 구성되어 있지 않습니다."
            })

    except ClientError as e:
        # 예외 발생 시 에러 메시지와 함께 결과 리스트에 추가
        findings.append({
            "arn": "N/A",
            "tag": "N/A",
            "region": "N/A",
            "status": "ERROR",
            "status_extended": f"IAM SAML 공급자를 검색하는 중 오류 발생: {str(e)}"
        })

    return findings  # 결과 리스트 반환

if __name__ == "__main__":
    # AWS IAM 클라이언트 생성
    iam_client = boto3.client('iam')

    # 함수 호출 및 결과 저장
    result = iam_check_saml_providers_sts2(iam_client)

    # 결과를 JSON 형식으로 출력
    print(json.dumps(result, indent=4, ensure_ascii=False))

    # 결과를 JSON 형식으로 파일 만들기
    # with open('iam_check_saml_providers_sts.json', 'w') as json_file:
    #     json.dump(result, json_file, indent=4, ensure_ascii=False)
