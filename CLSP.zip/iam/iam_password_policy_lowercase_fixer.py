import boto3
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError
import getpass

def get_aws_client(service):
    try:
        # Boto3 클라이언트 생성
        client = boto3.client(service)
        return client
    except (NoCredentialsError, PartialCredentialsError):
        print("AWS 자격 증명이 없습니다. 액세스 키와 비밀 키를 입력하세요.")
        access_key = input("AWS Access Key: ")
        secret_key = getpass.getpass("AWS Secret Key: ")

        # 자격 증명을 사용하여 클라이언트 생성
        session = boto3.Session(
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key
        )
        client = session.client(service)
        return client

def check_password_policy(iam_client):
    findings = []
    try:
        password_policy = iam_client.get_account_password_policy()
        findings.append({
            "arn": "arn:aws:iam::637423416030:user/daeun",
            "tag": "",
            "region": iam_client.meta.region_name,
            "status": "PASS" if password_policy['PasswordPolicy'].get('RequireLowercaseCharacters') else "FAIL",
            "status_extended": "Password expiration is set lower than 90 days (90 days)." if password_policy['PasswordPolicy'].get('RequireLowercaseCharacters') else "IAM 비밀번호 정책은 소문자를 요구하지 않습니다."
        })
    except iam_client.exceptions.NoSuchEntityException:
        findings.append({
            "arn": "arn:aws:iam::637423416030:user/daeun",
            "tag": "",
            "region": iam_client.meta.region_name,
            "status": "ERROR",
            "status_extended": "비밀번호 정책이 설정되지 않았습니다."
        })
    except Exception as e:
        findings.append({
            "arn": "arn:aws:iam::637423416030:user/daeun",
            "tag": "",
            "region": iam_client.meta.region_name,
            "status": "ERROR",
            "status_extended": str(e)
        })
    return findings

def update_password_policy(iam_client):
    findings = []
    try:
        # 비밀번호 정책 업데이트
        iam_client.update_account_password_policy(
            MinimumPasswordLength=12,
            RequireSymbols=True,
            RequireNumbers=True,
            RequireUppercaseCharacters=True,
            RequireLowercaseCharacters=True,  # 여기서는 소문자 요구를 반드시 True로 설정
            AllowUsersToChangePassword=True,
            MaxPasswordAge=90,
            PasswordReusePrevention=5,
            HardExpiry=False,
        )
        findings.append({
            "arn": "arn:aws:iam::637423416030:user/daeun",
            "tag": "",
            "region": iam_client.meta.region_name,
            "status": "SUCCESS",
            "status_extended": "IAM 비밀번호 정책이 성공적으로 업데이트되었습니다."
        })
    except Exception as e:
        findings.append({
            "arn": "arn:aws:iam::637423416030:user/daeun",
            "tag": "",
            "region": iam_client.meta.region_name,
            "status": "ERROR",
            "status_extended": str(e)
        })
    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w', encoding='utf-8') as file:
        json.dump(findings, file, ensure_ascii=False, indent=4)

if __name__ == "__main__":
    # AWS IAM 클라이언트 생성
    iam_client = get_aws_client('iam')

    # 함수 호출 및 결과 저장
    result = update_password_policy(iam_client)
    save_findings_to_json(result, 'iam_password_policy_lowercase_fixer.json')
    # 결과를 JSON 형식으로 출력
    print("결과가 'iam_password_policy_lowercase_fixer.json' 파일에 저장되었습니다.")
