import boto3
import json
from botocore.exceptions import ClientError

def iam_aws_attached_policy_no_administrative_privileges(iam_client):
    findings = []  # 결과를 저장할 리스트 초기화

    try:
        # 모든 정책을 가져오기 위해 페이지 처리 설정
        paginator = iam_client.get_paginator('list_policies')
        # 페이지 처리된 정책 리스트를 순회
        policies_exist = False  # 정책이 있는지 확인하는 플래그

        for response in paginator.paginate(Scope='Local'):
            if 'Policies' not in response or not response['Policies']:
                continue  # 응답에 'Policies' 키가 없거나 리스트가 비어있으면 다음으로 넘어감

            policies_exist = True  # 정책이 존재함을 플래그로 표시
            for policy in response['Policies']:
                policy_name = policy['PolicyName']  # 정책 이름 가져오기
                policy_arn = policy['Arn']  # 정책 ARN 가져오기

                # 정책이 연결된 엔터티를 확인
                attached_entities = iam_client.list_entities_for_policy(PolicyArn=policy_arn)
                # 정책이 어떤 엔터티에도 연결되지 않았으면 다음으로 넘어감
                if not attached_entities['PolicyGroups'] and not attached_entities['PolicyUsers'] and not attached_entities['PolicyRoles']:
                    continue

                # 기본 상태 및 상태 확장 메시지 설정
                status = "PASS"
                status_extended = f"AWS 정책 {policy_name}은 '*:*' 관리 권한을 허용하지 않습니다."

                # 정책의 기본 버전을 가져오기
                policy_version = iam_client.get_policy_version(
                    PolicyArn=policy_arn, 
                    VersionId=policy['DefaultVersionId']
                )['PolicyVersion']['Document']

                # 정책 문서에 'Statement'가 있는지 확인
                if 'Statement' in policy_version:
                    # 'Statement'가 리스트가 아니면 리스트로 변환
                    if not isinstance(policy_version['Statement'], list):
                        policy_statements = [policy_version['Statement']]
                    else:
                        policy_statements = policy_version['Statement']

                    # 각 'Statement'를 순회하며 조건 확인
                    for statement in policy_statements:
                        # "Effect": "Allow"와 "Action": "*" 그리고 "Resource": "*"인 경우 확인
                        if (
                            statement.get('Effect') == 'Allow'
                            and 'Action' in statement
                            and (
                                statement['Action'] == '*' or isinstance(statement['Action'], list) and '*' in statement['Action']
                            )
                            and (
                                statement['Resource'] == '*' or isinstance(statement['Resource'], list) and '*' in statement['Resource']
                            )
                        ):
                            # 조건에 맞으면 상태를 "FAIL"로 변경하고 확장 메시지 수정
                            status = "FAIL"
                            status_extended = f"AWS 정책 {policy_name}은 '*:*' 관리 권한을 허용합니다."
                            break

                # 결과 리스트에 현재 정책의 상태 추가
                findings.append({
                    "arn": f"{policy_arn}",
                    "tag": "N/A",  # IAM 정책에는 태그가 적용되지 않음
                    "region": iam_client.meta.region_name,
                    "status": status,
                    "status_extended": status_extended
                })

        # 정책이 존재하지 않으면 해당 메시지 추가
        if not policies_exist:
            findings.append({
                "arn": "N/A",
                "tag": "N/A",
                "region": "N/A",
                "status": "INFO",
                "status_extended": "계정에 정책이 정의되어 있지 않습니다."
            })

    except ClientError as e:
        # 예외 발생 시 에러 메시지와 함께 결과 리스트에 추가
        findings.append({
            "arn": "N/A",
            "tag": "N/A",
            "region": "N/A",
            "status": "ERROR",
            "status_extended": f"IAM 정책을 검색하는 중 오류 발생: {str(e)}"
        })

    return findings  # 결과 리스트 반환

if __name__ == "__main__":
    # AWS IAM 클라이언트 생성
    iam_client = boto3.client('iam')

    # 함수 호출 및 결과 저장
    result = iam_aws_attached_policy_no_administrative_privileges2(iam_client)

    # 결과를 JSON 형식으로 출력
    print(json.dumps(result, indent=4, ensure_ascii=False))

    # 결과를 JSON 형식으로 파일 만들기
    # with open('iam_aws_attached_policy_no_administrative_privileges.json', 'w') as json_file:
    #     json.dump(result, json_file, indent=4, ensure_ascii=False)
