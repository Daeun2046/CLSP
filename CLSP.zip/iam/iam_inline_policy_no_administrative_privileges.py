import boto3
import json
from botocore.exceptions import ClientError  # ClientError 예외를 사용하기 위해 가져옴

def iam_inline_policy_no_administrative_privileges(iam_client):
    findings = []  # 결과를 저장할 리스트 초기화

    try:
        # 사용자 지정 정책 중 연결된 것들만 가져옴
        response = iam_client.list_policies(Scope='Local', OnlyAttached=True, PolicyUsageFilter='PermissionsPolicy')

        # 인라인 정책이 없는 경우를 확인하기 위한 플래그
        inline_policies_found = False

        # 각 정책을 순회
        for policy in response['Policies']:
            # INLINE 정책이 아닌 경우 건너뜀
            if policy['PolicyType'] != 'INLINE':
                continue

            inline_policies_found = True  # 인라인 정책이 발견되었음을 표시
            
            policy_name = policy['PolicyName']  # 정책 이름 가져오기
            policy_arn = policy['Arn']  # 정책 ARN 가져오기

            # 기본 상태 및 상태 확장 메시지 설정
            status = "PASS"
            status_extended = f"IAM 식별자 {policy_arn}의 인라인 정책 {policy_name}은 '*:*' 관리 권한을 허용하지 않습니다."

            # 정책의 기본 버전 문서 가져오기
            policy_document = iam_client.get_policy_version(PolicyArn=policy_arn, VersionId=policy['DefaultVersionId'])['PolicyVersion']['Document']
            if policy_document:  # 정책 문서가 있는지 확인
                # 'Statement'가 리스트가 아니면 리스트로 변환
                if not isinstance(policy_document['Statement'], list):
                    policy_statements = [policy_document['Statement']]
                else:
                    policy_statements = policy_document['Statement']
                
                # 각 'Statement'를 순회하며 조건 확인
                for statement in policy_statements:
                    # "Effect": "Allow"와 "Action": "*" 그리고 "Resource": "*"인 경우 확인
                    if (
                        statement['Effect'] == 'Allow'  # "Effect"가 "Allow"인지 확인
                        and 'Action' in statement  # "Action" 키가 존재하는지 확인
                        and (
                            statement['Action'] == '*'  # "Action"이 "*"인지 확인
                            or statement['Action'] == ['*']  # "Action"이 ["*"] 리스트인지 확인
                        )
                        and (
                            statement['Resource'] == '*'  # "Resource"가 "*"인지 확인
                            or statement['Resource'] == ['*']  # "Resource"가 ["*"] 리스트인지 확인
                        )
                    ):
                        # 조건에 맞으면 상태를 "FAIL"로 변경하고 확장 메시지 수정
                        status = "FAIL"
                        status_extended = f"IAM 식별자 {policy_arn}의 인라인 정책 {policy_name}은 '*:*' 관리 권한을 허용합니다."
                        break  # 조건에 맞는 정책을 찾으면 더 이상 반복하지 않음

            # 결과 리스트에 현재 정책의 상태 추가
            findings.append({
                "arn": policy_arn,  # 정책 ARN 설정
                "tag": "N/A",  # IAM 인라인 정책에는 태그가 적용되지 않음
                "region": iam_client.meta.region_name,  # 현재 AWS 리전 설정
                "status": status,  # 상태 설정
                "status_extended": status_extended  # 확장 상태 메시지 설정
            })

        # 인라인 정책이 없는 경우
        if not inline_policies_found:
            findings.append({
                "arn": "N/A",
                "tag": "N/A",
                "region": iam_client.meta.region_name,
                "status": "INFO",
                "status_extended": "계정에 인라인 정책이 구성되어 있지 않습니다."
            })

    except ClientError as e:  # 예외 발생 시 처리
        # 예외 발생 시 에러 메시지와 함께 결과 리스트에 추가
        findings.append({
            "arn": "N/A",  # ARN을 가져올 수 없으므로 N/A 설정
            "tag": "N/A",  # 태그를 가져올 수 없으므로 N/A 설정
            "region": "N/A",  # 리전을 가져올 수 없으므로 N/A 설정
            "status": "ERROR",  # 상태를 "ERROR"로 설정
            "status_extended": f"IAM 인라인 정책을 검색하는 중 오류 발생: {str(e)}"  # 예외 메시지를 확장 상태 메시지로 설정
        })

    return findings  # 결과 리스트 반환

if __name__ == "__main__":
    # AWS IAM 클라이언트 생성
    iam_client = boto3.client('iam')

    # 함수 호출 및 결과 저장
    result = iam_inline_policy_no_administrative_privileges2(iam_client)

    # 결과를 JSON 형식으로 출력
    print(json.dumps(result, indent=4))

    # 결과를 JSON 형식으로 파일 만들기
    # with open('iam_inline_policy_no_administrative_privileges.json', 'w') as json_file:
    #     json.dump(result, json_file, indent=4)
