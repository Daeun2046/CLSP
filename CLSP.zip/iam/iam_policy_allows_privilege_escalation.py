import boto3
import json

# IAM 클라이언트 생성

# 권한 상승 가능한 조합 정의
privilege_escalation_policies_combination = {
    "OverPermissiveIAM": {"iam:*"},
    "IAMPut": {"iam:Put*"},
    "CreatePolicyVersion": {"iam:CreatePolicyVersion"},
    "SetDefaultPolicyVersion": {"iam:SetDefaultPolicyVersion"},
    "iam:PassRole": {"iam:PassRole"},
    "PassRole+EC2": {
        "iam:PassRole",
        "ec2:RunInstances",
    },
    "PassRole+CreateLambda+Invoke": {
        "iam:PassRole",
        "lambda:CreateFunction",
        "lambda:InvokeFunction",
    },
    "PassRole+CreateLambda+ExistingDynamo": {
        "iam:PassRole",
        "lambda:CreateFunction",
        "lambda:CreateEventSourceMapping",
    },
    "PassRole+CreateLambda+NewDynamo": {
        "iam:PassRole",
        "lambda:CreateFunction",
        "lambda:CreateEventSourceMapping",
        "dynamodb:CreateTable",
        "dynamodb:PutItem",
    },
    "PassRole+GlueEndpoint": {
        "iam:PassRole",
        "glue:CreateDevEndpoint",
        "glue:GetDevEndpoint",
    },
    "PassRole+GlueEndpoints": {
        "iam:PassRole",
        "glue:CreateDevEndpoint",
        "glue:GetDevEndpoints",
    },
    "PassRole+CloudFormation": {
        "iam:PassRole",
        "cloudformation:CreateStack",
        "cloudformation:DescribeStacks",
    },
    "PassRole+DataPipeline": {
        "iam:PassRole",
        "datapipeline:CreatePipeline",
        "datapipeline:PutPipelineDefinition",
        "datapipeline:ActivatePipeline",
    },
    "GlueUpdateDevEndpoint": {"glue:UpdateDevEndpoint"},
    "GlueUpdateDevEndpoints": {"glue:UpdateDevEndpoints"},
    "lambda:UpdateFunctionCode": {"lambda:UpdateFunctionCode"},
    "iam:CreateAccessKey": {"iam:CreateAccessKey"},
    "iam:CreateLoginProfile": {"iam:CreateLoginProfile"},
    "iam:UpdateLoginProfile": {"iam:UpdateLoginProfile"},
    "iam:AttachUserPolicy": {"iam:AttachUserPolicy"},
    "iam:AttachGroupPolicy": {"iam:AttachGroupPolicy"},
    "iam:AttachRolePolicy": {"iam:AttachRolePolicy"},
    "AssumeRole+AttachRolePolicy": {"sts:AssumeRole", "iam:AttachRolePolicy"},
    "iam:PutGroupPolicy": {"iam:PutGroupPolicy"},
    "iam:PutRolePolicy": {"iam:PutRolePolicy"},
    "AssumeRole+PutRolePolicy": {"sts:AssumeRole", "iam:PutRolePolicy"},
    "iam:PutUserPolicy": {"iam:PutUserPolicy"},
    "iam:AddUserToGroup": {"iam:AddUserToGroup"},
    "iam:UpdateAssumeRolePolicy": {"iam:UpdateAssumeRolePolicy"},
    "AssumeRole+UpdateAssumeRolePolicy": {
        "sts:AssumeRole",
        "iam:UpdateAssumeRolePolicy",
    },
}

def check_privilege_escalation(iam_client):
    findings = []

    # 모든 고객 관리형 정책 가져오기
    paginator = iam_client.get_paginator('list_policies')

    for page in paginator.paginate(Scope='All'):
        for policy in page['Policies']:
            if policy['AttachmentCount'] > 0:
                policy_arn = policy['Arn']
                policy_name = policy['PolicyName']

                try:
                    # 정책 버전 가져오기
                    policy_version = iam_client.get_policy_version(
                        PolicyArn=policy_arn,
                        VersionId=policy['DefaultVersionId']
                    )
                    policy_document = policy_version['PolicyVersion']['Document']

                    allowed_actions = set()
                    denied_actions = set()
                    denied_not_actions = set()

                    # 정책 문서 분석
                    if not isinstance(policy_document['Statement'], list):
                        policy_statements = [policy_document['Statement']]
                    else:
                        policy_statements = policy_document['Statement']

                    for statement in policy_statements:
                        effect = statement['Effect']

                        if effect == 'Allow':
                            actions = statement.get('Action', [])
                            if isinstance(actions, str):
                                allowed_actions.add(actions)
                            elif isinstance(actions, list):
                                allowed_actions.update(actions)

                        if effect == 'Deny':
                            actions = statement.get('Action', [])
                            not_actions = statement.get('NotAction', [])
                            if isinstance(actions, str):
                                denied_actions.add(actions)
                            elif isinstance(actions, list):
                                denied_actions.update(actions)

                            if isinstance(not_actions, str):
                                denied_not_actions.add(not_actions)
                            elif isinstance(not_actions, list):
                                denied_not_actions.update(not_actions)

                    # DENY의 액션을 제외한 허용된 액션 찾기
                    left_actions = allowed_actions.difference(denied_actions)
                    if denied_not_actions:
                        privileged_actions = left_actions.intersection(denied_not_actions)
                    else:
                        privileged_actions = left_actions

                    policies_combination = set()

                    for values in privilege_escalation_policies_combination.values():
                        for val in values:
                            val_set = {val}
                            if privileged_actions.intersection(val_set) == val_set:
                                policies_combination.add(val)
                            else:
                                for permission in privileged_actions:
                                    api_action = permission.split(":")
                                    if len(api_action) == 2:
                                        api = api_action[0]
                                        action = api_action[1]
                                        if action == "*":
                                            val_api = val.split(":")[0]
                                            if api == val_api:
                                                policies_combination.add(val)
                                    elif len(api_action) == 1:
                                        api = api_action[0]
                                        if api == "*":
                                            policies_combination.add(val)

                    combos = set()
                    for key, values in privilege_escalation_policies_combination.items():
                        intersection = policies_combination.intersection(values)
                        if intersection == values:
                            combos.add(key)

                    tags = []
                    try:
                        # 태그 가져오기
                        tags_response = iam_client.list_policy_tags(PolicyArn=policy_arn)
                        tags = tags_response.get('Tags', [])
                    except Exception as tag_exception:
                        pass  # 태그 가져오기에 실패해도 에러를 무시하고 진행

                    report = {
                        'arn': policy_arn,
                        'tag': tags,
                        'region': 'ap-northeast-2',
                        'status': 'PASS',
                        'status_extended': f"사용자 지정 정책 {policy_arn}는 권한 상승을 허용하지 않습니다."
                    }

                    if combos:
                        report['status'] = 'FAIL'
                        policies_affected = " ".join([str(privilege_escalation_policies_combination[key]) for key in combos])
                        report['status_extended'] = (
                            f"사용자 지정 정책 {policy_arn}는 다음 작업을 사용하여 권한 상승을 허용합니다: {policies_affected}."
                        )
                    
                    findings.append(report)
                except Exception as e:
                    findings.append({
                        'arn': policy_arn,
                        'tag': [],
                        'region': 'ap-northeast-2',
                        'status': 'ERROR',
                        'status_extended': str(e)
                    })
    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4)

# 결과 실행 및 출력
if __name__ == "__main__":
    iam_client = boto3.client('iam',
                    aws_access_key_id="AKIAXYKJTDP3MQUIMI43",
                    aws_secret_access_key="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",
                    region_name='ap-northeast-2')
    result = check_privilege_escalation(iam_client)
    save_findings_to_json(result, 'iam_privilege_escalation_findings.json')
    print(f"Results saved to 'iam_privilege_escalation_findings.json'.")
