import boto3
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError

def get_aws_client(service, access_key=None, secret_key=None, region=None):
    try:
        if access_key and secret_key:
            return boto3.client(service, aws_access_key_id=access_key, aws_secret_access_key=secret_key, region_name=region)
        else:
            client = boto3.client(service, region_name=region)
            sts_client = boto3.client('sts', region_name=region)
            sts_client.get_caller_identity()
            return client
    except (NoCredentialsError, PartialCredentialsError):
        return None
    except ClientError as e:
        if e.response['Error']['Code'] == 'ExpiredToken':
            print("자격 증명이 만료되었습니다.")
            return None
        else:
            raise e

def check_no_root_access_key(iam_client):
    findings = []
    try:
        response = iam_client.get_credential_report()
        credential_report = response['Content'].decode('utf-8').split('\n')
        headers = credential_report[0].split(',')
        for line in credential_report[1:]:
            user_data = line.split(',')
            user = dict(zip(headers, user_data))
            user_name = user["user"]
            if user_name == "<root_account>":
                user_name = "root_account"
            arn = user.get("arn", "N/A")
            region = iam_client.meta.region_name

            if user["access_key_1_active"] == "false" and user["access_key_2_active"] == "false":
                status = "PASS"
                status_extended = f"사용자 {user_name}는 액세스 키가 없습니다."
            elif user["access_key_1_active"] == "true" and user["access_key_2_active"] == "true":
                status = "FAIL"
                status_extended = f"사용자 {user_name}는 두 개의 활성 액세스 키가 있습니다."
            else:
                status = "FAIL"
                status_extended = f"사용자 {user_name}는 하나의 활성 액세스 키가 있습니다."

            findings.append({
                "arn": arn,
                "tag": "",
                "region": region,
                "status": status,
                "status_extended": status_extended
            })
    except Exception as e:
        findings.append({
            "arn": "N/A",
            "tag": "",
            "region": iam_client.meta.region_name,
            "status": "ERROR",
            "status_extended": str(e)
        })
    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4)

if __name__ == "__main__":
    # AWS IAM 클라이언트 생성
    region = 'ap-northeast-2'
    iam_client = get_aws_client('iam', region=region)

    if not iam_client:
        access_key = input("액세스 키를 입력하세요: ")
        secret_key = input("비밀 키를 입력하세요: ")
        iam_client = get_aws_client('iam', access_key=access_key, secret_key=secret_key, region=region)

    if iam_client:
        # 함수 호출 및 결과 저장
        result = check_no_root_access_key(iam_client)
        save_findings_to_json(result, 'iam_no_root_access_key.json')
        # 결과를 JSON 형식으로 출력
        print("'iam_no_root_access_key.json' 파일에 결과가 저장되었습니다.")
    else:
        print("AWS 클라이언트를 생성할 수 없습니다.")

    print(result)
