import boto3
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

def initialize_iam_client():
    try:
        iam_client = boto3.client('iam', region_name='us-east-1')
        # 자격 증명이 올바른지 확인하기 위해 간단한 API 호출
        iam_client.get_account_password_policy()
    except (NoCredentialsError, PartialCredentialsError):
        print("AWS 자격 증명이 설정되지 않았습니다.")
        access_key = input("AWS Access Key ID를 입력하세요: ")
        secret_key = input("AWS Secret Access Key를 입력하세요: ")
        
        # 환경 변수에 저장
        os.environ['AWS_ACCESS_KEY_ID'] = access_key
        os.environ['AWS_SECRET_ACCESS_KEY'] = secret_key
        
        iam_client = boto3.client('iam', region_name='us-east-1')
    except boto3.client('iam', region_name='us-east-1').exceptions.NoSuchEntityException:
        print("비밀번호 정책이 설정되어 있지 않습니다.")
        return None
    return iam_client

def check_password_policy_symbol(iam_client):
    findings = []
    if iam_client:
        try:
            password_policy = iam_client.get_account_password_policy()['PasswordPolicy']
            if password_policy.get('RequireSymbols', False):
                status = "PASS"
                status_extended = "IAM 비밀번호 정책에는 적어도 하나의 기호가 필요합니다."
            else:
                status = "FAIL"
                status_extended = "IAM 비밀번호 정책에는 기호가 필요하지 않습니다."

        except iam_client.exceptions.NoSuchEntityException:
            print("비밀번호 정책이 설정되어 있지 않습니다.")
            status = "FAIL"
            status_extended = "비밀번호 정책이 설정되지 않았습니다."
        except Exception as e:
            print(f"Error checking IAM password policy: {e}")
            status = "ERROR"
            status_extended = "계정에 사용자 지정 정책이 없습니다."
    else:
        status = "ERROR"
        status_extended = "계정에 사용자 지정 정책이 없습니다."

    findings = [{
        "arn": "N/A",
        "tag": "N/A",
        "region": "aws-global",
        "status": status,
        "status_extended": status_extended
    }]
    
    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    iam_client = initialize_iam_client()
    result = check_password_policy_symbol(iam_client)
    save_findings_to_json(result, 'iam_password_policy_symbol.json')
    print(f"Results saved to 'iam_password_policy_symbol.json'.")
