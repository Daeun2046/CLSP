import boto3
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError

def get_aws_credentials():
    print("AWS 자격 증명이 필요합니다.")
    aws_access_key_id = input("AWS Access Key ID를 입력하세요: ")
    aws_secret_access_key = input("AWS Secret Access Key를 입력하세요: ")

    # Set environment variables
    os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key_id
    os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_access_key

    return aws_access_key_id, aws_secret_access_key

def check_iam_password_policy_minimum_length_14(iam_client):
    try:
        sts_client = boto3.client('sts', region_name='ap-northeast-2')  # 리전 설정 추가
        account_id = sts_client.get_caller_identity().get('Account')
        region = boto3.session.Session().region_name
        user_name = iam_client.get_user()['User']['UserName']
        findings = []

        try:
            password_policy = iam_client.get_account_password_policy()
            if 'PasswordPolicy' in password_policy:
                if password_policy['PasswordPolicy']['MinimumPasswordLength'] >= 14:
                    status = "PASS"
                    status_extended = "IAM 비밀번호 정책의 최소 길이는 14자 이상입니다."
                else:
                    status = "FAIL"
                    status_extended = "IAM 비밀번호 정책의 최소 길이는 14자 이상이 아닙니다."
            else:
                status = "FAIL"
                status_extended = "IAM 비밀번호 정책을 찾을 수 없습니다."
        except iam_client.exceptions.NoSuchEntityException:
            status = "INFO"
            status_extended = "계정에 사용자 지정 정책이 없습니다."
        except Exception as e:
            status = "FAIL"
            status_extended = str(e)

        findings.append(
            {
                "arn": f"arn:aws:iam::{account_id}:user/{user_name}" if user_name else "N/A",
                "tag": "N/A",
                "region": region if region else "aws-global",
                "status": status,
                "status_extended": status_extended
            }
        )
        return findings

    except (NoCredentialsError, PartialCredentialsError):
        aws_access_key_id, aws_secret_access_key = get_aws_credentials()
        os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key_id
        os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_access_key
        return check_iam_password_policy_minimum_length_14(iam_client)  # 재귀 호출로 다시 시도

    except Exception as error:
        print(f"Error occurred: {error}")
        return []

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4)

if __name__ == "__main__":
    # AWS IAM 클라이언트 생성
    aws_access_key_id = input("액세스 키: ")
    aws_secret_access_key = input("비밀 키: ")

    iam_client = boto3.client('iam', 
                              aws_access_key_id=aws_access_key_id,
                              aws_secret_access_key=aws_secret_access_key,
                              region_name='ap-northeast-2')

    # 함수 호출 및 결과 저장
    result = check_iam_password_policy_minimum_length_14(iam_client)
    save_findings_to_json(result, 'iam_password_policy_minimum_length_14.json')
    # 결과를 JSON 형식으로 출력
    print(f"Results saved to 'iam_password_policy_minimum_length_14.json'.")
