import boto3
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

def initialize_iam_client():
    try:
        iam_client = boto3.client('iam')
        # 자격 증명이 올바른지 확인하기 위해 간단한 API 호출
        iam_client.get_account_password_policy()
    except (NoCredentialsError, PartialCredentialsError):
        print("AWS 자격 증명이 설정되지 않았습니다.")
        access_key = input("AWS Access Key ID를 입력하세요: ")
        secret_key = input("AWS Secret Access Key를 입력하세요: ")

        # 환경 변수에 저장
        os.environ['AWS_ACCESS_KEY_ID'] = access_key
        os.environ['AWS_SECRET_ACCESS_KEY'] = secret_key

        iam_client = boto3.client('iam')
    except boto3.client('iam').exceptions.NoSuchEntityException:
        print("비밀번호 정책이 설정되어 있지 않습니다.")
        return None
    return iam_client

def check_password_policy_uppercase(iam_client):
    findings = [{
        "arn": "N/A",
        "tag": "N/A",
        "region": "aws-global",
        "status": "ERROR",
        "status_extended": "계정에 사용자 지정 정책이 없습니다."
    }]
    if not iam_client:
        return findings

    try:
        response = iam_client.get_account_password_policy()
        password_policy = response['PasswordPolicy']

        policy_status = "PASS" if password_policy.get('RequireUppercaseCharacters', False) else "FAIL"
        status_extended = "IAM 비밀번호 정책에는 적어도 하나의 대문자가 필요합니다." if policy_status == "PASS" else "IAM 비밀번호 정책에는 대문자가 필요하지 않습니다."

        findings = [{
            "arn": "N/A",
            "tag": "N/A",
            "region": "aws-global",
            "status": policy_status,
            "status_extended": status_extended
        }]

    except iam_client.exceptions.NoSuchEntityException:
        print("비밀번호 정책이 설정되어 있지 않습니다.")
        findings["status"] = "FAIL"
        findings["status_extended"] = "비밀번호 정책이 설정되어 있지 않습니다."
    except Exception as e:
        print(f"오류 발생: {e}")
        findings["status"] = "ERROR"
        findings["status_extended"] = "계정에 사용자 지정 정책이 없습니다."

    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    # IAM 클라이언트 초기화
    iam_client = initialize_iam_client()

    # 패스워드 정책 검사 및 결과 저장
    result = check_password_policy_uppercase(iam_client)
    save_findings_to_json(result, 'iam_password_policy_uppercase.json')

    # 결과를 JSON 형식으로 출력
    print(f"Results saved to 'iam_password_policy_uppercase.json'.")
