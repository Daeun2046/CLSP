import boto3
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

def get_aws_client(service):
    try:
        # Boto3 클라이언트 생성
        client = boto3.client(service)
        return client
    except (NoCredentialsError, PartialCredentialsError):
        print("AWS 자격 증명이 없습니다. 액세스 키와 비밀 키를 입력하세요.")
        access_key = input("AWS Access Key: ")
        secret_key = input("AWS Secret Key: ")

        # 환경 변수에 자격 증명 저장
        os.environ['AWS_ACCESS_KEY_ID'] = access_key
        os.environ['AWS_SECRET_ACCESS_KEY'] = secret_key

        # 자격 증명을 사용하여 다시 클라이언트 생성
        client = boto3.client(service, aws_access_key_id=access_key, aws_secret_access_key=secret_key)
        return client

def check_password_policy_lowercase(iam_client):
    findings = []

    try:
        # 사용자 이름 가져오기
        user_name = iam_client.get_user()['User']['UserName']
        arn = iam_client.get_user()['User']['Arn']

        try:
            password_policy = iam_client.get_account_password_policy()
            if password_policy['PasswordPolicy'].get('RequireLowercaseCharacters'):
                response = {
                    "arn": arn,
                    "tag": "N/A",
                    "region": "aws-global",
                    "status": "PASS",
                    "status_extended": "비밀번호 만료가 90일 이하로 설정되었습니다 (90일)."
                }
            else:
                response = {
                    "arn": arn,
                    "tag": "N/A",
                    "region": "aws-global",
                    "status": "FAIL",
                    "status_extended": "IAM 비밀번호 정책에 소문자 요구 사항이 없습니다."
                }
        except iam_client.exceptions.NoSuchEntityException:
            response = {
                "arn": "N/A",
                "tag": "N/A",
                "region": "aws-global",
                "status": "ERROR",
                "status_extended": "계정에 사용자 지정 정책이 없습니다."
            }
        except Exception as e:
            response = {
                "arn": "N/A",
                "tag": "N/A",
                "region": "aws-global",
                "status": "ERROR",
                "status_extended": str(e)
            }

        findings.append(response)
    except NoCredentialsError:
        print("No AWS credentials found.")
    except PartialCredentialsError:
        print("Incomplete AWS credentials found.")
    except Exception as e:
        print(f"An error occurred: {e}")
    
    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4)

if __name__ == "__main__":
    # AWS IAM 클라이언트 생성
    iam_client = get_aws_client('iam')

    if iam_client:
        # 함수 호출 및 결과 저장
        result = check_password_policy(iam_client)
        save_findings_to_json(result, 'iam_password_policy_lowercase.json')
        # 결과를 JSON 형식으로 출력
        print(f"Results saved to 'iam_password_policy_lowercase.json'.")
        print(json.dumps(result, indent=4))
    else:
        print("AWS 클라이언트를 생성할 수 없습니다.")
