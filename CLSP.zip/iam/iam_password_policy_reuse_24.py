import boto3
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

def initialize_iam_client():
    try:
        iam_client = boto3.client(
            'iam',
            aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
            region_name='ap-northeast-2'
        )
    except (NoCredentialsError, PartialCredentialsError):
        print("AWS 자격 증명이 설정되지 않았습니다.")
        access_key = input("AWS Access Key ID를 입력하세요: ")
        secret_key = input("AWS Secret Access Key를 입력하세요: ")
        os.environ['AWS_ACCESS_KEY_ID'] = access_key
        os.environ['AWS_SECRET_ACCESS_KEY'] = secret_key
        iam_client = boto3.client(
            'iam',
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name='ap-northeast-2'
        )
    return iam_client

def check_password_policy_reuse(iam_client):
    try:
        password_policy = iam_client.get_account_password_policy()
        password_policy_detail = password_policy['PasswordPolicy']
        
        if 'PasswordReusePrevention' in password_policy_detail and password_policy_detail['PasswordReusePrevention'] == 24:
            status = "PASS"
            status_extended = "IAM 비밀번호 정책 재사용 방지가 24로 설정되어 있습니다."
        else:
            status = "FAIL"
            status_extended = "IAM 비밀번호 정책 재사용 방지가 24보다 작거나 설정되지 않았습니다."
    except iam_client.exceptions.NoSuchEntityException:
        status = "FAIL"
        status_extended = "비밀번호 정책이 설정되지 않았습니다."
    except Exception as e:
        print(f"Error checking IAM password policy: {e}")
        status = "ERROR"
        status_extended = "계정에 사용자 지정 정책이 없습니다."

    findings = [{
        "arn": "N/A",
        "tag": "N/A",
        "region": "aws-global",
        "status": status,
        "status_extended": status_extended
    }]
    
    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    # AWS IAM 클라이언트 생성
    iam_client = initialize_iam_client()

    # 함수 호출 및 결과 저장
    result = check_password_policy_reuse(iam_client)
    save_findings_to_json(result, 'iam_password_policy_reuse_24.json')
    # 결과를 JSON 형식으로 출력
    print(f"Results saved to 'iam_password_policy_reuse_24.json'.")
