import boto3
import os
import json

def get_aws_credentials():
    try:
        # Try to get the credentials from the environment variables
        access_key = os.environ.get("AWS_ACCESS_KEY_ID")
        secret_key = os.environ.get("AWS_SECRET_ACCESS_KEY")
        
        # If the credentials are not found in the environment variables, prompt the user to enter them
        if not access_key or not secret_key:
            access_key = input("Enter your AWS Access Key: ")
            secret_key = input("Enter your AWS Secret Key: ")
            os.environ["AWS_ACCESS_KEY_ID"] = access_key
            os.environ["AWS_SECRET_ACCESS_KEY"] = secret_key
    except Exception as e:
        print(f"Error getting AWS credentials: {e}")
        return None, None
    
    return access_key, secret_key

def check_iam_password_policy(iam_client):
    try:
        # Get the current IAM password policy
        password_policy = iam_client.get_account_password_policy()["PasswordPolicy"]

        # Check if the password policy requires at least one number
        if "RequireNumbers" in password_policy and password_policy["RequireNumbers"]:

            status = "PASS"
            status_extended = "암호 만료가 90일 미만으로 설정되었습니다 (90일)."
        else:
            print("IAM 암호 정책에는 숫자가 필요하지 않습니다.")
            status = "FAIL"
            status_extended = "암호 만료가 90일 미만으로 설정되지 않았습니다 (90일)."

        return [{
            "arn": "N/A",
            "tag": "N/A",
            "region": "aws-global",
            "status": status,
            "status_extended": status_extended
        }]
    except Exception as e:
        print(f"Error checking IAM password policy: {e}")
        return [{
            "arn": "N/A",
            "tag": "N/A",
            "region": "aws-global",
            "status": "ERROR",
            "status_extended": "계정에 사용자 지정 정책이 없습니다."
        }]

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    # Get AWS credentials
    access_key, secret_key = get_aws_credentials()
    if not access_key or not secret_key:
        print("Failed to get AWS credentials.")
        exit(1)

    # Create an IAM client
    iam_client = boto3.client('iam', aws_access_key_id=access_key, aws_secret_access_key=secret_key, region_name='ap-northeast-2')

    # Check IAM password policy and save results
    result = check_iam_password_policy(iam_client)
    save_findings_to_json(result, 'iam_password_policy_number.json')
    print(f"Results saved to 'iam_password_policy_number.json'.")
