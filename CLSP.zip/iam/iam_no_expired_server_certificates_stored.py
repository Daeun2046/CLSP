import boto3
import json
from datetime import datetime, timezone  # 날짜와 시간을 다루기 위해 datetime과 timezone 모듈을 가져옴
from botocore.exceptions import ClientError  # ClientError 예외를 사용하기 위해 가져옴

def iam_no_expired_server_certificates_stored(iam_client):
    findings = []  # 결과를 저장할 리스트 초기화

    try:
        # 서버 인증서 목록을 가져옴
        response = iam_client.list_server_certificates()

        # 인증서가 없을 경우
        if not response['ServerCertificateMetadataList']:
            findings.append({
                "arn": "N/A",
                "tag": "N/A",
                "region": iam_client.meta.region_name,
                "status": "INFO",
                "status_extended": "계정에 IAM 서버 인증서가 없습니다."
            })
            return findings

        # 각 서버 인증서를 순회
        for certificate in response['ServerCertificateMetadataList']:
            certificate_name = certificate['ServerCertificateName']  # 인증서 이름 가져오기
            certificate_arn = certificate['Arn']  # 인증서 ARN 가져오기

            # 기본 상태 및 상태 확장 메시지 설정
            status = "PASS"
            # 현재 날짜와 인증서 만료 날짜를 비교하여 일수 계산
            expiration_days = (datetime.now(timezone.utc) - certificate['Expiration']).days

            # 만료된 경우 상태와 확장 메시지 수정
            if expiration_days >= 0:
                status = "FAIL"
                status_extended = f"IAM 인증서 {certificate_name}이 {expiration_days}일 전에 만료되었습니다."
            else:
                status_extended = f"IAM 인증서 {certificate_name}은 만료되지 않았습니다."

            # 결과 리스트에 현재 인증서의 상태 추가
            findings.append({
                "arn": f"{certificate_arn}",  # 인증서 ARN 설정
                "tag": "N/A",  # IAM 서버 인증서에는 태그가 적용되지 않음
                "region": iam_client.meta.region_name,  # 현재 AWS 리전 설정
                "status": status,  # 상태 설정
                "status_extended": status_extended  # 확장 상태 메시지 설정
            })

    except ClientError as e:  # 예외 발생 시 처리
        # 예외 발생 시 에러 메시지와 함께 결과 리스트에 추가
        findings.append({
            "arn": "N/A",  # ARN을 가져올 수 없으므로 N/A 설정
            "tag": "N/A",  # 태그를 가져올 수 없으므로 N/A 설정
            "region": "N/A",  # 리전을 가져올 수 없으므로 N/A 설정
            "status": "ERROR",  # 상태를 "ERROR"로 설정
            "status_extended": f"IAM 서버 인증서를 가져오는 중 오류 발생: {str(e)}"  # 예외 메시지를 확장 상태 메시지로 설정
        })

    return findings  # 결과 리스트 반환

if __name__ == "__main__":
    # AWS IAM 클라이언트 생성
    iam_client = boto3.client('iam')

    # 함수 호출 및 결과 저장
    result = iam_no_expired_server_certificates_stored2(iam_client)

    # 결과를 JSON 형식으로 출력
    print(json.dumps(result, indent=4))

    # 결과를 JSON 형식으로 파일 만들기
    # with open('iam_no_expired_server_certificates_stored.json', 'w') as json_file:
    #     json.dump(result, json_file, indent=4)
