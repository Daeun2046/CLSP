import boto3
import os
import json
from dotenv import load_dotenv #파일을 직접 읽어올지 dotenv를 쓸지는 선택의 문제 저는 예뻐서 얘를..
import time
from colorama import Fore, Style, init
import datetime

"""
개발에 대해...
환경변수에 직접 넣을지 아님 이런식으로 파일로 관리를 할지

환경변수에 직접 넣는다
장점: 
1.따로 파일을 관리할 필요가 없다. (보안에 유리)
2. 환경변수에 직접적으로 넣는거라 다른 boto3를 사용하는 프로그램과의 연동이 좋다. ex) Prowler 와 같은 CSPM 등
단점:
1. OS에 따라 코드를 실행시켜야한다 (platform에 따른 대응)
2. 코드가 비교적 복잡해진다.
3. 사전지식이 비교적 더 필요하다 (ex: Window와 Mac OS의 환경변수 처리 방식 등)

파일로 관리한다.
장점: 
1.코드가 비교적으로 쉽고 간결하다.
2. 독립성이 보장되며 환경변수 충돌이 없다.
3. 파일을 관리할수만 있다면 클라우드 환경에서 사용 가능 (ex: Discord로 CSPM서비스를 운영할 경우 사용자가 파일에 잠금을 걸 수 있다는 가정하에 안심하며 사용가능)
단점:
1. 타 플랫폼과 상호작용 불가 (타 플랫폼이 쓰려면 파일을 읽어오는 코드가 있어야하는데 그건 일반 사용자가 하기에는 말이안됨)
2. 파일이 유출 및 분실등 보안적으로 신경써야함
3. 파일명이 코드에 제시돼있으므로 보안적 위협이 비교적 있음


좀더 찾아보니까 고민해결 -> 환경변수에 넣는다고 해도 세션이 종료되고 나면 값이 초기화됨 즉, 큰 의미가없음 그니까 무조건 파일로 관리해야함..
정 아니면 로그인 스크립트에 삽입하는 방법도 있긴한데, 권한의 문제와 같은 까다로운 보안 이슈가 있기에 패스
레지스트리 이용 -> 관리자 권한이 필요
"""

from iam.iam_administrator_access_with_mfa import iam_administrator_access_with_mfa
from iam.iam_avoid_root_usage import iam_avoid_root_usage
from iam.iam_aws_attached_policy_no_administrative_privileges import iam_aws_attached_policy_no_administrative_privileges
from iam.iam_check_saml_providers_sts import iam_check_saml_providers_sts
from iam.iam_customer_attached_policy_no_administrative_privileges import iam_customer_attached_policy_no_administrative_privileges
from iam.iam_customer_unattached_policy_no_administrative_privileges import iam_customer_unattached_policy_no_administrative_privileges
from iam.iam_inline_policy_no_administrative_privileges import iam_inline_policy_no_administrative_privileges
from iam.iam_no_custom_policy_permissive_role_assumption import iam_no_custom_policy_permissive_role_assumption
from iam.iam_no_expired_server_certificates_stored import iam_no_expired_server_certificates_stored
from iam.iam_policy_allows_privilege_escalation import check_privilege_escalation
from iam.iam_policy_attached_only_to_group_or_roles import get_users_with_policies
from iam.iam_policy_no_full_access_to_cloudtrail import check_policy_no_full_access_to_cloudtrail
from iam.iam_policy_no_full_access_to_kms import check_policy_no_full_access_to_kms
from iam.iam_rotate_access_key_90_days import check_iam_access_key_rotation
from iam.iam_securityaudit_role_created import check_security_audit_role_created
from iam.iam_support_role_created import check_iam_support_role_created
from iam.iam_user_accesskey_unused import check_unused_access_keys
from iam.iam_user_console_access_unused import check_iam_user_console_access_unused
from iam.iam_user_hardware_mfa_enabled import check_iam_user_hardware_mfa_enabled
from iam.iam_user_mfa_enabled_console_access import check_iam_user_mfa_enabled_console_access
from iam.iam_user_no_setup_initial_access_key import check_iam_user_no_setup_initial_access_key
from iam.iam_user_two_active_access_key import check_iam_user_two_active_access_keys
from iam.iam_user_with_temporary_credentials import check_iam_user_with_temporary_credentials
from iam.iam_no_root_access_key import check_no_root_access_key
from iam.iam_password_policy_expires_passwords_within_90_days_or_less import check_password_policy
from iam.iam_password_policy_expires_passwords_within_90_days_or_less_fixer import check_password_policy_expires_passwords_within_90_days_or_less_fixer
from iam.iam_password_policy_lowercase import check_password_policy_lowercase
from iam.iam_password_policy_lowercase_fixer import check_password_policy as check_password_policy_lowercase_fixer
from iam.iam_password_policy_minimum_length_14 import check_iam_password_policy_minimum_length_14
from iam.iam_password_policy_minimum_length_14_fixer import update_password_policy as update_password_policy_minimum_length_14_fixer
from iam.iam_password_policy_number import check_iam_password_policy
from iam.iam_password_policy_number_fixer import fixer as fixer_number_fixer
from iam.iam_password_policy_reuse_24 import check_password_policy_reuse
from iam.iam_password_policy_reuse_24_fixer import fixer as fixer_reuse_fixer
from iam.iam_password_policy_symbol import check_password_policy_symbol
from iam.iam_password_policy_symbol_fixer import fixer as fixer_symbol_fixer
from iam.iam_password_policy_uppercase import check_password_policy_uppercase
from iam.iam_password_policy_uppercase_fixer import fixer as fixer_uppercase_fixer

def key_pair():
    env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env')

    if os.path.exists(env_path):
        load_dotenv(env_path)
    else:
        open(env_path, 'a').close()

    try:

        aws_access_key_id = os.getenv('AWS_ACCESS_KEY_ID')
        aws_secret_access_key = os.getenv('AWS_SECRET_ACCESS_KEY')
        aws_default_region = os.getenv('AWS_DEFAULT_REGION', "ap-northeast-2")

        os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key_id
        os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_access_key
        os.environ['AWS_DEFAULT_REGION'] = aws_default_region

        iam_client = boto3.client('iam')
        response = iam_client.list_buckets()


    except Exception as e:
        aws_access_key_id = input("AWS_ACCESS_KEY_ID: ")

        aws_secret_access_key = input("AWS_SECRET_ACCESS_KEY: ")

        aws_default_region = input("AWS_DEFAULT_REGION (기본값: ap-northeast-2[서울]): ") or "ap-northeast-2"

        os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key_id
        os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_access_key
        os.environ['AWS_DEFAULT_REGION'] = aws_default_region


        with open(env_path, 'w') as f:
            f.write(f"AWS_ACCESS_KEY_ID={aws_access_key_id}\n")
            f.write(f"AWS_SECRET_ACCESS_KEY={aws_secret_access_key}\n")
            f.write(f"AWS_DEFAULT_REGION={aws_default_region}\n")
        
        if not os.environ['AWS_DEFAULT_REGION']:
            os.environ['AWS_DEFAULT_REGION'] = "ap-northeast-2"

        iam_client = boto3.client('iam')
        response = iam_client.get_user()


# ==============================================상현님 코드=================================================
# 정사각형 테두리 생성 함수
def print_in_box(lines):
    max_length = max(len(f"{index + 1}. {line}") for index, line in enumerate(lines))
    print('╔' + '═' * (max_length + 2) + '╗')
    for index, line in enumerate(lines):
        print(f'║ {index + 1}. {line.ljust(max_length - len(f"{index + 1}. "))} ║')
    print('╚' + '═' * (max_length + 2) + '╝')

# IAM 사용자 목록 가져오기 함수
def list_iam_users():
    response = iam_client.list_users()
    users = response['Users']
    user_names = [user['UserName'] for user in users]
    return user_names

# IAM 사용자의 정책 목록 가져오기 함수
def list_user_policies(user_name):
    response = iam_client.list_attached_user_policies(UserName=user_name)
    policies = response['AttachedPolicies']
    policy_names = [policy['PolicyName'] for policy in policies]
    return policy_names

def iam_client_info():
    user_names = list_iam_users()
    print("Select the IAM users you want to analyze:\n")
    print("0. All users")
    print_in_box(user_names)
    while True:
        try:
            selection = int(input("Enter the number: "))
            if selection == 0:
                selected_users = user_names
                break
            elif 1 <= selection <= len(user_names):
                selected_users = [user_names[selection - 1]]
                break
            else:
                print("Please enter a valid number.")
        except ValueError:
            print("Please enter a number.")

    print(f"Selected IAM users: {', '.join(selected_users)}")
    return selected_users

def parse_data(data):
    results = []
    for user_name, checks in data.items():
        for policy_name, check_results in checks.items():
            for check_name, check_result in check_results.items():
                for result in check_result:
                    results.append({
                        'user_name': user_name,
                        'policy_name': policy_name,
                        'check_name': check_name,
                        'arn': result['arn'],
                        'status': result['status']
                    })
    return results

def iam_print_pretty_report(data):
    init(autoreset=True)  # 자동으로 색상을 리셋
    if not data:
        print("No data available.")
        return

    user_name = data[0].get('user_name', 'N/A')
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    pass_count = sum(1 for check in data if check['status'] == 'PASS')
    fail_count = sum(1 for check in data if check['status'] == 'FAIL')
    error_count = sum(1 for check in data if check['status'] == 'ERROR')

    print("="*50)
    print(f"{Fore.BLUE}USER: {Fore.WHITE}{user_name}")
    print(f"{Fore.CYAN}Current Time: {Fore.WHITE}{current_time}")
    print(f"{Fore.GREEN}PASS: {pass_count}{Style.RESET_ALL}, {Fore.RED}FAIL: {fail_count}{Style.RESET_ALL}, {Fore.YELLOW}ERROR: {error_count}{Style.RESET_ALL}")
    print("="*50)

    for check in data:
        status_color = Fore.GREEN if check['status'] == 'PASS' else Fore.RED if check['status'] == 'FAIL' else Fore.YELLOW
        print(f"{Fore.MAGENTA}Policy Name: {Fore.WHITE}{check['policy_name']}")
        print(f"{Fore.MAGENTA}Check Name: {Fore.WHITE}{check['check_name']}")
        print(f"{Fore.MAGENTA}ARN: {Fore.WHITE}{check.get('arn', 'N/A')}")
        print(f"{Fore.MAGENTA}Status: {status_color}{check['status']}{Style.RESET_ALL}")
        print("-"*50)

env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env')

#=========================================================================================


# 버킷 이름 출력
def main():
    key_pair()
    selected_users = iam_client_info()
    results = {}
    checklist = [
                (iam_administrator_access_with_mfa, "iam_administrator_access_with_mfa"),
                (iam_avoid_root_usage, "iam_avoid_root_usage"),
                (iam_aws_attached_policy_no_administrative_privileges, "iam_aws_attached_policy_no_administrative_privileges"),
                (iam_check_saml_providers_sts, "iam_check_saml_providers_sts"),
                (iam_customer_attached_policy_no_administrative_privileges, "iam_customer_attached_policy_no_administrative_privileges"),
                (iam_customer_unattached_policy_no_administrative_privileges, "iam_customer_unattached_policy_no_administrative_privileges"),
                (iam_inline_policy_no_administrative_privileges, "iam_inline_policy_no_administrative_privileges"),
                (iam_no_custom_policy_permissive_role_assumption, "iam_no_custom_policy_permissive_role_assumption"),
                (iam_no_expired_server_certificates_stored, "iam_no_expired_server_certificates_stored"),
                (check_privilege_escalation, "check_privilege_escalation"),
                (get_users_with_policies, "get_users_with_policies"),
                (check_policy_no_full_access_to_cloudtrail, "check_policy_no_full_access_to_cloudtrail"),
                (check_policy_no_full_access_to_kms, "check_policy_no_full_access_to_kms"),   
                (check_iam_access_key_rotation, "check_iam_access_key_rotation"),
                (check_security_audit_role_created, "check_security_audit_role_created"),
                (check_iam_support_role_created, "check_iam_support_role_created"),
                (check_unused_access_keys, "check_unused_access_keys"),
                (check_iam_user_console_access_unused, "check_iam_user_console_access_unused"),
                (check_iam_user_hardware_mfa_enabled, "check_iam_user_hardware_mfa_enabled"),
                (check_iam_user_mfa_enabled_console_access, "check_iam_user_mfa_enabled_console_access"),
                (check_iam_user_no_setup_initial_access_key, "check_iam_user_no_setup_initial_access_key"),
                (check_iam_user_two_active_access_keys, "check_iam_user_two_active_access_keys"),
                (check_iam_user_with_temporary_credentials, "check_iam_user_with_temporary_credentials"),
                (check_no_root_access_key, "check_no_root_access_key"),
                (check_password_policy, "check_password_policy"),
                (check_password_policy_expires_passwords_within_90_days_or_less_fixer, "check_password_policy_expires_passwords_within_90_days_or_less_fixer"),
                (check_password_policy_lowercase, "check_password_policy_lowercase"),
                (check_password_policy_lowercase_fixer, "check_password_policy_lowercase_fixer"),
                (check_iam_password_policy_minimum_length_14, "check_iam_password_policy_minimum_length_14"),
                (update_password_policy_minimum_length_14_fixer, "update_password_policy_minimum_length_14_fixer"),
                (check_iam_password_policy, "check_iam_password_policy"),
                (fixer_number_fixer, "fixer_number_fixer"),
                (check_password_policy_reuse, "check_password_policy_reuse"),
                (fixer_reuse_fixer, "fixer_reuse_fixer"),
                (check_password_policy_symbol, "check_password_policy_symbol"),
                (fixer_symbol_fixer, "fixer_symbol_fixer"),
                (check_password_policy_uppercase, "check_password_policy_uppercase"),
                (fixer_uppercase_fixer, "fixer_uppercase_fixer"),
                ]
    for user_name in selected_users:
        user_policies = list_user_policies(user_name)
        results[user_name] = {}

        for policy_name in user_policies:
            results[user_name][policy_name] = {}
            for checkthis, name in checklist:
                results[user_name][policy_name][name] = checkthis(iam_client)


    script_dir = os.path.dirname(__file__)
    
    base_dir = os.path.join(os.path.abspath(os.path.join(script_dir, '..')), 'results')
    results_dir = os.path.join(base_dir, 'detail_results')

    if not os.path.exists(results_dir):
        os.makedirs(results_dir)

    iam_results_path = os.path.join(results_dir, 'iam_analysis_results.json')


    with open(iam_results_path, 'w') as json_file:
        json.dump(results, json_file, indent=4, ensure_ascii=False)

    transformed_results = parse_data(results)

    results_dir = os.path.join(base_dir, 'checks')

    if not os.path.exists(results_dir):
        os.makedirs(results_dir)

    s3_checks_path = os.path.join(results_dir, 'iam_checks.json')

    with open(s3_checks_path, 'w') as json_file:
        json.dump(transformed_results, json_file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    main()