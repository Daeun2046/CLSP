import boto3
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

def initialize_iam_client():
    try:
        iam_client = boto3.client('iam')
        # 자격 증명이 올바른지 확인하기 위해 간단한 API 호출
        iam_client.get_account_password_policy()
    except (NoCredentialsError, PartialCredentialsError):
        print("AWS 자격 증명이 설정되지 않았습니다.")
        access_key = input("AWS Access Key ID를 입력하세요: ")
        secret_key = input("AWS Secret Access Key를 입력하세요: ")

        # 환경 변수에 저장
        os.environ['AWS_ACCESS_KEY_ID'] = access_key
        os.environ['AWS_SECRET_ACCESS_KEY'] = secret_key

        iam_client = boto3.client('iam')
    except boto3.client('iam').exceptions.NoSuchEntityException:
        print("비밀번호 정책이 설정되어 있지 않습니다.")
        return None
    return iam_client

def fixer(iam_client):
    findings = []
    if not iam_client:
        return findings

    try:
        response = iam_client.get_account_password_policy()
        password_policy = response['PasswordPolicy']

        user_info = iam_client.get_user()
        user_name = user_info['User']['UserName']
        user_arn = user_info['User']['Arn']

        # 패스워드 정책 업데이트
        iam_client.update_account_password_policy(
            MinimumPasswordLength=password_policy.get('MinimumPasswordLength', 8),
            RequireSymbols=password_policy.get('RequireSymbols', True),
            RequireNumbers=password_policy.get('RequireNumbers', True),
            RequireUppercaseCharacters=True,
            RequireLowercaseCharacters=password_policy.get('RequireLowercaseCharacters', True),
            AllowUsersToChangePassword=password_policy.get('AllowUsersToChangePassword', True),
            MaxPasswordAge=password_policy.get('MaxPasswordAge', 90),
            PasswordReusePrevention=password_policy.get('PasswordReusePrevention', 5),
            HardExpiry=password_policy.get('HardExpiry', False),
        )

        policy_status = "PASS" if password_policy.get('RequireUppercaseCharacters', False) else "FAIL"
        status_extended = "사용자 {}는 대문자가 필요합니다.".format(user_name) if policy_status == "PASS" else "사용자 {}는 대문자가 필요하지 않습니다.".format(user_name)

        finding = {
            "arn": user_arn,
            "tag": "",
            "region": "aws-global",
            "status": policy_status,
            "status_extended": status_extended
        }

        findings.append(finding)

    except iam_client.exceptions.NoSuchEntityException:
        print("비밀번호 정책이 설정되어 있지 않습니다.")
    except Exception as e:
        print(f"오류 발생: {e}")

    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    iam_client = boto3.client('iam',
        aws_access_key_id="YOUR_AWS_ACCESS_KEY_ID",
        aws_secret_access_key="YOUR_AWS_SECRET_ACCESS_KEY",
        region_name='ap-northeast-2')

    # 패스워드 정책 수정 및 결과 저장
    results = fixer(iam_client)
    save_findings_to_json(results, 'iam_password_policy_uppercase_fixer.json')

    # 결과를 JSON 형식으로 출력
    print(f"결과가 'iam_password_policy_uppercase_fixer.json' 파일에 저장되었습니다.")
