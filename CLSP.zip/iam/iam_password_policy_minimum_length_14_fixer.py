import boto3
import os
import json

def get_aws_credentials():
    access_key = input("AWS Access Key를 입력하세요: ")
    secret_key = input("AWS Secret Key를 입력하세요: ")
    os.environ["AWS_ACCESS_KEY_ID"] = access_key
    os.environ["AWS_SECRET_ACCESS_KEY"] = secret_key

def get_iam_client():
    try:
        iam_client = boto3.client('iam')
        iam_client.get_account_summary()
        return iam_client
    except Exception as e:
        print(f"IAM 클라이언트를 생성하지 못했습니다: {e}")
        return None

def get_current_user_name(iam_client):
    try:
        user = iam_client.get_user()
        return user["User"]["UserName"]
    except Exception as e:
        print(f"현재 사용자 이름을 가져오지 못했습니다: {e}")
        return "알 수 없음"

def update_password_policy(iam_client):
    findings = []
    try:
        # 사용자 이름을 내부에서 가져옴
        user_name = get_current_user_name(iam_client)
        
        iam_client.update_account_password_policy(
            MinimumPasswordLength=14,
            RequireSymbols=True,
            RequireNumbers=True,
            RequireUppercaseCharacters=True,
            RequireLowercaseCharacters=True,
            AllowUsersToChangePassword=True,
            MaxPasswordAge=90,
            PasswordReusePrevention=5,
            HardExpiry=False,
        )

        findings.append({
            "arn": f"arn:aws:iam::123456789012:user/{user_name}",
            "tag": "",
            "region": "ap-northeast-2",
            "status": "PASS",
            "status_extended": f"{user_name} 사용자는 IAM 또는 STS가 아닌 다른 서비스에 액세스할 수 있는 자격 증명을 오래 사용했습니다."
        })
    except Exception as error:
        user_name = get_current_user_name(iam_client)
        print(f"{error.__class__.__name__}[{error.__traceback__.tb_lineno}]: {error}")
        findings.append({
            "arn": f"arn:aws:iam::123456789012:user/{user_name}",
            "tag": "",
            "region": "ap-northeast-2",
            "status": "FAIL",
            "status_extended": f"{user_name} 사용자는 IAM 또는 STS가 아닌 다른 서비스에 액세스할 수 있는 자격 증명을 오래 사용했습니다."
        })

    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4)

if __name__ == "__main__":
    get_aws_credentials()
    iam_client = get_iam_client()
    if iam_client:
        findings = update_password_policy(iam_client)
        save_findings_to_json(findings, 'iam_password_policy_minimum_length_14_fixer.json')
        print(f"결과가 'iam_password_policy_minimum_length_14_fixer.json' 파일에 저장되었습니다.")
    else:
        print("IAM 클라이언트를 생성하지 못했습니다.")
