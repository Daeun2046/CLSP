import boto3
import json
from botocore.exceptions import ClientError  # Boto3 클라이언트 에러를 처리하기 위해 예외를 가져옴

def iam_administrator_access_with_mfa(iam_client):
    findings = []  # 결과를 저장할 리스트 초기화

    try:
        response = iam_client.list_groups()  # 모든 IAM 그룹을 나열
        for group in response['Groups']:  # 각 그룹에 대해 반복
            group_name = group['GroupName']  # 그룹 이름을 가져옴
            group_arn = group['Arn']  # 그룹 ARN을 가져옴

            # 기본값 설정
            status = "PASS"  # 초기 상태는 "PASS"로 설정
            status_extended = f"그룹 {group_name}에는 정책이 없습니다."  # 기본 설명 설정

            attached_policies = iam_client.list_attached_group_policies(GroupName=group_name)  # 그룹에 연결된 정책 나열
            if attached_policies['AttachedPolicies']:  # 연결된 정책이 있는지 확인
                status_extended = f"그룹 {group_name}에는 관리자 권한이 없는 접근 권한이 있습니다."  # 연결된 정책이 있음을 설명
                for policy in attached_policies['AttachedPolicies']:  # 각 연결된 정책에 대해 반복
                    if policy['PolicyArn'] == "arn:aws:iam::aws:policy/AdministratorAccess":  # 관리자 액세스 정책인지 확인
                        users = iam_client.get_group(GroupName=group_name)['Users']  # 그룹에 속한 사용자 나열
                        if users:  # 사용자가 있는지 확인
                            for user in users:  # 각 사용자에 대해 반복
                                credential_report = iam_client.get_credential_report()  # IAM 자격 증명 보고서 가져옴
                                for report_user in credential_report['Content'].decode('utf-8').split('\n'):  # 보고서 내용을 한 줄씩 읽음
                                    user_data = report_user.split(',')  # 각 줄을 쉼표로 분리
                                    if user_data[0] == user['UserName'] and user_data[7] == "false":  # 사용자 이름이 일치하고 MFA가 비활성화된 경우
                                        status = "FAIL"  # 상태를 "FAIL"로 설정
                                        status_extended = f"그룹 {group_name}은 사용자 {user['UserName']}에게 MFA 비활성화 상태에서 관리자 권한을 부여합니다."  # 설명 업데이트
                        else:
                            status_extended = f"그룹 {group_name}은 관리자 권한을 부여하지만 사용자가 없습니다."  # 사용자가 없음을 설명

            findings.append({  # 결과를 findings 리스트에 추가

                "arn": f"{group_arn}",  # 그룹 ARN
                "tag": "N/A",  # IAM 그룹에는 태그가 적용되지 않음
                "region": iam_client.meta.region_name,  # IAM 클라이언트의 지역
                "status": status,  # 그룹의 상태
                "status_extended": status_extended  # 상태에 대한 설명
            })

    except ClientError as e:  # ClientError 발생 시 처리
        findings.append({  # 에러 내용을 findings 리스트에 추가
            "arn": "N/A",  # N/A로 설정
            "tag": "N/A",  # N/A로 설정
            "region": "N/A",  # N/A로 설정
            "status": "ERROR",  # 상태를 "ERROR"로 설정
            "status_extended": f"IAM 그룹 정보를 가져오는 중 오류 발생: {str(e)}"  # 에러 메시지 추가
        })

    return findings  # 결과 반환

if __name__ == "__main__":
    # AWS IAM 클라이언트 생성
    iam_client = boto3.client('iam')

    # 함수 호출 및 결과 저장
    result = iam_administrator_access_with_mfa2(iam_client)

    # 결과를 JSON 형식으로 출력
    print(json.dumps(result, indent=4, ensure_ascii=False))

    # 결과를 JSON 형식으로 파일 만들기
    # with open('iam_administrator_access_with_mfa.json', 'w') as json_file:
    #     json.dump(result, json_file, indent=4, ensure_ascii=False)
