import boto3
import json
from botocore.exceptions import ClientError
from ec2.lib import check_network_acl  # lib 모듈에서 check_network_acl 함수 import

# 네트워크 ACL의 TCP 포트 22가 인터넷에 노출되었는지 확인하는 함수
def ec2_networkacl_allow_ingress_tcp_port_22(ec2_client):
    findings = []  # 결과를 저장할 리스트 초기화
    tcp_protocol = "6"  # TCP 프로토콜을 나타내는 값 (6)
    check_port = 22  # 확인할 포트 번호 (SSH 포트)

    try:
        # 모든 네트워크 ACL 정보를 가져오기
        response = ec2_client.describe_network_acls()
        network_acls = response['NetworkAcls']
        ec2_resource = boto3.resource('ec2')  # EC2 리소스 객체 생성

        for network_acl in network_acls:
            vpc_id = network_acl['VpcId']
            vpc = ec2_resource.Vpc(vpc_id)
            region = vpc.meta.client.meta.region_name  # ACL이 속한 리전 가져오기

            # 네트워크 ACL의 태그 정보 가져오기
            tags = ec2_client.describe_tags(Filters=[{'Name': 'resource-id', 'Values': [network_acl['NetworkAclId']]}])['Tags']

            report = {
                "arn": f"{network_acl['NetworkAclId']} (VPC ID: {vpc_id})",
                "tags": tags,  # ACL의 태그 정보 추가
                "region": region,
                "status": "PASS",
                "status_extended": f"네트워크 ACL {network_acl['NetworkAclId']}은(는) 인터넷에 SSH 포트 22가 열려 있지 않습니다."
            }

            # 네트워크 ACL의 Entry들을 확인하여 SSH 포트 22가 인터넷에 열려 있는지 검사
            if check_network_acl(network_acl['Entries'], tcp_protocol, check_port):
                report["status"] = "FAIL"
                report["status_extended"] = f"네트워크 ACL {network_acl['NetworkAclId']}은(는) 인터넷에 SSH 포트 22가 열려 있습니다."

            findings.append(report)  # 결과를 리스트에 추가
    except ClientError as e:
        # 예외 처리: 네트워크 ACL 정보를 가져오는 중 오류 발생
        findings.append({
            "arn": "N/A",
            "tags": [],
            "region": "N/A",
            "status": "ERROR",
            "status_extended": f"네트워크 ACL 정보를 가져오는 중 오류 발생: {str(e)}"
        })

    return findings

if __name__ == "__main__":
    ec2_client = boto3.client('ec2')

    result = ec2_networkacl_allow_ingress_tcp_port_22(ec2_client)

    print(json.dumps(result, indent=4))

    # 결과를 JSON 형식으로 파일에 저장하는 경우 (필요 시 주석 해제)
    # with open('ec2_networkacl_allow_ingress_tcp_port_22_results.json', 'w') as json_file:
    #     json.dump(result, json_file, indent=4)
