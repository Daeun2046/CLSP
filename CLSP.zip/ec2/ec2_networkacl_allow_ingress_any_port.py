import boto3
import json
from botocore.exceptions import ClientError
from ec2.lib import check_network_acl  # lib 모듈에서 check_network_acl 함수 import

# 네트워크 ACL의 모든 포트가 인터넷에 노출되었는지 확인하는 함수
def ec2_networkacl_allow_ingress_any_port(ec2_client):
    findings = []  # 결과를 저장할 리스트 초기화
    tcp_protocol = "-1"  # TCP 프로토콜을 나타내는 값 (-1은 모든 TCP 포트)
    check_port = 0  # 확인할 포트 번호 (사용하지 않음)

    try:
        # 모든 네트워크 ACL 정보를 가져오기
        response = ec2_client.describe_network_acls()
        network_acls = response['NetworkAcls']
        ec2_resource = boto3.resource('ec2')  # EC2 리소스 객체 생성

        for network_acl in network_acls:
            vpc_id = network_acl['VpcId']
            vpc = ec2_resource.Vpc(vpc_id)
            region = vpc.meta.client.meta.region_name  # ACL이 속한 리전 가져오기

            # 네트워크 ACL의 태그를 가져오기
            tags = []
            if 'Tags' in network_acl:
                tags = network_acl['Tags']

            report = {
                "arn": network_acl['NetworkAclId'],  # ACL ARN
                "tags": tags,  # 태그 추가
                "region": region,  # 리전 이름
                "status": "PASS",  # 기본 상태 'PASS'
                "status_extended": f"네트워크 ACL {network_acl['NetworkAclId']}은(는) 모든 포트가 인터넷에 열려 있지 않습니다."  # 상태 확장 설명
            }

            # 네트워크 ACL의 Entry들을 확인하여 모든 포트가 인터넷에 열려 있는지 검사
            if check_network_acl(network_acl['Entries'], tcp_protocol, check_port):
                report["status"] = "FAIL"
                report["status_extended"] = f"네트워크 ACL {network_acl['NetworkAclId']}은(는) 모든 포트가 인터넷에 열려 있습니다."

            findings.append(report)  # 결과를 리스트에 추가
    except ClientError as e:
        # 예외 처리: 네트워크 ACL 정보를 가져오는 중 오류 발생
        findings.append({
            "arn": "N/A",  # ARN이 없음
            "tags": [],  # 태그 정보가 없음
            "region": "N/A",  # 리전 정보가 없음
            "status": "ERROR",  # 상태 'ERROR'
            "status_extended": f"네트워크 ACL 정보를 가져오는 중 오류 발생: {str(e)}"  # 상세 오류 메시지
        })

    return findings  # 최종 결과 반환

if __name__ == "__main__":
    ec2_client = boto3.client('ec2')  # EC2 클라이언트 생성

    result = ec2_networkacl_allow_ingress_any_port(ec2_client)  # 함수 호출하여 결과 저장

    print(json.dumps(result, indent=4))  # 결과를 JSON 형식으로 출력
