import boto3
import ipaddress
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

def set_aws_credentials():
    access_key = input("AWS Access Key를 입력하세요: ")
    secret_key = input("AWS Secret Key를 입력하세요: ")
    os.environ["AWS_ACCESS_KEY_ID"] = access_key
    os.environ["AWS_SECRET_ACCESS_KEY"] = secret_key

def get_ec2_security_groups(ec2_client):
    try:
        response = ec2_client.describe_security_groups()
        return response['SecurityGroups']
    except (NoCredentialsError, PartialCredentialsError):
        set_aws_credentials()
        return get_ec2_security_groups(ec2_client)
    except Exception as e:
        print(f"An error occurred: {e}")
        return []

def check_security_group_rules(ec2_client, target_group_name="default"):
    findings = []
    cidr_threshold = 24

    # EC2 클라이언트에서 리전 정보를 가져옴
    try:
        region = ec2_client.meta.region_name
    except AttributeError as e:
        print(f"An error occurred while accessing region info: {e}")
        return findings

    # EC2 보안 그룹 가져오기
    security_groups = get_ec2_security_groups(ec2_client)

    for sg in security_groups:
        if sg.get('GroupName') == target_group_name:
            sg_id = sg['GroupId']
            sg_arn = sg.get('Arn', 'N/A')
            sg_tags = sg.get('Tags', [])

            report = {
                "arn": sg_arn,
                "tag": sg_tags,
                "region": region,
                "status": "PASS",
                "status_extended": f"보안 그룹 ({sg_id})는 잠재적인 광범위한 non-RFC1918 주소가 없습니다."
            }

            def check_rules(rules, rule_type):
                for rule in rules:
                    for ipv4 in rule.get("IpRanges", []):
                        ip = ipaddress.ip_network(ipv4["CidrIp"])
                        if ip.is_global and 0 < ip.prefixlen < cidr_threshold:
                            report["status"] = "FAIL"
                            report["status_extended"] = f"보안 그룹 ({sg_id})는 {rule_type} 규칙에 잠재적인 광범위한 non-RFC1918 주소 {ipv4['CidrIp']}를 포함하고 있습니다."
                            return

            check_rules(sg.get('IpPermissions', []), 'ingress')
            if report["status"] == "PASS":
                check_rules(sg.get('IpPermissionsEgress', []), 'egress')

            findings.append(report)

    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4)

if __name__ == "__main__":
    # 사용자로부터 리전을 입력 받음
    region = input("AWS 리전을 입력하세요 (예: ap-northeast-2): ")

    # EC2 클라이언트 생성
    ec2_client = boto3.client('ec2', region_name=region)

    # 특정 보안 그룹 규칙 검사 (여기서 "default" 보안 그룹만 검사)
    findings = check_security_group_rules(ec2_client, target_group_name="default")

    if findings:
        # 첫 번째 결과만 출력
        result_to_save = findings[0]
        print(json.dumps(result_to_save, indent=4, ensure_ascii=False))

        # 결과를 JSON 파일로 저장
        save_findings_to_json([result_to_save], 'ec2_securitygroup_from_launch_wizard.json')
    else:
        print("지정한 보안 그룹에 대한 검색 결과가 없습니다.")
