import boto3
import os
import json
import datetime
from dotenv import load_dotenv
from colorama import Fore, Style, init

from ec2.ec2_instance_port_ssh_exposed_to_internet import ec2_instance_port_ssh_exposed_to_internet
from ec2.ec2_instance_port_telnet_exposed_to_internet import ec2_instance_port_telnet_exposed_to_internet
from ec2.ec2_instance_profile_attached import ec2_instance_profile_attached
from ec2.ec2_instance_public_ip import ec2_instance_public_ip
from ec2.ec2_instance_secrets_user_data import ec2_instance_secrets_user_data
from ec2.ec2_launch_template_no_secrets import ec2_launch_template_no_secrets
from ec2.ec2_networkacl_allow_ingress_any_port import ec2_networkacl_allow_ingress_any_port
from ec2.ec2_networkacl_allow_ingress_tcp_port_22 import ec2_networkacl_allow_ingress_tcp_port_22
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_all_ports import ec2_networkacl_allow_ingress_tcp_port_3389
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_any_port import ec2_securitygroup_allow_ingress_from_internet_to_any_port
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_port_mongodb_27017_27018 import ec2_securitygroup_allow_ingress_from_internet_to_mongodb_ports
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_ftp_port_20_21 import ec2_securitygroup_allow_ingress_from_internet_to_ftp_ports
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_22 import ec2_securitygroup_allow_ingress_from_internet_to_ssh_port_22
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_3389 import ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_3389
from ec2.ec2_instance_port_cassandra_exposed_to_internet import check_ec2_instance_port_cassandra_exposed_to_internet
from ec2.ec2_instance_port_cifs_exposed_to_internet import check_ec2_instance_port_cifs_exposed_to_internet
from ec2.ec2_instance_port_elasticsearch_kibana_exposed_to_internet import check_ec2_instance_port_elasticsearch_kibana_exposed_to_internet
from ec2.ec2_instance_port_ftp_exposed_to_internet import check_ec2_instance_port_ftp_exposed_to_internet
from ec2.ec2_instance_port_kafka_exposed_to_internet import check_ec2_instance_port_kafka_exposed_to_internet
from ec2.ec2_instance_port_kerberos_exposed_to_internet import check_ec2_instance_port_kerberos_exposed_to_internet
from ec2.ec2_instance_port_ldap_exposed_to_internet import check_ec2_instance_port_ldap_exposed_to_internet
from ec2.ec2_instance_port_memcached_exposed_to_internet import check_ec2_instance_port_memcached_exposed_to_internet
from ec2.ec2_instance_port_mongodb_exposed_to_internet import check_ec2_instance_port_mongodb_exposed_to_internet
from ec2.ec2_instance_port_mysql_exposed_to_internet import check_ec2_instance_port_mysql_exposed_to_internet
from ec2.ec2_instance_port_oracle_exposed_to_internet import check_ec2_instance_port_oracle_exposed_to_internet
from ec2.ec2_instance_port_postgresql_exposed_to_internet import check_ec2_instance_port_postgresql_exposed_to_internet
from ec2.ec2_instance_port_rdp_exposed_to_internet import check_ec2_instance_port_rdp_exposed_to_internet
from ec2.ec2_instance_port_redis_exposed_to_internet import check_ec2_instance_port_redis_exposed_to_internet
from ec2.ec2_instance_port_sqlserver_exposed_to_internet import check_ec2_instance_port_sqlserver_exposed_to_internet
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_cassandra_7199_9160_8888 import check_security_group_ports
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_elasticsearch_kibana_9200_9300_5601 import check_security_groups
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_kafka_9092 import check_security_group_ingress
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_memcached_11211 import check_security_group_for_memcached
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_mysql_3306 import check_security_group_ingress
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_oracle_1521_2483 import check_security_group_ingress_for_oracle_ports
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_postgres_5432 import check_security_group_ingress_for_postgres_port
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_redis_6379 import check_security_group_ingress_for_redis_port
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_sql_server_1433_1434 import check_security_group_ingress_for_sql_server_ports
from ec2.ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_telnet_23 import check_security_group_ingress_for_telnet_port
from ec2.ec2_securitygroup_allow_wide_open_public_ipv4 import check_security_group_rules
from ec2.ec2_securitygroup_default_restrict_traffic import execute
from ec2.ec2_securitygroup_from_launch_wizard import get_ec2_security_groups
from ec2.ec2_securitygroup_not_used import find_unused_security_groups
from ec2.ec2_securitygroup_with_many_ingress_egress_rules import check_security_groups

from ec2.lib import *


def key_pair():
    env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env')

    if os.path.exists(env_path):
        load_dotenv(env_path)
    else:
        open(env_path, 'a').close()

    try:
        

        aws_access_key_id = os.getenv('AWS_ACCESS_KEY_ID')
        aws_secret_access_key = os.getenv('AWS_SECRET_ACCESS_KEY')
        aws_default_region = os.getenv('AWS_DEFAULT_REGION', "ap-northeast-2")

        os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key_id
        os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_access_key
        os.environ['AWS_DEFAULT_REGION'] = aws_default_region

        ec2_client = boto3.client('ec2')
        ec2_resource = boto3.resource('ec2')

    except Exception as e:
        
        aws_access_key_id = input("AWS_ACCESS_KEY_ID: ")

        aws_secret_access_key = input("AWS_SECRET_ACCESS_KEY: ")

        aws_default_region = input("AWS_DEFAULT_REGION (기본값: ap-northeast-2[서울]): ") or "ap-northeast-2"

        os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key_id
        os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_access_key
        os.environ['AWS_DEFAULT_REGION'] = aws_default_region


        with open(env_path, 'w') as f:
            f.write(f"AWS_ACCESS_KEY_ID={aws_access_key_id}\n")
            f.write(f"AWS_SECRET_ACCESS_KEY={aws_secret_access_key}\n")
            f.write(f"AWS_DEFAULT_REGION={aws_default_region}\n")
        
        if not os.environ['AWS_DEFAULT_REGION']:
            os.environ['AWS_DEFAULT_REGION'] = "ap-northeast-2"

        ec2_client = boto3.client('ec2')
        ec2_resource = boto3.resource('ec2')



# 정사각형 테두리 생성 함수
def print_in_box(lines):
    max_length = max(len(f"{index + 1}. {line}") for index, line in enumerate(lines))
    print('╔' + '═' * (max_length + 2) + '╗')
    for index, line in enumerate(lines):
        print(f'║ {index + 1}. {line.ljust(max_length - len(f"{index + 1}. "))} ║')
    print('╚' + '═' * (max_length + 2) + '╝')

# EC2 인스턴스 목록 가져오기 함수
def list_ec2_instances():
    response = ec2_client.describe_instances()
    instances = []
    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            instances.append(instance['InstanceId'])
    return instances

# 파싱하는 함수 (instance_name 제외)
def parse_data(data):
    results = []
    for instance_id, checks in data.items():
        for check_name, check_results in checks.items():
            for result in check_results:
                results.append({
                    'instance_id': instance_id,
                    'check_name': check_name,
                    'arn': result['arn'],
                    'status': result['status']
                })
    return results

def ec2_client_info():
    instance_ids = list_ec2_instances()
    print("분석할 EC2 인스턴스를 선택하세요:\n")
    print("0. 모든 인스턴스")
    print_in_box(instance_ids)
    while True:
        try:
            selection = int(input("번호를 입력하세요: "))
            if selection == 0:
                selected_instances = instance_ids
                break
            elif 1 <= selection <= len(instance_ids):
                selected_instances = [instance_ids[selection - 1]]
                break
            else:
                print("유효한 번호를 입력하세요.")
        except ValueError:
            print("숫자를 입력하세요.")

    print(f"선택된 EC2 인스턴스: {', '.join(selected_instances)}")
    return selected_instances

def read_json_file(filename):
    with open(filename, 'r', encoding='utf-8') as file:
        return json.load(file)

def ec2_print_pretty_report(data):
    init(autoreset=True)  # 자동으로 색상을 리셋
    if not data:
        print("No data available.")
        return

    instance_id = data[0].get('instance_id', 'N/A')
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    pass_count = sum(1 for check in data if check['status'] == 'PASS')
    fail_count = sum(1 for check in data if check['status'] == 'FAIL')
    error_count = sum(1 for check in data if check['status'] == 'ERROR')

    print("="*50)
    print(f"{Fore.BLUE}Instance ID: {Fore.WHITE}{instance_id}")
    print(f"{Fore.CYAN}Current Time: {Fore.WHITE}{current_time}")
    print(f"{Fore.GREEN}PASS: {pass_count}{Style.RESET_ALL}, {Fore.RED}FAIL: {fail_count}{Style.RESET_ALL}, {Fore.YELLOW}ERROR: {error_count}{Style.RESET_ALL}")
    print("="*50)

    for check in data:
        status_color = Fore.GREEN if check['status'] == 'PASS' else Fore.RED if check['status'] == 'FAIL' else Fore.YELLOW
        print(f"{Fore.MAGENTA}Check Name: {Fore.WHITE}{check['check_name']}")
        print(f"{Fore.MAGENTA}ARN: {Fore.WHITE}{check.get('arn', 'N/A')}")
        print(f"{Fore.MAGENTA}Status: {status_color}{check['status']}{Style.RESET_ALL}")
        print("-"*50)

# EC2 분석 메인 함수
def main():
    key_pair()
    selected_instances = ec2_client_info()
    results = {}
    checklist = [
        (ec2_instance_port_ssh_exposed_to_internet, "ec2_instance_port_ssh_exposed_to_internet"),
        (ec2_instance_port_telnet_exposed_to_internet, "ec2_instance_port_telnet_exposed_to_internet"),
        (ec2_instance_profile_attached, "ec2_instance_profile_attached"),
        (ec2_instance_public_ip, "ec2_instance_public_ip"),
        (ec2_instance_secrets_user_data, "ec2_instance_secrets_user_data"),
        (ec2_launch_template_no_secrets, "ec2_launch_template_no_secrets"),
        (ec2_networkacl_allow_ingress_any_port, "ec2_networkacl_allow_ingress_any_port"),
        (ec2_networkacl_allow_ingress_tcp_port_22, "ec2_networkacl_allow_ingress_tcp_port_22"),
        (ec2_networkacl_allow_ingress_tcp_port_3389, "ec2_networkacl_allow_ingress_tcp_port_3389"),
        (ec2_securitygroup_allow_ingress_from_internet_to_any_port, "ec2_securitygroup_allow_ingress_from_internet_to_any_port"),
        (ec2_securitygroup_allow_ingress_from_internet_to_mongodb_ports, "ec2_securitygroup_allow_ingress_from_internet_to_mongodb_ports"),
        (ec2_securitygroup_allow_ingress_from_internet_to_ftp_ports, "ec2_securitygroup_allow_ingress_from_internet_to_ftp_ports"),
        (ec2_securitygroup_allow_ingress_from_internet_to_ssh_port_22, "ec2_securitygroup_allow_ingress_from_internet_to_ssh_port_22"),
        (ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_3389, "ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_3389"),
        (check_ec2_instance_port_cassandra_exposed_to_internet, "check_ec2_instance_port_cassandra_exposed_to_internet"),
        (check_ec2_instance_port_cifs_exposed_to_internet, "check_ec2_instance_port_cifs_exposed_to_internet"),
        (check_ec2_instance_port_elasticsearch_kibana_exposed_to_internet, "check_ec2_instance_port_elasticsearch_kibana_exposed_to_internet"),
        (check_ec2_instance_port_ftp_exposed_to_internet, "check_ec2_instance_port_ftp_exposed_to_internet"),
        (check_ec2_instance_port_kafka_exposed_to_internet, "check_ec2_instance_port_kafka_exposed_to_internet"),
        (check_ec2_instance_port_kerberos_exposed_to_internet, "check_ec2_instance_port_kerberos_exposed_to_internet"),
        (check_ec2_instance_port_ldap_exposed_to_internet, "check_ec2_instance_port_ldap_exposed_to_internet"),
        (check_ec2_instance_port_memcached_exposed_to_internet, "check_ec2_instance_port_memcached_exposed_to_internet"),
        (check_ec2_instance_port_mongodb_exposed_to_internet, "check_ec2_instance_port_mongodb_exposed_to_internet"),
        (check_ec2_instance_port_mysql_exposed_to_internet, "check_ec2_instance_port_mysql_exposed_to_internet"),
        (check_ec2_instance_port_oracle_exposed_to_internet, "check_ec2_instance_port_oracle_exposed_to_internet"),
        (check_ec2_instance_port_postgresql_exposed_to_internet, "check_ec2_instance_port_postgresql_exposed_to_internet"),
        (check_ec2_instance_port_rdp_exposed_to_internet, "check_ec2_instance_port_rdp_exposed_to_internet"),
        (check_ec2_instance_port_redis_exposed_to_internet, "check_ec2_instance_port_redis_exposed_to_internet"),
        (check_ec2_instance_port_sqlserver_exposed_to_internet, "check_ec2_instance_port_sqlserver_exposed_to_internet"),
        (check_security_group_ports, "check_security_group_ports"),
        (check_security_groups, "check_security_groups"),
        (check_security_group_ingress, "check_security_group_ingress"),
        (check_security_group_for_memcached, "check_security_group_for_memcached"),
        (check_security_group_ingress, "check_security_group_ingress"),
        (check_security_group_ingress_for_oracle_ports, "check_security_group_ingress_for_oracle_ports"),
        (check_security_group_ingress_for_postgres_port, "check_security_group_ingress_for_postgres_port"),
        (check_security_group_ingress_for_redis_port, "check_security_group_ingress_for_redis_port"),
        (check_security_group_ingress_for_sql_server_ports, "check_security_group_ingress_for_sql_server_ports"),
        (check_security_group_ingress_for_telnet_port, "check_security_group_ingress_for_telnet_port"),
        (check_security_group_rules, "check_security_group_rules"),
        (execute, "execute"),
        (get_ec2_security_groups, "get_ec2_security_groups"),
        (find_unused_security_groups, "find_unused_security_groups"),
        (check_security_groups, "check_security_groups")
    ]

    for instance_id in selected_instances:
        results[instance_id] = {}
        for checkthis, name in checklist:
            # print(f"{instance_id}에서 {name} 실행 중...")
            results[instance_id][name] = checkthis(ec2_client)

    # 파싱
    parsed_results = parse_data(results)


    script_dir = os.path.dirname(__file__)
    
    base_dir = os.path.join(os.path.abspath(os.path.join(script_dir, '..')), 'results')
    results_dir = os.path.join(base_dir, 'detail_results')

    if not os.path.exists(results_dir):
        os.makedirs(results_dir)
    
    s3_results_path = os.path.join(results_dir, 'ec2_analysis_results.json')

    with open(s3_results_path, 'w') as json_file:
        json.dump(results, json_file, indent=4, ensure_ascii=False)

    results_dir = os.path.join(base_dir, 'checks')

    if not os.path.exists(results_dir):
        os.makedirs(results_dir)

    s3_checks_path = os.path.join(results_dir, 'ec2_checks.json')
    
    with open(s3_checks_path, 'w') as json_file:
        json.dump(parsed_results, json_file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    main()
