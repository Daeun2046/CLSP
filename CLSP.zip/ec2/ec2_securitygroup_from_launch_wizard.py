import boto3
import ipaddress
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

def set_aws_credentials():
    access_key = input("Enter your AWS Access Key: ")
    secret_key = input("Enter your AWS Secret Key: ")
    os.environ["AWS_ACCESS_KEY_ID"] = access_key
    os.environ["AWS_SECRET_ACCESS_KEY"] = secret_key

def get_ec2_security_groups(ec2_client, target_group_name="default"):
    try:
        response = ec2_client.describe_security_groups()
        security_groups = response['SecurityGroups']
        findings = check_security_group_rules(security_groups, target_group_name)
        return findings
    except (NoCredentialsError, PartialCredentialsError):
        set_aws_credentials()
        return get_ec2_security_groups(ec2_client, target_group_name)
    except Exception as e:
        # Return a default value even if an error occurs
        return [{
            "arn": "N/A",
            "tag": [],
            "region": ec2_client.meta.region_name,
            "status": "ERROR",
            "status_extended": f"An error occurred: {str(e)}"
        }]

def check_security_group_rules(security_groups, target_group_name="default"):
    findings = []
    cidr_threshold = 24
    region = ec2_client.meta.region_name  # EC2 클라이언트에서 리전 정보를 가져옴

    for sg in security_groups:
        if sg.get('GroupName') == target_group_name:
            sg_id = sg['GroupId']
            sg_arn = sg.get('Arn', 'N/A')
            sg_tags = sg.get('Tags', [])

            report = {
                "arn": sg_arn,
                "tag": sg_tags,
                "region": region,
                "status": "PASS",
                "status_extended": f"Security group ({sg_id}) has no potential wide-open non-RFC1918 address."
            }

            def check_rules(rules, rule_type):
                for rule in rules:
                    for ipv4 in rule.get("IpRanges", []):
                        ip = ipaddress.ip_network(ipv4["CidrIp"])
                        if ip.is_global and 0 < ip.prefixlen < cidr_threshold:
                            report["policy_name"] = rule_type
                            report["status"] = "FAIL"
                            report["status_extended"] = f"Security group ({sg_id}) has potential wide-open non-RFC1918 address {ipv4['CidrIp']} in {rule_type} rule."
                            return

            check_rules(sg.get('IpPermissions', []), 'ingress')
            if report["status"] == "PASS":
                check_rules(sg.get('IpPermissionsEgress', []), 'egress')

            findings.append(report)

    return findings

def save_findings_to_json(findings, filename):
    with open(filename, 'w') as file:
        json.dump(findings, file, indent=4)

if __name__ == "__main__":
    region = input("Enter the AWS region (e.g., ap-northeast-2): ")

    ec2_client = boto3.client('ec2', region_name=region)
    target_group_name = "default"

    # EC2 보안 그룹 가져오기 및 검사
    findings = get_ec2_security_groups(ec2_client, target_group_name)

    if findings:
        # 첫 번째 결과만 출력
        result_to_save = findings[0]
        print(json.dumps(result_to_save, indent=4, ensure_ascii=False))

        # 결과를 JSON 파일로 저장
        save_findings_to_json([result_to_save], 'ec2_securitygroup_from_launch_wizard.json')
    else:
        print("No findings for the specified security group.")
