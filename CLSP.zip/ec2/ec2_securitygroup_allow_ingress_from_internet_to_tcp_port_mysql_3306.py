import boto3
import os
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

def set_aws_credentials():
    access_key = input("AWS Access Key를 입력하세요: ")
    secret_key = input("AWS Secret Key를 입력하세요: ")

    os.environ['AWS_ACCESS_KEY_ID'] = access_key
    os.environ['AWS_SECRET_ACCESS_KEY'] = secret_key

def get_ec2_client():
    try:
        return boto3.client('ec2')
    except (NoCredentialsError, PartialCredentialsError):
        print("AWS 자격 증명을 찾을 수 없거나 불완전합니다. 자격 증명을 입력하세요.")
        set_aws_credentials()
        return boto3.client('ec2')

def check_security_group_ingress(ec2_client):
    check_ports = [3306]
    findings = []

    try:
        response = ec2_client.describe_security_groups()
    except Exception as e:
        print(f"Error describing security groups: {str(e)}")
        return []

    for security_group in response['SecurityGroups']:
        report = {
            'arn': security_group.get('Arn', 'N/A'),
            'tag': security_group.get('Tags', []),
            'region': ec2_client.meta.region_name,
            'status': "PASS",
            'status_extended': f"보안 그룹 {security_group['GroupName']} ({security_group['GroupId']})은(는) MySQL 포트 3306이 인터넷에 열려 있지 않습니다."
        }

        for ingress_rule in security_group.get('IpPermissions', []):
            ip_ranges = ingress_rule.get('IpRanges', [])
            if ingress_rule.get('FromPort') in check_ports and ingress_rule.get('ToPort') in check_ports:
                for ip_range in ip_ranges:
                    if ip_range.get('CidrIp') == '0.0.0.0/0':
                        report['status'] = "FAIL"
                        report['status_extended'] = f"보안 그룹 {security_group['GroupName']} ({security_group['GroupId']})은(는) MySQL 포트 3306이 인터넷에 열려 있습니다."
                        break

        findings.append(report)

    return findings

def save_findings_to_json(findings, filename):
    if findings:
        with open(filename, 'w', encoding='utf-8') as file:
            json.dump(findings, file, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    ec2_client = boto3.client(
        'ec2'
    )

    # 함수 호출 및 결과 저장
    results = check_security_group_ingress(ec2_client)
    save_findings_to_json(results, 'ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_mysql_3306.json')
    # 결과를 JSON 형식으로 출력
    print(f"결과가 'ec2_securitygroup_allow_ingress_from_internet_to_tcp_port_mysql_3306.json' 파일에 저장되었습니다.")
