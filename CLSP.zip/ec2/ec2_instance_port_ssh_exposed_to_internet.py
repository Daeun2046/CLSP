import boto3
import json
from botocore.exceptions import ClientError
from ec2.lib import *  # 추가 함수들 포함 (예: check_security_group, get_instance_public_status)

# VPC 클라이언트를 사용하여 서브넷 정보를 가져와서 public 여부를 확인하는 함수
def get_vpc_subnets(vpc_client):
    subnets = vpc_client.describe_subnets()
    vpc_subnets = {
        subnet['SubnetId']: {
            'Public': any(
                attr['Key'] == 'mapPublicIpOnLaunch' and attr['Value'] == 'true'
                for attr in subnet.get('Tags', [])
            )
        } for subnet in subnets['Subnets']
    }
    return vpc_subnets

# EC2 인스턴스의 SSH 포트가 인터넷에 노출되었는지 확인하는 함수
def ec2_instance_port_ssh_exposed_to_internet(ec2_client):
    findings = []
    check_ports = [22]

    try:
        vpc_client = boto3.client('ec2')
        vpc_subnets = get_vpc_subnets(vpc_client)

        instances = ec2_client.describe_instances()
        for reservation in instances['Reservations']:
            for instance in reservation['Instances']:
                report = {
                    "arn": instance['InstanceId'],
                    "tag": instance.get('Tags', []),
                    "region": instance['Placement']['AvailabilityZone'][:-1],  # 마지막 문자열을 제외하고 region 정보로 사용
                    "status": "PASS",
                    "status_extended": f"인스턴스 {instance['InstanceId']}는 인터넷에 SSH 포트 22가 열려 있지 않습니다."
                }
                is_open_port = False

                security_groups = instance['SecurityGroups']
                for sg in security_groups:
                    sg_info = ec2_client.describe_security_groups(GroupIds=[sg['GroupId']])
                    for sg_detail in sg_info['SecurityGroups']:
                        for ingress_rule in sg_detail['IpPermissions']:
                            if check_security_group(ingress_rule, "tcp", check_ports, any_address=True):
                                report["status"] = "FAIL"
                                report["status_extended"] = get_instance_public_status(vpc_subnets, instance, "SSH")
                                is_open_port = True
                                break
                        if is_open_port:
                            break

                findings.append(report)
    except ClientError as e:
        findings.append({
            "arn": "N/A",
            "tag": "N/A",
            "region": "N/A",
            "status": "ERROR",
            "status_extended": f"EC2 인스턴스 정보를 가져오는 중 오류 발생: {str(e)}"
        })

    return findings

if __name__ == "__main__":
    ec2_client = boto3.client('ec2')
    result = ec2_instance_port_ssh_exposed_to_internet(ec2_client)

    print(json.dumps(result, indent=4))
    # with open('ec2_instance_port_ssh_exposed_to_internet_results.json', 'w') as json_file:
    #     json.dump(result, json_file, indent=4)
